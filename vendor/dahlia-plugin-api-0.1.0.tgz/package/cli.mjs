#!/usr/bin/env node
import path from "node:path";
import { BuildError, buildPlugin } from "./build.mjs";

const USAGE = `dahlia-plugin build [folder] [--minify] [--out <folder>]

Builds the plugin in [folder] (the current folder by default) into dist/ (or --out):
plugin.json, the halves it names, its styles, its assets, and plugin.zip.`;

const [command, ...rest] = process.argv.slice(2);
if (command !== "build") {
  console.log(USAGE);
  process.exit(command === undefined || command === "--help" ? 0 : 1);
}

const minify = rest.includes("--minify");
const outAt = rest.indexOf("--out");
const out = outAt >= 0 ? rest[outAt + 1] : undefined;
const folder = rest.find((a, i) => !a.startsWith("--") && !(outAt >= 0 && i === outAt + 1));
try {
  const { manifest, files, zip } = await buildPlugin({ root: path.resolve(folder ?? "."), minify, ...(out ? { out: path.resolve(out) } : {}) });
  console.log(`${manifest.name} ${manifest.version}: ${files.join(", ")}`);
  console.log(`→ ${path.relative(process.cwd(), zip) || zip}`);
} catch (err) {
  console.error(err instanceof BuildError ? err.message : err);
  process.exit(1);
}

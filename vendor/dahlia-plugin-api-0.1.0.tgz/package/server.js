/** Types the server half (`server.d.ts`), and hands it back unchanged. */
export function defineServerPlugin(plugin) {
  return plugin;
}

/**
 * **Chips of your own in the HUD over the composer** — the row where the states a reader marked "show
 * in HUD" stand. Your chips follow the app's, drawn by the same code with the same face (a mark, a
 * label, a value, a bar), before the divider past which the armed actions stand.
 *
 * ```ts
 * this.addHudChips({
 *   id: "tower",
 *   chips: (chat) => [{ id: "faces", label: "Tower", value: `d${faces}`, icon: { file: "assets/icons/tower.svg" } }],
 * });
 * ```
 *
 * `chips` is asked whenever the row is drawn — the chat changed, the reader typed — so keep it a quick
 * read of what you already hold. To redraw for a change of your own, add the same `id` again. A chip
 * that throws, or a `chips` that throws, draws nothing and leaves the app's chips standing.
 */
import type { PluginIcon } from "./graphics";
import type { PluginChat } from "./index";

export type PluginHudChip = {
  /** Yours alone within this source. */
  id: string;
  label: string;
  /** What follows the label; cut at the chip's width, whole in `title`. */
  value?: string;
  /** An emoji as its mark, or `icon`. */
  emoji?: string;
  icon?: PluginIcon;
  /** The tooltip. */
  title?: string;
  /** A small bar under the value, as a numeric state's chip has. */
  bar?: { value: number; min: number; max: number };
  /** A chip with a press is a button. It may open your own dialog; it may not spend (only the reader's send does). */
  onPress?: () => void;
};

export type PluginHudSource = {
  /** Yours alone: adding the same id again replaces it (a redraw). */
  id: string;
  /** The chips for the chat on screen, in order. */
  chips: (chat: PluginChat) => readonly PluginHudChip[];
};

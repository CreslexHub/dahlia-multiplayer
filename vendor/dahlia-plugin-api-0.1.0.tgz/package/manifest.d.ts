/**
 * `plugin.json`, the manifest a plugin ships at the root of its package. The app draws the plugin's
 * card from it and nothing else, so a plugin cannot show one thing and do another.
 */

/** A plugin's id: lowercase words and hyphens. It names a folder on the reader's disk. */
export declare const PLUGIN_ID_PATTERN: RegExp;

/**
 * One kind of reach, said in a sentence on the card before Install. `run-program` also needs the
 * program pinned in `programs`, and the card adds a sentence of the app's own about it.
 */
export type PluginPermission = {
  kind: "download" | "run-program" | "public-address" | "network";
  sentence: string;
};

/** One setting the card draws for the plugin. The server half reads the values (`ctx.settings`). */
export type PluginSettingSpec =
  | { key: string; kind: "toggle"; label: string; hint?: string; default: boolean }
  | { key: string; kind: "text"; label: string; hint?: string; default: string; placeholder?: string; maxLength?: number }
  | { key: string; kind: "number"; label: string; hint?: string; default: number; min: number; max: number; unit?: string }
  | { key: string; kind: "select"; label: string; hint?: string; default: string; options: { id: string; label: string }[] };

export type PluginSettingValue = boolean | string | number;
export type PluginSettings = Record<string, PluginSettingValue>;

/** A button on the card while the plugin is on. `when` offers it only while running, or only while stopped. */
export type PluginAction = { id: string; label: string; when?: "running" | "stopped" };

/** A file the plugin downloads onto the reader's computer: where from, and the page that publishes it. */
export type PluginDownload = { file: string; url: string; page: string };

/**
 * A route of the plugin's server half. Served at `/api/plugins/<id>/<path>/…` to the reader's own
 * devices; a `public` one is served to guests too, at `/api/plugins/<id>/public/<path>/…`.
 */
export type PluginMountSpec = { path: string; public?: boolean; publicBodyBytes?: number };

/**
 * A program the app may start for the plugin: one file of its package, for one platform
 * (`win32-x64`, `linux-x64`, `darwin-arm64`…), at one SHA-256. Nothing else is ever started.
 */
export type PluginProgram = { file: string; platform: string; sha256: string };

/**
 * A page of your own, drawn by your client half (`this.addPage(path, Component)`) at
 * `/plugin?at=<id>/<path>`. `public`: a guest at the reader's public address may open it, with nothing
 * installed (the app serves your client half to them while you declare one). `landing`: where the
 * public door sends a guest who asked for no page in particular; it is public.
 */
export type PluginPageSpec = { path: string; public?: boolean; landing?: boolean };

/**
 * **Who a plugin's effects reach at a table of several people.** `host`: only the host ever sees
 * them. `table`: what it changes is visible to the guests too.
 */
export type PluginReach = "host" | "table";

export type PluginManifest = {
  id: string;
  name: string;
  /** The plugin's own version, semver. */
  version: string;
  /** The oldest app version it works with. */
  minAppVersion: string;
  author: string;
  description: string;
  reach: PluginReach;
  permissions: PluginPermission[];
  downloads?: PluginDownload[];
  /** When it downloads them, if not at install, said on the card ("the first time you open it"). */
  downloadsWhen?: string;
  settings?: PluginSettingSpec[];
  actions?: PluginAction[];
  /** The half that runs in the reader's tab: an ES module whose default export extends `Plugin`. */
  client?: string;
  /** The half that runs in its own Node process, walled to the plugin's folder. */
  server?: string;
  /** A stylesheet added to the page while the plugin is on. */
  styles?: string;
  mounts?: PluginMountSpec[];
  programs?: PluginProgram[];
  /** Your own pages; each is drawn by your client half. */
  pages?: PluginPageSpec[];
};

/**
 * **A theme of your own** — a row of the app's own theme table, chosen in Settings → Appearance →
 * Theme beside Midnight, Obsidian, Slate and Dawn, under your plugin's name.
 *
 * A theme is one of the app's shipped themes (`base`) with your values over its tokens — the colours,
 * faces and corners every screen is drawn from (`DESIGN.md` §2). The app's components read only those
 * tokens, so every screen, card and control follows a theme without knowing it exists. Nothing changes
 * until the reader chooses it; removing your plugin draws the app's default theme again, and the
 * reader's choice comes back if your plugin does.
 *
 * ```ts
 * this.addTheme({
 *   id: "brass",
 *   label: "Brass",
 *   blurb: "Warm and dark, like the inside of a dice tower.",
 *   base: "midnight",
 *   colors: { "surface-100": "oklch(17% 0.02 70)", "surface-200": "oklch(22% 0.025 70)", "ink-700": "oklch(95% 0.02 85)" },
 *   radii: { lg: "0.25rem" },
 * });
 * ```
 */

/** The app's shipped themes a theme of yours is drawn over. `dawn` is the light one. */
export type ThemeBase = "midnight" | "obsidian" | "slate" | "dawn";

/**
 * **The colour tokens a theme may set** (`DESIGN.md` §2.1). The number rises with *presence*, not
 * lightness: `surface` is elevation (100 the page, 300 a raised card), `line` is contrast, `ink` is
 * loudness (700 body text). On a light base, 100 is the lightest surface; on a dark one the darkest.
 * The accent is the reader's own choice and is not a theme's.
 */
export type ThemeColorToken =
  | "surface-100"
  | "surface-200"
  | "surface-300"
  | "surface-400"
  | "surface-500"
  | "surface-600"
  | "line-200"
  | "line-300"
  | "line-400"
  | "line-500"
  | "line-600"
  | "ink-100"
  | "ink-200"
  | "ink-300"
  | "ink-400"
  | "ink-500"
  | "ink-600"
  | "ink-700"
  | "well"
  | "veil"
  | "shade"
  | "scrim"
  | "on-scrim";

/**
 * **The faces a theme may set** (`DESIGN.md` §2.2): a font stack, as CSS writes one. The app keeps its
 * emoji either side of it, so a face of yours never loses them. `sans` is the interface's face until
 * the reader chooses another.
 */
export type ThemeFontToken = "sans" | "serif" | "mono" | "rounded";

/** **The corners a theme may set** (`DESIGN.md` §2.4): the steps the app's cards, buttons and fields wear. */
export type ThemeRadiusToken = "sm" | "md" | "lg" | "xl" | "2xl";

export type PluginTheme = {
  /** Yours alone: the app files it under your plugin (`<plugin>/<id>`), so it cannot meet another's. */
  id: string;
  /** Its name, written on its tile in the picker in its own ink, over its own surfaces. */
  label: string;
  /** One line under the picker while it is chosen. */
  blurb?: string;
  /** The shipped theme it is drawn over; `"dawn"` makes a light theme. Absent: `"midnight"`. */
  base?: ThemeBase;
  /** Colour values (any CSS colour) over the base's. */
  colors?: Partial<Record<ThemeColorToken, string>>;
  /** Font stacks over the base's. */
  fonts?: Partial<Record<ThemeFontToken, string>>;
  /** Corner radii (any CSS length) over the base's. */
  radii?: Partial<Record<ThemeRadiusToken, string>>;
};

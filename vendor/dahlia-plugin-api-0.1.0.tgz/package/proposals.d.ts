/**
 * **A kind of change your plugin proposes** — a tag a model writes, filed as a proposal the reader
 * approves, edits or discards on a card like the app's own (a new world, a state change), and applied
 * by your code when they approve it.
 *
 * Registered with `this.addProposalKind(kind)`, it joins the app's own tables: its tag is a tool the
 * reader adds to an agent in Add block → Tool instructions (the card is the grant, titled with your
 * plugin's name), its calls are read by the app's parser, judged by your `validate`, de-duplicated,
 * and filed as a card in the Director pane and under the reply in the story. Whether it applies
 * without asking is the reader's answer on Autonomy, under your tool's row — it asks until they say
 * otherwise. Approving runs your `apply` on the chat inside the app's one write; a rewind, a retry or
 * the card put back runs your `takeBack`.
 *
 * ```tsx
 * this.addProposalKind({
 *   name: "tower_fate",
 *   label: "Tower fate",
 *   says: "Write what the dice decided onto a character's card.",
 *   title: "TOWER FATE — write what the tower decided onto a character's card.",
 *   when: "a roll of the tower settled something about a character that should last.",
 *   args: [{ name: "card", type: "string", required: true, doc: "the character's name" }],
 *   body: { field: "fate", doc: "the line to write", required: true },
 *   edits: { text: "body" },
 *   validate: (change, chat) => (chat && !chat.characters?.some((c) => c.name === change.args.card) ? `no character is called "${change.args.card}"` : null),
 *   apply: (draft, change) => { … replace the character, never write into it … },
 *   takeBack: (draft, change) => { … take the line back out … },
 *   card: { icon: { file: "assets/icons/tower.svg" }, tone: "amber", noun: "Tower fate" },
 * });
 * ```
 */
import type { ComponentType } from "react";
import type { CardLook } from "./graphics";
import type { PluginToolArg } from "./tools";
import type { Chat } from "./app";

/**
 * **One change of your kind**, as the app read the tag: its attributes by name (an alias already
 * folded) and what was between the tags. It is what the reader approves, and what their edit changes.
 */
export type PluginChange = {
  kind: string;
  args: Readonly<Record<string, string>>;
  body?: string;
};

/** What your card's `Body` is drawn with: the change, and the chat it is proposed in. */
export type PluginProposalCardProps = {
  change: PluginChange;
  chat?: Chat;
};

/** What the card says of a change. Every part optional; the app says the rest from the call. */
export type PluginProposalSummary = {
  /** The headline: what the change is about. */
  subject?: string;
  /** Short facts beside it, each a chip. */
  facts?: readonly { label?: string; value: string }[];
  /** The words the change carries, at reading size. */
  prose?: string;
};

export type PluginProposalKind = {
  /**
   * The tag the model writes, the name of its card and of its answer on Autonomy — lower-case letters,
   * digits and `_`, starting with a letter. Refused when the app already reads that tag.
   */
  name: string;
  /** Other tag names read as this one, never shown to the model. */
  aliases?: readonly string[];
  /** The card's name in Prompt master, and on its tag. */
  label: string;
  /** What it is for, in a sentence the reader is shown under its name. */
  says: string;

  // ── the paragraph the model is told, rendered by the app like its own tools' ──
  title: string;
  when?: string;
  whenNot?: string;
  notes?: readonly string[];
  examples?: readonly { args: Record<string, string>; body?: string }[];
  args: readonly PluginToolArg[];
  body?: { field: string; doc: string; required: boolean };

  /**
   * **Why this call cannot be used, in one line to the model that wrote it — or null.** Asked as the
   * reply is read (without a chat: the tag's shape alone) and again against the chat when the reader
   * approves it, which may be long after. A throw is read as the refusal.
   */
  validate?: (change: PluginChange, chat?: Chat) => string | null;
  /**
   * **Make the change**, on `draft` — the chat inside the app's one write, so what you change is saved,
   * synced and drawn. Return a sentence to say why it did nothing (the card then reads "Not applied"
   * with it); a throw is the same. Change nothing but `draft`: the app may run it on a copy, to let the
   * next call in the same reply see it. Replace a list's element rather than writing into it (the app
   * keeps the chat before the change, and an element is shared with it).
   */
  apply: (draft: Chat, change: PluginChange) => string | null | void;
  /**
   * **Undo it**, on `draft`: a rewind past the reply, a retry, a card put back in front of the reader.
   * Without it a change of your kind stays when its turn is taken back, and an approved card of it is
   * never put back.
   */
  takeBack?: (draft: Chat, change: PluginChange) => void;
  /** Whether the chat already is what this says, so proposing it is proposing nothing (no card is made). */
  isNoOp?: (chat: Chat, change: PluginChange) => boolean;
  /** What the card says of a change. Without it: the first argument as the headline, every argument below, the body as prose. */
  summary?: (change: PluginChange, chat?: Chat) => PluginProposalSummary;
  /**
   * **What the card's edit boxes change**: the argument each writes, or `"body"` for what is between the
   * tags. `text` is the big box, `title` the line above it. Without it the card has no pencil.
   */
  edits?: { title?: string; text: string };
  /**
   * **Which right at a table lets a guest edit it before approving** — one the table names, such as
   * `"editLibrary"` or `"writeNotes"`. Without it a guest approves or declines it as it stands.
   */
  guestEdits?: string;
  /** How its card looks (`graphics.d.ts`), and a body drawn on it under its headline. */
  card?: CardLook & { Body?: ComponentType<PluginProposalCardProps> };
};

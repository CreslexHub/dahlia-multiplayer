import { PLUGIN_API_GLOBAL } from "./global.js";

export { PLUGIN_ID_PATTERN } from "./manifest.js";

/**
 * The app's API, read off the global it sets before it loads any plugin. A bundle evaluated anywhere
 * else has no app to talk to, and says so rather than failing later on an undefined.
 */
const api = globalThis[PLUGIN_API_GLOBAL];
if (!api) {
  throw new Error("@dahlia/plugin-api: this code runs inside Dahlia, loaded as a plugin. There is no app here.");
}

export const Plugin = api.Plugin;
export const React = api.React;
export const ui = api.ui;
export const app = api.app;
export const apiVersion = api.version;

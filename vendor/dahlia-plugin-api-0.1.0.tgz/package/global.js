/**
 * Where the app puts its plugin API, and which version of it — read by the app, which sets the
 * global before it loads any plugin, and by this package's runtime, which reads it. One file for
 * both, so the two sides cannot name two different globals.
 */
export const PLUGIN_API_GLOBAL = "__dahliaPluginApi";

/** Raised when the API changes in a way an older plugin would notice. */
export const PLUGIN_API_VERSION = 1;

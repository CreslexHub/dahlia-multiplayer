import { PLUGIN_API_GLOBAL } from "./global.js";

/**
 * JSX, compiled against the app's React. The build points `jsxImportSource` here, so an author's
 * `<div>` becomes the app's `jsx("div")` and their bundle carries no React of its own.
 */
const { jsx: runtime } = globalThis[PLUGIN_API_GLOBAL] ?? {};
if (!runtime) {
  throw new Error("@dahlia/plugin-api: this code runs inside Dahlia, loaded as a plugin. There is no app here.");
}

export const jsx = runtime.jsx;
export const jsxs = runtime.jsxs;
export const Fragment = runtime.Fragment;

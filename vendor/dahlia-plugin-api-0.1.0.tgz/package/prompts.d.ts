/**
 * **Prompt material a plugin offers**: ready-made prompt blocks and macros.
 *
 * Neither changes any prompt by being offered. A block is a row in Prompt master's Add block → Ready-made,
 * filed under your plugin's name and titled with it; the reader adds it to an agent's stack, and from
 * then on it is theirs — an ordinary block they can reword, move or switch off, drawn with your name on
 * every screen that shows a prompt. A macro does something only where a reader writes it in a block, and
 * the Debug pane shows what it put there.
 *
 * ```ts
 * this.addPromptBlock({
 *   id: "tower-etiquette",
 *   title: "Dice tower etiquette",
 *   describe: "When the story should lean on the dice tower for chance.",
 *   content: "When a moment turns on chance, drop the dice with <tower_roll> rather than deciding.",
 * });
 * this.addMacro({ name: "towerFaces", describe: "How many faces the tower's dice have.", run: () => "6" });
 * ```
 */

/** A ready-made block, as the catalogue offers it. */
export type PluginPromptBlock = {
  /** Yours alone: filed under your plugin, so it cannot collide with another plugin's. */
  id: string;
  title: string;
  /** One line under the title in the picker: when the reader would want it. */
  describe: string;
  /** Its words. Macros in it (`{{char}}`, your own) are run when the prompt is built, as in any block. */
  content: string;
  /** The turn it is sent as; `system` unless said. */
  role?: "system" | "user" | "assistant";
  /** A setting it is in the prompt under, as any block's condition is (`"pseudoMessage"`…). */
  condition?: string;
};

/** A macro: `{{name}}`, or `{{name::argument}}` with arguments. */
export type PluginMacro = {
  /** Matched case-insensitively. Refused when the app already has a macro by that name. */
  name: string;
  /** What the Macros guide and the `{{` list say about it. */
  describe: string;
  /** How the guide spells it; `{{name}}` unless said. */
  written?: string;
  /** How many `::` arguments it takes, least and most; none unless said. Outside it, the macro stays as written. */
  args?: readonly [min: number, max: number];
  /**
   * What goes in its place when the prompt is built, from its arguments — or `null` to leave the macro as
   * written. Runs every time a prompt is built (the Debug pane's preview too), so it must be quick and must
   * not spend anything.
   */
  run: (args: readonly string[]) => string | null;
};

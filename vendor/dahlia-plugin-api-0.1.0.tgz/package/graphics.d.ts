/**
 * **How a plugin's things look** — the icons and the tones its cards, buttons and doors wear.
 *
 * The app draws a plugin's card with the same code that draws its own (a tool's card in the story, a
 * proposal's card in the Director pane), so a plugin says what its card looks like in the app's own
 * terms rather than handing over a stylesheet for it: a tone from the app's palette, which every theme
 * already styles, and an icon.
 */
import type { ComponentType } from "react";

/**
 * **An icon**, three ways:
 *
 * - one of the app's marks, by name (`"story"`, `"characters"`, `"world"`, `"memory"`, `"room"`…);
 * - a picture from your own package, by its path in it (`{ file: "icons/die.svg" }`) — an SVG or an
 *   image you ship, served from your approved files like `client.js` is. An SVG is drawn in the colour
 *   of the text around it when it uses `currentColor`;
 * - your own component, drawn with the `className` the app sizes and colours it with.
 */
export type PluginIcon = string | { file: string } | ComponentType<{ className?: string }>;

/**
 * **The tones a card may wear** — the app's palette, so a plugin's card reads as one of the app's in
 * every theme. `ink` is the plain one.
 */
export type CardTone = "teal" | "cyan" | "sky" | "indigo" | "violet" | "pink" | "rose" | "amber" | "emerald" | "ink";

/** What a card looks like: its icon, its tone, and what its kind is called (the tooltip, a screen reader). */
export type CardLook = {
  icon?: PluginIcon;
  tone?: CardTone;
  noun?: string;
};

/**
 * **A card file of your own kind** — read in where the app's card files are (a chat's cast, the
 * character shelf), written out where they are (Export on a card or a shelf), beside the PNG, JSON and
 * Dahlia formats.
 *
 * You translate; the app does the rest. `read` turns your file into a card the app already reads — a
 * SillyTavern card (`{ spec: "chara_card_v2", data: { name, description, … } }`) or a Dahlia file — and
 * that card goes through the same checks and the same landing as any card file: its ids made the
 * library's, its lorebook filed, its links bound. `write` is handed the card as the app's JSON card
 * writes it (SillyTavern's card for a character, a World Info entry for a world card) and returns your
 * file.
 *
 * ```ts
 * this.addCardFormat({
 *   id: "tower-card",
 *   label: "Tower card",
 *   extension: ".tower.json",
 *   read: async (file) => ({ card: fromTower(JSON.parse(await file.text())) }),
 *   write: ({ json }) => JSON.stringify(toTower(json)),
 * });
 * ```
 */

export type PluginCardRead = {
  /** A card the app reads: a SillyTavern card object, or a Dahlia file object. */
  card: unknown;
  /** A portrait as a `data:image/…` URL, for a format that carries one. */
  portrait?: string;
};

export type PluginCardWrite = {
  kind: "character" | "world";
  /** The card as the app's JSON card writes it. */
  json: Record<string, unknown>;
  /** The card's name or title. */
  name: string;
};

export type PluginCardFormat = {
  /** Yours alone; filed under your plugin. */
  id: string;
  /** Its name on the export dialog's tile. */
  label: string;
  /** What its files end in, with the dot (`.tower.json`). Files ending so are read by `read`. */
  extension: string;
  /** One line under the export tiles, saying where the file is going. */
  hint?: string;
  /** Read one of your files into a card. Throw an `Error` with a sentence to refuse it. */
  read?: (file: File) => PluginCardRead | Promise<PluginCardRead>;
  /** Write one card as your file: its text, or a `Blob`. */
  write?: (card: PluginCardWrite) => string | Blob | Promise<string | Blob>;
};

export declare const PLUGIN_API_GLOBAL: "__dahliaPluginApi";
export declare const PLUGIN_API_VERSION: 1;

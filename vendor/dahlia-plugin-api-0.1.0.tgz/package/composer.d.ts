/**
 * **A row of your own in the composer's menu** — the `≡` beside the box the reader types in, where
 * "Attach a file" is. Your row follows the app's one-press rows, drawn as they are, and runs when the
 * reader presses it (the menu closes first).
 *
 * ```ts
 * this.addComposerAction({
 *   id: "drop",
 *   label: "Drop a die",
 *   icon: { file: "assets/icons/tower.svg" },
 *   tone: "amber",
 *   onPress: (chat) => ui.showNotice(`A ${roll()} for ${chat.title}`),
 * });
 * ```
 *
 * The press is the reader's: your row may change the chat (`app.chat.mutateChat`), open your own
 * dialog or start a turn the reader asked for. It shows while your plugin is installed and on;
 * `shown` hides it for a chat it means nothing to.
 */
import type { CardTone, PluginIcon } from "./graphics";
import type { PluginChat } from "./index";

export type PluginComposerAction = {
  /** Yours alone: adding the same id again replaces it. */
  id: string;
  label: string;
  icon: PluginIcon;
  /** The icon's tone. Absent: the plain one. */
  tone?: CardTone;
  /** Whether it is offered for this chat. Absent: always. */
  shown?: (chat: PluginChat) => boolean;
  onPress: (chat: PluginChat) => void;
};

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { PLUGIN_ID_PATTERN } from "./manifest.js";
import { PLUGIN_API_GLOBAL } from "./global.js";
import { zipFiles } from "./zip.mjs";

/**
 * **`dahlia-plugin build`**: a plugin's folder in, `dist/` out — `plugin.json`, the halves its
 * manifest names, its stylesheet, its `assets/`, and all of them in `dist/plugin.zip`, which is what
 * the app's "Install from file" takes and what a GitHub release carries.
 *
 * The layout it reads:
 *
 *   plugin.json          the manifest; `client`, `server` and `styles` name the built files
 *   src/<client>.tsx     the client half (`.tsx`, `.ts`, `.jsx` or `.js`), named after `client`
 *   src/<server>.ts      the server half, named after `server`
 *   src/<styles>         the stylesheet, as `styles` names it
 *   assets/              copied whole, for files the plugin reads at run time
 */

const PACKAGE = "@dahlia/plugin-api";
/** The esbuild namespace `react` resolves into: the app's React, read off the API's global. */
const APP_REACT = "dahlia-app-react";
const HERE = path.dirname(fileURLToPath(import.meta.url));
const SOURCE_EXTENSIONS = [".tsx", ".ts", ".jsx", ".js"];
export const DIST = "dist";
export const ZIP = "plugin.zip";
export const MANIFEST = "plugin.json";
const ASSETS = "assets";

/** A sentence an author can act on; the CLI prints it without a stack. */
export class BuildError extends Error {}

/** `@dahlia/plugin-api[/x]` → this package's file for it, from its own `exports`, so the map is one. */
function ownEntry(specifier) {
  const exportsMap = JSON.parse(fs.readFileSync(path.join(HERE, "package.json"), "utf8")).exports;
  const key = "." + specifier.slice(PACKAGE.length);
  const target = exportsMap[key];
  const file = typeof target === "string" ? target : target?.default;
  return file ? path.join(HERE, file) : null;
}

/**
 * **The plugin builds against this copy of the API**, whichever copy its imports would otherwise
 * find: the runtime here and the app it was written for agree, and a plugin inside a checkout of
 * the app needs no install to build.
 */
function apiFromHere(half) {
  return {
    name: "dahlia-plugin-api",
    setup(build) {
      build.onResolve({ filter: /^@dahlia\/plugin-api(\/.*)?$/ }, (args) => {
        if (half === "server" && args.path === PACKAGE) {
          return { errors: [{ text: `The server half imports from "${PACKAGE}/server": "${PACKAGE}" is the client half's.` }] };
        }
        const file = ownEntry(args.path);
        return file ? { path: file } : { errors: [{ text: `"${args.path}" is not part of ${PACKAGE}.` }] };
      });
      if (half !== "client") return;
      /*
       * **`react` is the app's React.** A bundled copy renders, and then every hook in it throws,
       * because hooks are kept per copy. So `react` and its JSX runtimes resolve to the app's own, off
       * the API's global, for the plugin's code and for any library it bundles that imports React (a
       * store, an icon set) alike. They are CommonJS here so every named import (`useState`) is read
       * off the app's object as the plugin runs. `react-dom` is the app's to render with; a plugin
       * that needs a portal uses `ui.Modal`.
       */
      build.onResolve({ filter: /^react(\/jsx-runtime|\/jsx-dev-runtime)?$/ }, (args) => ({ path: args.path, namespace: APP_REACT }));
      build.onLoad({ filter: /.*/, namespace: APP_REACT }, (args) => ({
        contents: `module.exports = globalThis[${JSON.stringify(PLUGIN_API_GLOBAL)}].${args.path === "react" ? "React" : "jsx"};`,
        loader: "js",
      }));
      build.onResolve({ filter: /^react-dom(\/.*)?$/ }, (args) => ({
        errors: [{ text: `"${args.path}": a plugin draws with the app's React and its dialogs with ui.Modal; it brings no react-dom of its own.` }],
      }));
    },
  };
}

/** The manifest, read and checked for what would stop the app taking it. */
export function readManifest(root) {
  const file = path.join(root, MANIFEST);
  let manifest;
  try {
    manifest = JSON.parse(fs.readFileSync(file, "utf8"));
  } catch (err) {
    throw new BuildError(fs.existsSync(file) ? `${MANIFEST} is not valid JSON: ${err.message}` : `There is no ${MANIFEST} in ${root}.`);
  }
  if (typeof manifest.id !== "string" || !PLUGIN_ID_PATTERN.test(manifest.id)) {
    throw new BuildError(`${MANIFEST}: "id" must be lowercase words joined by hyphens, like "dice-tray".`);
  }
  for (const key of ["name", "version", "minAppVersion", "author", "description"]) {
    if (typeof manifest[key] !== "string" || !manifest[key].trim()) throw new BuildError(`${MANIFEST}: "${key}" is missing.`);
  }
  if (!manifest.client && !manifest.server) throw new BuildError(`${MANIFEST}: a plugin has a "client" half, a "server" half, or both.`);
  for (const key of ["client", "server", "styles"]) {
    const name = manifest[key];
    if (name === undefined) continue;
    if (typeof name !== "string" || !/^[\w.-]+$/.test(name) || name.startsWith(".")) {
      throw new BuildError(`${MANIFEST}: "${key}" is a file name at the package's root, like "${key}.js".`);
    }
  }
  if (manifest.mounts?.length && !manifest.server) throw new BuildError(`${MANIFEST}: "mounts" are served by a server half, and there is no "server".`);
  if (manifest.pages?.length && !manifest.client) throw new BuildError(`${MANIFEST}: "pages" are drawn by a client half, and there is no "client".`);
  return manifest;
}

/** `src/<name without extension>.<one of SOURCE_EXTENSIONS>`. */
function sourceOf(root, builtName, key) {
  const base = path.join(root, "src", path.parse(builtName).name);
  const found = SOURCE_EXTENSIONS.map((ext) => base + ext).find((f) => fs.existsSync(f));
  if (!found) throw new BuildError(`${MANIFEST} names "${builtName}" as its ${key}, and there is no src/${path.parse(builtName).name}.tsx, .ts, .jsx or .js to build it from.`);
  return found;
}

function listFiles(dir, prefix = "") {
  if (!fs.existsSync(dir)) return [];
  return fs.readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
    const rel = prefix ? `${prefix}/${entry.name}` : entry.name;
    return entry.isDirectory() ? listFiles(path.join(dir, entry.name), rel) : [rel];
  });
}

/**
 * Build `root` into `root/dist`. Answers the files the package holds and where the zip is.
 * `minify` for a release; off by default, so what an author ships can be read.
 */
export async function buildPlugin({ root = process.cwd(), minify = false, out = path.join(root, DIST) } = {}) {
  const manifest = readManifest(root);
  fs.rmSync(out, { recursive: true, force: true });
  fs.mkdirSync(out, { recursive: true });
  const esbuild = await import("esbuild");
  const common = { bundle: true, format: "esm", minify, logLevel: "silent", absWorkingDir: root, legalComments: "none" };
  const run = async (options) => {
    try {
      await esbuild.build({ ...common, ...options });
    } catch (err) {
      const first = err.errors?.[0];
      const where = first?.location ? ` (${first.location.file}:${first.location.line})` : "";
      throw new BuildError(first ? `${first.text}${where}` : String(err.message ?? err));
    }
  };

  if (manifest.client) {
    await run({
      entryPoints: [sourceOf(root, manifest.client, "client")],
      outfile: path.join(out, manifest.client),
      platform: "browser",
      target: "es2022",
      jsx: "automatic",
      jsxImportSource: PACKAGE,
      plugins: [apiFromHere("client")],
    });
  }
  if (manifest.server) {
    await run({
      entryPoints: [sourceOf(root, manifest.server, "server")],
      outfile: path.join(out, manifest.server),
      platform: "node",
      target: "node22",
      plugins: [apiFromHere("server")],
    });
  }
  if (manifest.styles) {
    const source = path.join(root, "src", manifest.styles);
    if (!fs.existsSync(source)) throw new BuildError(`${MANIFEST} names "${manifest.styles}" as its styles, and there is no src/${manifest.styles}.`);
    await run({ entryPoints: [source], outfile: path.join(out, manifest.styles), loader: { ".css": "css" } });
  }
  if (fs.existsSync(path.join(root, ASSETS))) fs.cpSync(path.join(root, ASSETS), path.join(out, ASSETS), { recursive: true });
  fs.writeFileSync(path.join(out, MANIFEST), JSON.stringify(manifest, null, 2) + "\n");

  const files = listFiles(out).sort();
  const zip = path.join(out, ZIP);
  fs.writeFileSync(zip, zipFiles(files.map((name) => ({ name, data: fs.readFileSync(path.join(out, name)) }))));
  return { manifest, files, zip };
}

/**
 * **The server half of a Dahlia plugin** (`@dahlia/plugin-api/server`).
 *
 * It runs in a Node process of its own that the app starts, never in the app's server. Node's
 * permission model walls it: it reads its own folder, writes only `<folder>/data`, starts no program
 * but the ones its manifest pins, and its environment is empty. It talks to the app over one channel,
 * and everything it needs from the app is in `ctx`. Every request to its routes says who is asking,
 * as the app decided it.
 *
 * ```ts
 * import { defineServerPlugin } from "@dahlia/plugin-api/server";
 *
 * export default defineServerPlugin({
 *   async fetch(request, caller, ctx) {
 *     return Response.json({ hello: caller.door });
 *   },
 * });
 * ```
 *
 * The app's own channel (`lib/plugins/channel.ts` in the app) is checked against these types, so
 * what is written here is what the app hands over.
 */
import type { PluginSettings } from "./manifest";

/** Who is asking, as the app decided it — never as a header said it. */
export type PluginCaller = {
  /** `private`: one of the reader's own devices. `public`: a guest, on a public mount. */
  door: "private" | "public";
  /** The library's owner, on the private door only. */
  owner: string | null;
  /** A `Room`-scheme credential the request carried (`Authorization: Room <token>`), whichever door. */
  credential: string | null;
  /** The address the request came from, or null where nothing named one (never file a decision under null). */
  address: string | null;
  /** The request came from the reader's own computer itself, not their WiFi or the tunnel. */
  thisComputer: boolean;
};

/** A program the app started for the plugin. */
export type PluginRunInfo = { run: string };

/** What the server half is handed with every call. */
export type PluginServerContext = {
  id: string;
  /** Its folder: everything it shipped. Readable, never writable. */
  dir: string;
  /** `<dir>/data`, the one folder it may write. */
  dataDir: string;
  /** Its settings as the card saved them, every declared key present and in range. */
  settings: PluginSettings;
  /** A line in the app's console, under the plugin's name. */
  log(line: string): void;
  /**
   * Start a program its manifest pins (`programs`: this platform, the pinned SHA-256, checked at
   * every start). Refused otherwise, in a sentence. Stopped with the plugin.
   */
  run(
    file: string,
    args?: string[],
    onOutput?: (stream: "stdout" | "stderr", text: string) => void,
    onExit?: (code: number | null) => void
  ): Promise<PluginRunInfo>;
  kill(run: string): Promise<void>;
  /** The port the app's server answers on, or null before it has answered anything. */
  serverPort(): Promise<number | null>;
  /** Keep the app's server listening on the loopback until released (a program that reaches it at 127.0.0.1). */
  holdLoopback(): Promise<void>;
  releaseLoopback(): Promise<void>;
  /** Spend one of this key's attempts: whether there was one left, and when the next will be. */
  rateLimit(key: string): Promise<{ allowed: boolean; retryAfterSecs: number }>;
  /**
   * **Tell the app every seat you have handed out**, whole, replacing the last list. The app's network
   * guard reads seats on every request and cannot wait for your answer, so you tell it instead. A
   * public request whose credential holds a seat is listed on the reader's Network screen (where Kick
   * calls your `kickSeat`), and may send up to the seat's `bodyBytes`. Send it again whenever a seat
   * comes or goes; an empty list seats nobody. Your list is forgotten when your server half stops.
   */
  setSeats(grants: PluginSeatGrant[]): Promise<void>;
  /**
   * **Whether a budget of attempts has room** (`budget` per quarter hour, at most the app's plugin
   * budget), asked without spending. Spend with `noteAttempt` only when the attempt counts against
   * the caller — a wrong guess, a new seat — so a caller who gets it right pays nothing.
   */
  attempts(key: string, budget: number): Promise<{ allowed: boolean; retryAfterSecs: number }>;
  noteAttempt(key: string): Promise<void>;
  /** **A name a person goes by, made fit to show**, by the app's own rule — what every screen of it draws. */
  playerName(raw: string | null): Promise<string>;
};

/** A seat you handed out (`ctx.setSeats`). */
export type PluginSeatGrant = {
  /** The `Room`-scheme credential that holds it (`Authorization: Room <token>`). The app keeps only its hash. */
  credential: string;
  /** Where it is good: a path under your public address, `<mount>/<more…>` (`"room/ABCDEF"`). */
  scope: string;
  /** Your own name for the seat, handed back to `kickSeat`. */
  seat: string;
  /** What a seated write may send: bytes, or `"library"` (the app's own ceiling). Absent: the mount's `publicBodyBytes`. */
  bodyBytes?: number | "library";
};

/** What the card says about the plugin now, in a line. */
export type PluginStatus = {
  line: string;
  tone: "idle" | "ok" | "busy" | "warn";
  /** For an action's `when`. */
  running: boolean;
  /** What switching it off or removing it would end, asked before either; null for nothing. */
  offEnds?: string | null;
};

/** A seat, as the app hands it back to `kickSeat`. */
export type PluginSeat = { scope: string; seat: string };

/**
 * **What `server.js` default-exports.** Every member is optional. A member that throws an `Error`
 * fails the command with its message, which the card shows as it stands — so write a sentence.
 */
export type PluginServerHalf = {
  /** Put what it needs in `ctx.dataDir`. */
  install?(ctx: PluginServerContext): unknown;
  /** Undo anything it did outside its folder (the folder is deleted after). */
  uninstall?(ctx: PluginServerContext): unknown;
  /** Switched on, or the app started with it on. */
  start?(ctx: PluginServerContext): unknown;
  /** Switched off, or before removal. */
  stop?(ctx: PluginServerContext): unknown;
  /** Its settings changed. */
  configure?(ctx: PluginServerContext, before: PluginSettings): unknown;
  /** One of its declared `actions` was pressed. */
  action?(ctx: PluginServerContext, action: string): unknown;
  status?(ctx: PluginServerContext): PluginStatus | Promise<PluginStatus>;
  /**
   * **A request to one of its mounts.** The URL's path is `/<mount>/<rest…>` with the query, on a host
   * that means nothing. No cookie and no `Authorization` reach it: `caller` says who asked. A long
   * poll is simply a late answer.
   */
  fetch?(request: Request, caller: PluginCaller, ctx: PluginServerContext): Response | Promise<Response>;
  /** Remove the guest in this seat, as your own Kick would: the reader pressed Kick on its Network row. */
  kickSeat?(at: PluginSeat): boolean | Promise<boolean>;
};

/** Types the server half, and hands it back unchanged. */
export declare function defineServerPlugin<T extends PluginServerHalf>(plugin: T): T;

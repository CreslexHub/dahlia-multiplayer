/**
 * **`@dahlia/plugin-api`** — the client half of a Dahlia plugin, as its author builds against it.
 *
 * Nothing here is the app's code. The app puts one object on a global before it loads any plugin
 * (`global.js`), and this package's runtime hands out its parts. The app's own implementation is
 * typed against these declarations (`lib/plugins/api.ts` in the app), so the two cannot drift: a
 * change on either side that breaks the other fails the app's type check.
 *
 * ```tsx
 * import { Plugin, ui } from "@dahlia/plugin-api";
 *
 * export default class Hello extends Plugin {
 *   onload() {
 *     this.addHeaderAction({ id: "hello", label: "Say hello", icon: "story", onClick: () => ui.showNotice("Hello") });
 *   }
 * }
 * ```
 */
import type * as ReactNamespace from "react";
import type * as JsxRuntime from "react/jsx-runtime";
import type {
  ButtonHTMLAttributes,
  ComponentType,
  InputHTMLAttributes,
  ReactNode,
  SelectHTMLAttributes,
} from "react";
import type { PluginManifest } from "./manifest";

export type {
  PluginAction,
  PluginDownload,
  PluginManifest,
  PluginMountSpec,
  PluginPageSpec,
  PluginPermission,
  PluginProgram,
  PluginReach,
  PluginSettingSpec,
  PluginSettingValue,
  PluginSettings,
} from "./manifest";
export { PLUGIN_ID_PATTERN } from "./manifest";

// The API by area, one file each, all of it re-exported here (`.agents/PLUGIN-PLATFORM.md` §10).
export type { CardLook, CardTone, PluginIcon } from "./graphics";
import type { PluginIcon } from "./graphics";
export type { PluginTool, PluginToolAnswer, PluginToolArg, PluginToolCall, PluginToolCardProps, PluginToolContext } from "./tools";
import type { PluginTool } from "./tools";
export type { PluginAgent, PluginAgentModel, PluginAgentSampler } from "./agents";
import type { PluginAgent } from "./agents";
export type { PluginMacro, PluginPromptBlock } from "./prompts";
import type { PluginMacro, PluginPromptBlock } from "./prompts";
export type { PluginTheme, ThemeBase, ThemeColorToken, ThemeFontToken, ThemeRadiusToken } from "./themes";
import type { PluginTheme } from "./themes";
export type { PluginStoryTag, PluginStoryTagProps } from "./tags";
import type { PluginStoryTag } from "./tags";
export type { PluginHudChip, PluginHudSource } from "./hud";
import type { PluginHudSource } from "./hud";
export type { PluginComposerAction } from "./composer";
import type { PluginComposerAction } from "./composer";
// The app's own capabilities by area (`app.table`, `app.reveal`, `app.turns`…) and every type they
// name, printed from the app's sources (`app.d.ts`; `.agents/PLUGIN-PLATFORM.md` §9).
export type * from "./app";
import type { AppAreas, Chat } from "./app";

// ─── the chat ────────────────────────────────────────────────────────────────

/** One message of a chat, as a plugin reads it. The app's message has more; these are the API. */
export type PluginChatMessage = {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
};

/** A chat, as a plugin reads it. */
export type PluginChat = {
  id: string;
  title: string;
  createdAt: number;
  updatedAt: number;
  worldIds: string[];
  characterIds: string[];
  messages: PluginChatMessage[];
};

/**
 * **What a plugin can hear.** Each is a request somebody made in the app: a turn asked for, a stop,
 * a summary approved. A plugin listening does not answer it; the app does.
 */
export type PluginEvents = {
  PIPELINE_START_REQUESTED: { chatId: string; reason?: string; generation?: string };
  PIPELINE_STOP_REQUESTED: { chatId: string };
  PIPELINE_SKIP_REQUESTED: { chatId: string; agentId?: string };
  AGENT_RUN_REQUESTED: { chatId: string; passId: string; instruction?: string };
  CUSTOM_ACTION_REQUESTED: { chatId: string; action: string };
  CUSTOM_OPTION_REQUESTED: { chatId: string; text: string };
  SUMMARY_APPROVAL_REQUESTED: { chatId: string; messageId: string; text: string };
  SUMMARY_DECLINE_REQUESTED: { chatId: string; messageId: string };
  INTENT_REFUSED: { of: string; reason: string; text?: string; chatId?: string | null };
  /**
   * **Told, not asked** (`events`): a turn the reader started began its work, and ended — the one place
   * that runs a turn says so. A plugin learns what happened; it may not start paid work from it (only
   * the reader's press spends), and it changes the story only through `mutateChat`.
   */
  TURN_STARTED: { chatId: string };
  TURN_ENDED: { chatId: string; stopReason: string };
};
export type PluginEventType = keyof PluginEvents;

/** `this.app`: the app as every plugin shares it. */
export type DahliaApp = {
  chat: {
    /** The chat on screen, or null on the home screen. */
    getActiveChat: () => PluginChat | null;
    getActiveChatId: () => string | null;
    /** Any chat of the library by id, the freshest copy. */
    readChat: (chatId: string) => PluginChat | null;
    /**
     * **Change a chat**, through the same door every edit of the app takes: the change is saved,
     * synced and drawn. The mutator edits a draft; false when the write was not taken (no such
     * chat, or another device writing it).
     */
    mutateChat: (chatId: string, mutator: (draft: PluginChat) => void) => boolean;
  };
  events: {
    /** Listen; the answer stops listening. Hand it to `registerEvent` and unload stops it for you. */
    on: <T extends PluginEventType>(type: T, handler: (payload: PluginEvents[T]) => void) => () => void;
  };
} & AppAreas;

// ─── the places a plugin draws ───────────────────────────────────────────────

/**
 * **Named places a plugin draws into**, with what the screen drawing each hands its component.
 * `C` is the chat type: `PluginChat` for a plugin; the app reads the same places with its own.
 */
export type SlotPropsOf<C> = {
  /** Over every screen. */
  "app.overlay": Record<never, never>;
  /** Over the home screen: the dialogs its doors open. */
  "home.layer": Record<never, never>;
  /** Over a chat screen: the dialogs its header buttons open. */
  "chat.layer": { chat: C | null };
  /** Under the composer. */
  "composer.foot": { chat: C };
  /** At the foot of Chat style. */
  "chatStyle.section": { chat: C | null };
  /** At the foot of Autonomy. */
  "autonomy.section": { chat: C | null };
  /**
   * In a message's action bar, beside Edit and Delete: a small button (`ui.IconButton`) that acts on
   * that message. `messageId` is the take the bar is on.
   */
  "message.actions": { chat: C | null; messageId: string; role: "user" | "assistant" | "system" };
  /**
   * **Your own settings screen**, on your plugin's card under the fields `plugin.json` declares, while
   * it is installed and on. Only your own entry is drawn on your card (`addSettings`).
   */
  "plugin.settings": Record<never, never>;
};
export type SlotProps = SlotPropsOf<Chat>;
export type SlotName = keyof SlotProps;

/** A button in the chat header's right-hand group, beside Settings. */
export type HeaderAction = {
  /** Yours alone: the app files it under your plugin, so it cannot collide with another plugin's. */
  id: string;
  label: string;
  /** One of the header's marks by name (`story`, `characters`, `world`, `memory`, `room`…), a picture of your package, or a component (`graphics.d.ts`). */
  icon: PluginIcon;
  onClick: () => void;
  badge?: number;
  alert?: boolean;
  /** Drawn in the accent: what it opens is live. */
  lit?: boolean;
};

/** A door on the home screen, beside Settings: the sidebar on a desk, the bottom bar on a phone. */
export type HomeDoor = {
  id: string;
  label: string;
  /** The bottom bar's one word. */
  short: string;
  /** As a header button's: a mark by name, a picture of your package, or a component. */
  icon: PluginIcon;
  lit?: boolean;
  onClick: () => void;
};

/** A tab of the Director pane, with what it draws and its unread count. */
export type PaneTab = {
  id: string;
  label: string;
  count: number | null;
  Panel: ComponentType;
};

// ─── the plugin ──────────────────────────────────────────────────────────────

/**
 * **Every client half's default export extends this.** The app constructs it when the plugin is
 * switched on and calls `onload`; switching it off calls `unload`, which takes back everything it
 * added and every listener it registered, then calls `onunload`.
 */
export declare abstract class Plugin {
  readonly id: string;
  readonly manifest?: PluginManifest;
  readonly app: DahliaApp;
  constructor(id: string, app: DahliaApp, manifest?: PluginManifest);
  /** A button in the chat header. The answer takes it away early; unload takes it anyway. */
  addHeaderAction(action: HeaderAction): () => void;
  /** Draws `Component` in the named place. */
  addSlot<N extends SlotName>(name: N, id: string, Component: ComponentType<SlotProps[N]>): () => void;
  /** A door on the home screen. Adding the same id again replaces it. */
  addHomeDoor(door: HomeDoor): () => void;
  /** A tab of the Director pane. Adding the same id again replaces it (a new count). */
  addPaneTab(tab: PaneTab): () => void;
  /**
   * **A tool the models can call** (`tools.d.ts`): its card joins Add block → Tool instructions, and an
   * agent the reader hands it to is told about it and has its calls answered by `tool.answer`. Throws
   * when its tag is one the app already reads. The answer takes it away early; unload takes it anyway.
   */
  addTool(tool: PluginTool): () => void;
  /**
   * **An agent the reader can add** (`agents.d.ts`), offered in Pipeline & Agents → Add an agent under
   * your name. Added, it is the reader's written agent; nothing is added until they press Add.
   */
  addAgent(agent: PluginAgent): () => void;
  /**
   * **A settings screen of your own**, drawn on your plugin's card (the `plugin.settings` place) — for
   * what the manifest's declared fields cannot say. Keep what it sets with `saveData`, or your server half.
   */
  addSettings(Component: ComponentType): () => void;
  /** **A ready-made prompt block** (`prompts.d.ts`) in Add block → Ready-made, under your name. */
  addPromptBlock(block: PluginPromptBlock): () => void;
  /** **A macro** (`prompts.d.ts`), run where a reader writes it in a block. */
  addMacro(macro: PluginMacro): () => void;
  /**
   * **A theme** (`themes.d.ts`) in Settings → Appearance → Theme, beside the app's own, under your
   * name: one of its shipped themes with your colours, faces and corners over it. Throws for a token
   * the app has not got.
   */
  addTheme(theme: PluginTheme): () => void;
  /**
   * **A tag of your own in story text** (`tags.d.ts`), drawn by your component wherever the app draws
   * story text, as it draws its own `<spoiler>`. The text is never changed; the words inside the tag
   * are what is drawn once you are removed.
   */
  addStoryTag(tag: PluginStoryTag): () => void;
  /**
   * **Chips in the HUD over the composer** (`hud.d.ts`), after the app's own HUD states and drawn as
   * they are. Adding the same id again redraws them.
   */
  addHudChips(source: PluginHudSource): () => void;
  /**
   * **A row in the composer's menu** (`composer.d.ts`), after the app's "Attach a file", drawn as it
   * is and run when the reader presses it.
   */
  addComposerAction(action: PluginComposerAction): () => void;
  /**
   * **A page of your own** at `/plugin?at=<id>/<path>`, one your manifest declares (`pages`). A
   * `public` page is how a guest with nothing installed reaches you: the app loads your client half for
   * them when they open it.
   */
  addPage(path: string, Component: ComponentType): () => void;
  /**
   * **Stay loaded in this tab across its reloads**, whatever the reader's switch says (a guest seated
   * at a table, whose tab reloads on another screen). `false` lets go.
   */
  keepAwake(on: boolean): void;
  /** **This tab no longer needs you** (a guest who left): unloaded here unless the reader's switch has you on. */
  rest(): void;
  /** An unsubscribe (from `app.events.on`, a store), run at unload. */
  registerEvent(unsubscribe: () => void): void;
  /** Any teardown, run at unload. */
  registerCleanup(cleanup: () => void): void;
  /** What `saveData` kept on this device, or null. Each plugin has its own. */
  loadData(): Promise<Record<string, unknown> | null>;
  saveData(data: Record<string, unknown>): Promise<void>;
  /**
   * **A request to this plugin's own server half**: `path` is under its mounts (`"hello/greet"` is
   * `/api/plugins/<id>/hello/greet`). Works on every device the app runs on, which a bare `fetch`
   * does not. A path that leaves the plugin's own routes is refused.
   */
  fetchMount(path: string, init?: RequestInit): Promise<Response>;
  abstract onload(): Promise<void> | void;
  onunload(): Promise<void> | void;
  /** Called by the app. */
  unload(): void;
}

// ─── the kit ─────────────────────────────────────────────────────────────────

export type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost" | "danger" | "subtle";
  size?: "xs" | "sm" | "md" | "lg";
};
export type IconButtonProps = ButtonProps & { label: string; shape?: "square" | "round" };

export type SegmentedProps<T extends string> = {
  value: T;
  options: readonly { id: T; label: string }[];
  onChange: (id: T) => void;
  ariaLabel?: string;
  disabled?: boolean;
  /** Under its own label on a line of its own: fills the column on a phone. */
  fill?: boolean;
  size?: "sm" | "md";
  className?: string;
};

export type ModalProps = {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  subtitle?: ReactNode;
  icon?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  headerActions?: ReactNode;
  width?: string;
  keepOnBackdropClick?: boolean;
  padded?: boolean;
  /** How it grows on a desk: `none` keeps its size, `vertical` takes the height, `fullscreen` the screen. */
  stretchMode?: "none" | "vertical" | "fullscreen";
};

export type SwitchProps = {
  checked: boolean | "mixed";
  onChange: (value: boolean) => void;
  label: string;
  disabled?: boolean;
  labelVisible?: boolean;
  id?: string;
  labelledBy?: string;
  /** The track's colour when on. */
  accent?: "teal" | "amber" | "violet" | "sky";
};

export type SettingToggleProps = {
  icon?: ReactNode;
  label: string;
  sub: string;
  checked: boolean;
  onChange: (value: boolean) => void;
  locked?: boolean;
  action?: ReactNode;
  /** The track's colour when on. */
  accent?: "teal" | "amber" | "violet" | "sky";
};

/**
 * **The app's own controls.** Use these rather than drawing your own: they carry the app's look,
 * its theme and its touch targets, and the app's stylesheet styles them. The app's stylesheet
 * does *not* style class names it has never seen, so a utility class of your own draws nothing:
 * your own look goes in your `styles.css`.
 */
export type PluginUi = {
  Button: ComponentType<ButtonProps>;
  IconButton: ComponentType<IconButtonProps>;
  TextField: ComponentType<InputHTMLAttributes<HTMLInputElement>>;
  Label: ComponentType<{ children: ReactNode; hint?: string; htmlFor?: string }>;
  Select: ComponentType<SelectHTMLAttributes<HTMLSelectElement>>;
  Segmented: <T extends string>(props: SegmentedProps<T>) => ReactNode;
  Hint: ComponentType<{ text?: string; className?: string; tone?: "hint" | "warning" }>;
  Modal: ComponentType<ModalProps>;
  Section: ComponentType<{ icon: ReactNode; title: string; action?: ReactNode; children: ReactNode }>;
  SettingToggle: ComponentType<SettingToggleProps>;
  Switch: ComponentType<SwitchProps>;
  /** A short notice at the foot of the screen. */
  showNotice: (message: string) => void;
};

// ─── the whole ───────────────────────────────────────────────────────────────

/** What the app puts on the global, whole. */
export type DahliaPluginApi = {
  version: number;
  Plugin: typeof Plugin;
  React: typeof ReactNamespace;
  jsx: { jsx: typeof JsxRuntime.jsx; jsxs: typeof JsxRuntime.jsxs; Fragment: typeof JsxRuntime.Fragment };
  ui: PluginUi;
  /** The app, whole: `this.app` in a plugin, and `app` for any module of it. */
  app: DahliaApp;
};

/** The app's React. Import it from here, never from `react`: a second copy breaks every hook. */
export declare const React: typeof ReactNamespace;
export declare const ui: PluginUi;
/** The app (`this.app`), for a module of the plugin that is not the plugin itself. */
export declare const app: DahliaApp;
/** The API version of the app the plugin is running in. */
export declare const apiVersion: number;

/**
 * **The app's own types, as a plugin sees them** — generated from the app's sources by
 * `scripts/plugin-api-types.mjs`. Do not edit: `npm run plugin-api-types` writes it again, and the
 * app's tests fail while it differs from what the app hands over.
 *
 * Every area of the API (`app.table`, `app.reveal`, `app.turns`…) is typed `App<Area>` below, and
 * every type an area's members name is declared here, as the app declares it.
 */

import type * as React from "react";

/**
 * **A new agent in the loop, as a tag proposes it** (`<agent_add>`, `.agents/history/ROUND-2026-09-28.md`
 * §4.3). The reader approves it, as a new agent always has been.
 *
 * Read leniently, like every other tag here: `runs` and `every` arrive as the model wrote them and
 * `STATE_EVENT_KINDS.agent_add.validate` says what is wrong with them, so a fluffed attribute is
 * reported back rather than silently defaulted into an agent that does something else. The body is
 * the new agent's instructions.
 */
export type AgentAdd = {
  type: "agent_add";
  name: string;
  /** One line on what it is for — its card's, and what `{{agents}}` shows an agent choosing whom to call. */
  description?: string;
  /** When it runs: `player`, `reply`, or the agent it runs right after (`RUNS_WORDS`). */
  runs: string;
  /** Turns between runs; `NaN` when the attribute was not a number. 0 is "only when called". */
  every: number;
  /** Where its words go, spelled as the output box spells it. Absent is nowhere, or the message in the reply. */
  output?: string;
  tools: string[];
  /**
   * **What it reads: import paths, one card each**, in place of the shipped set — each where its
   * kind ships, so the transcript still comes last and the Input card after it. Absent keeps the
   * shipped set; empty reads only what it is handed.
   */
  reads?: string[];
  /**
   * The states this agent keeps an eye on, by id — what the state editor draws a badge from,
   * so a reader looking at a number can see which agent is minding it.
   */
  watches: string[];
  prompt: string;
};

/** Agent ids are free-form so user-defined agents need no code change. */
export type AgentId = string;

/**
 * **How an agent's part of this turn ended, where it did not simply finish** — the progress box's
 * dot for it. An agent of the turn that is no longer running and has none of these finished.
 */
export type AgentOutcome = "failed" | "stopped" | "skipped";

/** **A written agent taken out of the loop** (`<agent_remove>`); one that ships is switched off instead. */
export type AgentRemove = {
  type: "agent_remove";
  agent: string;
};

/**
 * **One run of one agent, about one message** — what the Inspector draws and what
 * `{{output::…}}` reads back.
 *
 * It was `agentLogs: Record<agent, { raw, thinking, output }>`, one slot per agent per message,
 * so a second run on the same message overwrote the first and a hand run's note was never kept:
 * the reader could not see what they had asked, and a rerun erased the run it was a rerun of.
 * A scheduled run still replaces the agent's earlier scheduled run on the message (a retry is
 * the same run again); a hand run is added beside it (`lib/agents/runs.ts`).
 */
export type AgentRun = {
  /** The agent that ran, by id. */
  agent: string;
  /**
   * **This run's name in the call log** — every request the run made is filed under it
   * (`CallRecord.run`), so the Inspector draws a run's requests without matching them up by time.
   * Absent on a run recorded before runs were named.
   */
  id?: string;
  /** When it finished. */
  at: number;
  /** A person asked for this run by name; absent for a run the pipeline scheduled. */
  by?: "hand";
  /** What it was handed for this run: the reader's note, or what a caller gave it. */
  input?: string;
  /**
   * The agent that called this run (`<call_agent>`), by id — absent for a run a person or the
   * schedule asked for. Such a run writes no stamp and starts no follower (D6).
   */
  caller?: string;
  /** Its reply as written, tags and all. */
  raw?: string;
  /** Its reasoning, when the agent is allowed to show it. */
  thinking?: string;
  /**
   * What it handed on, where `raw` is not its reply but a record of its run: the Director's,
   * whose raw is its loop's transcript (reasoning, calls, what came back). `outputOf` reads this
   * before `raw`, so `{{output::directorChat}}` is what the Director said and not how it got there.
   */
  output?: string;
  /**
   * Where its output went, as it was wired when it ran (`destinationOf`). Stored rather than
   * derived because the wiring can change after the run, and the Inspector's "where it went"
   * describes the run, not today's settings.
   */
  to?: string;
};

/**
 * **An agent this chat already has, changed** (`<agent_update>`). `agent` is its id; each other
 * field is a change, absent where it leaves that alone. A written agent may change anything; one
 * that ships only when it runs, how often, where its output goes, and whether it is on (D3).
 */
export type AgentUpdate = {
  type: "agent_update";
  agent: string;
  name?: string;
  description?: string;
  runs?: string;
  every?: number;
  output?: string;
  tools?: string[];
  reads?: string[];
  watches?: string[];
  enabled?: boolean;
  prompt?: string;
};

/** What `ToolCall.aliased` holds: the tag as read, and each argument written under an alias. */
export type AliasesRead = {
  tag?: { wrote: string; read: string };
  args: readonly { wrote: string; read: string }[];
};

export interface AnimationSettings {
  enableEntranceAnimations: boolean;
  enableTypingIndicator: boolean;
  typingSpeedCharsPerSec: number;
  /**
   * How fast a line of narration is typed, when it is typed at all.
   *
   * Its own speed because it is not a person at a keyboard: the story describing a room
   * has no reason to take as long as somebody thumbing out a reply, and at the pace that
   * suits dialogue a long scene beat stalls the whole burst. **0 means instant** — the
   * line simply appears — and the rest after it still runs, so the beat still lands
   * before the next person speaks.
   */
  narratorTypingSpeedCharsPerSec: number;
  enableTypingDelay: boolean;
  interCharacterRestTime: number;
  /**
   * Added to the pause after a bubble, per word of the bubble just sent.
   *
   * A fixed rest says everyone replies at the same distance behind each other however
   * much there was to take in, which is the one thing a pseudo message never does — a
   * three-word line gets answered instantly and a long one does not. 0 turns it off and
   * leaves the fixed rest alone.
   */
  readingRestPerWordMs: number;
  typingRandomVariation: number;
  /**
   * Hand the pace to the reader instead of to a timer.
   *
   * The timings above answer "how long would somebody take to write this", which is the
   * right question only while the reply is still arriving. Once a burst is committed the
   * app is pacing out text it has already got, against a clock that knows nothing about
   * how fast you read — so a long scene either scrolls past or crawls, and the only
   * controls are two sliders you have to guess at. This makes the wait a thing you end.
   *
   * Off is exactly today's behaviour, which is why it ships off.
   */
  continueGate?: boolean;
  /** What a spoken line does once it has landed. */
  dialogueGate?: RevealGate;
  /** The same for a line of prose — a page, where dialogue is a beat. */
  narrationGate?: RevealGate;
  /** Widen the hit area from the button to the whole transcript. */
  continueOnTranscriptClick?: boolean;
  // Continue in the composer is the composer's (`ComposerTuning.continueInComposer`, Settings →
  // Advanced).
}

/**
 * **A Writer's answered tool, rewritten by the reader as plain text** — round 2026-10-07C: *"Lets
 * also make editing past tool tags more intuitive. right now it just feels hard coded. Maybe the
 * user can edit the plain text itself? so that we can apply it to all past tool tags?"*
 *
 * Every answered call is one record (`RollRecord`): the call (`call`, its arguments), what the next
 * turn reads of the answer (`result`, put back in the history's bracketed line by `answerLine`),
 * and for a throw the throw itself (`roll`, which the card draws). The reader edits the first two
 * as the text they are — the call in the chat's own form, the answer in words — and this reads the
 * text back with the real parsers: the tool table's for the call (`readCallText`), the dice's own
 * for a throw's faces (`readThrow`). There were two editors before, a box per face with a total
 * beside them, and a box for a lookup's words; one way now, for every tool.
 *
 * **What a changed call does to its answer**, since a past call is a record and not a request:
 *
 * - **a throw is never thrown again.** Its dice, its target and its modifier are read from the
 *   call, the faces from the answer, and the total and the verdict added up again from them
 *   (`throwFromFaces`). `vs="15"` made `vs="20"` turns a success into a failure on the same face;
 *   `1d20` made `2d20` needs a second face written into the answer. A modifier was read off the
 *   card when the dice were thrown, so the call may keep it or drop it, and its figure is changed
 *   in the answer — a different `mod` names a figure the record never had.
 * - **any other answer stands as it was** unless the reader rewrites it too: a lookup asked again
 *   with other words would be a new question, and answering it would be the app writing the story
 *   past the reader's hand. What the next turn reads is the answer, so it is the answer that
 *   changes what it reads.
 *
 * **Telling the truth.** A throw's answer is said again from the numbers, whatever was typed around
 * them (the verdict, a natural roll, the sum beside a total set by hand) — so it never adds up to a
 * number it does not show; the half before the arrow is kept exactly as the model was sent it while
 * the call still says the same thing there. And the record wears `edited`, which the card says, so
 * it never claims the dice or a card said something they did not.
 */
export type AnswerEdit = {
  /** The call as the reader left it, or undefined when they did not touch it. */
  call?: string;
  /** What the next turn reads, as the reader left it. */
  result: string;
};

/** A kind its own switch settles: carded (`!autoApply`), and not one that always asks the reader. */
export type AnsweredKind = {
  [K in keyof KindTable]: KindTable[K] extends { approval: "setting"; autoApply: false } ? K : never;
}[keyof KindTable];

/**
 * What a single chat may say about its own canvas.
 *
 * Everything here is an override of the app record above, and `"inherit"` is a real stored
 * value rather than an absent key — an override you cannot see is the mystery AGENTS §12
 * objects to, and `undefined` cannot be told apart from "never written".
 *
 * Interface scale is deliberately *not* here. It is an accessibility lever for the whole
 * application, and a chat that shrank the UI would be a chat you could not read the settings
 * of.
 */
export interface AppearanceSettings {
  /** Message prose only — the app's own chrome follows `AppAppearance.fontScale`. */
  fontSize: FontSizeOption;
  /** A font the reader added that is no longer on the list reads as "inherit" (`resolveAppearance`). */
  fontFamily: FontChoice | "inherit";
  bubbleDensity: BubbleDensityOption;
  /**
   * How wide a picture on a line is drawn until it is pressed. The ceiling is the bubble's own
   * max width — a press grows a picture to it and a second press puts it back.
   */
  pictureSize: PictureSizeOption;
  /** A data URL, or "" for none. */
  backgroundImage: string;
  /** How far the canvas is dimmed over the image, 0–1. */
  backgroundDim: number;
  /** Blur radius over the image, in px. */
  backgroundBlur: number;
  /** Crop/zoom for the background, same shape as a portrait's. Absent = plain cover. */
  backgroundTransform?: ImageTransform;
  /**
   * There is **no `expressionAvatars` here**, and its absence is the point.
   *
   * It was "draw the ranked face on the bubble", filed beside `bubbleDensity` on the
   * reasoning that running the ranking and drawing its answer are two questions — one costs
   * an inference, the other is taste. In use that was a third switch for one feature
   * (Appearance, Settings → Retrieval, and the retrieval hub's own deck), and the state it
   * bought — rank every line and then draw the portrait anyway — is one nobody wants: the
   * ranking's only output *is* the picture. `enableExpressions` decides both now. The three
   * fields below are what is left, and every one of them is genuinely about drawing.
   */
  /** The avatar's shape and size. `FACE_GUIDES` is the crop stage's half of this. */
  expressionAvatarSize?: ExpressionAvatarSize;
  /**
   * How many bubbles a large avatar stands beside, 2–5.
   *
   * Ignored by the circle, which is about as tall as a line of text and never reached past
   * its own row. See `avatarBox` for why the large one has to.
   */
  expressionAvatarSpan?: number;
  /**
   * Which bubble of a speaker's run stands beside the picture — the first, or the last (as
   * Messenger does). The name and the time stay on the first either way. `portraitRowOf` is
   * the rule, and it is the only reader.
   */
  expressionAvatarAt?: PortraitPlacement;
  /** The ring round the picture: none, the theme's, or a colour of the reader's (`portraitRing`). */
  expressionAvatarBorder?: PortraitBorder;
  /**
   * A pulsing dot on a picture whose face is still being chosen.
   *
   * The one state the picture cannot show by itself: a bubble waiting for its ranking and a
   * bubble whose ranking picked the portrait draw the same image, so "is it working" and
   * "that is the answer" look identical. Default on — it can only appear while a ranking the
   * reader asked for is running.
   */
  expressionActivityDot?: boolean;
  /**
   * How quoted speech, `*…*` and `**…**` are drawn in the story's bubbles — a colour of the
   * reader's and whether each is bold or slanted. A kind absent is drawn as it always was
   * (`TEXT_MARKS`, read through `textMarkOf`).
   */
  textMarks?: Partial<Record<TextMark, TextMarkStyle>>;
}

/**
 * **What "apply without asking" is answered for: each carded kind, and each action** — the keys of
 * `ChatSettings.autoApprove`, read off the two tables above so a new kind arrives with its key.
 *
 * It was one answer per tool, and one tool raises several kinds: States defines a state, moves one,
 * hands one over and links two cards. The owner (2026-10-30): *"there should be a way to refine the
 * permission scope even more precisely."* So the stored fact is the kind's, and a tool's row on
 * Autonomy is drawn from its kinds' answers (`approvalKeysFor`), never stored beside them.
 */
export type ApprovalKey = AnsweredKind | DirectorAction["type"];

export type ArcAdd = {
  type: "arc_add";
  arcType: "style" | "major" | "minor";
  title: string;
  isSpoiler: boolean;
  content: string;
  status?: "ongoing" | "closed";
  /** The arc to file this under, by title or id — `resolveArcTarget` answers which. Absent is top level. */
  parent?: string;
};

export type ArcUpdate = {
  type: "arc_update";
  id: string;
  content: string;
  action?: "edit" | "delete";
  title?: string;
  arcType?: "style" | "major" | "minor";
  isSpoiler?: boolean;
  status?: "ongoing" | "closed";
  /** Re-file under this arc; `""` is "to the top level"; absent leaves it where it is. */
  parent?: string;
  /** The card's in-prompt switch, the same one the Story manager draws. Absent leaves it. */
  enabled?: boolean;
};

/**
 * One thing the player has set up and not yet sent.
 *
 * Two kinds, and the second is not the fork this used to have. It held `StateDelta | ItemDelta`
 * — one shape for a number and another for a thing — and every reader had a branch in it for no
 * reason it could name; a thing is a state, so spending an arrow and taking a wound are the same
 * operation. That collapse stands. `StateUpdate` is here because *setting* is genuinely not
 * *moving*: a flag going on and a list gaining an entry have no delta to be, and the queue's
 * shape is what tells the two apart.
 */
export type ArmedAction = StateDelta | StateUpdate;

/**
 * **What one line may carry** — this chat's, from Settings → Composer (`composer`):
 * how many pictures and documents, the largest file read at all (a bound on the *reading*: a
 * document's text is capped below it, and this only stops a stray video being pulled into memory
 * to find that out), and the most text one document may carry. A file past that is refused with
 * its length rather than cut: a document that silently lost its second half would be read as the
 * whole of it.
 */
export type AttachmentLimits = {
  maxPictures: number;
  /** The longest side a picture is kept at, in pixels (`resizeAndCompressImage`). */
  pictureMaxDim: number;
  maxFiles: number;
  maxFileBytes: number;
  maxFileChars: number;
};

/** The tones `components/ui/Surface.tsx` knows how to paint. Named, never a class or a hex. */
export type BadgeTone = "accent" | "neutral" | "positive" | "caution" | "danger";

export type BaseSettings = SamplingParams & {
  appearance?: AppearanceSettings;
  animation?: AnimationSettings;
  contextPolicy: ContextPolicy;
  summaryPolicy: SummaryPolicy;
  /**
   * **The reader's tree of questions the story's memories are filed under** — see `MemoryNode`.
   * A setting rather than chat content: a preset carries it and the new-chat template seeds it,
   * so a reader draws their tree once. Empty is **Flat**, the default and the recommendation:
   * every memory in one place, and no filing request is ever made.
   */
  memoryTree: MemoryNode[];
  /*
   * **Settings → Memory** (`.agents/MEMORY.md` §8) — each read through `memoryPolicy`
   * (`lib/memory/settings.ts`), which settles a stored value outside its bounds.
   */
  /** The Fact Writer writes once its unread span holds this many messages. */
  memoryWriteEvery: number;
  /** Before a Fact Writer run, ask which memories the new messages change (the Classification model). */
  memoryChangeCheck: boolean;
  /** Spans of the story itself kept as memories, cut by the app with no model. */
  memoryPassages: boolean;
  /** How many messages a passage holds. */
  memoryPassageLength: number;
  /**
   * **The Classification model**: the decision model that files the memories and reads them —
   * `provider::model`, spelled as a retrieval model is (`lib/rag/model-ref.ts`). Its card is in
   * Connection beside the retrieval models, and on Settings → Memory.
   */
  memoryClassifierModel: string;
  /** What Close reading reads of the memories when they are read with the fusion: its reach and depth. */
  memoryCloseReading: { reach: CloseReadingReach; depth: number };
  /** Read the memories whenever they are out of date, not only at a send — see `lib/rag/auto-score.ts`. */
  memoryAutoScore: boolean;
  /** Read only memories whose every message has left the history the prompt quotes. */
  memoryForgottenOnly: boolean;
  /** Whether models read the bare fact ("fact-only") or include the Fact Writer's context note ("with-context"). */
  factContextMode: "fact-only" | "with-context";
  /** The most memories read for one reply; past it, a shortlist (`memoryShortlist`). */
  memoryReadCap: number;
  memoryShortlist: MemoryShortlist;
  memoryFiler: MemoryFiler;
  /** How many branches a memory may be filed under: one, or two (§5.2). */
  memoryBranches: number;
  /** A node's answer, gated down the path, at which a memory fits it. */
  memoryFitsAt: number;
  /** Below this best answer, the memory is also filed under Unsure. */
  memorySureAt: number;
  memoryNothingFits: MemoryNothingFits;
  /** How the memories are chosen when they do not all fit the memories' share; nothing is asked when they do. */
  memoryChooser: MemoryChooser;
  /** Every leaf at once, or down the tree with each parent a gate — for filing and the tree chooser alike. */
  memoryTreeAsk: MemoryTreeAsk;
  /** Whether the tree chooser takes the best branch first or each top-level branch in turn. */
  memoryBranchOrder: MemoryBranchOrder;
  /**
   * **Tree vs. Fact Balance**: how much the branch score influences final memory rank, 0 to 1.
   * 0 is memory text only, 1 is branch category only.
   */
  memoryBranchWeight: number;
  writerVisibility?: ModelVisibility;
  storyGuideVisibility?: ModelVisibility;
  stateManagerVisibility?: ModelVisibility;
  optionVisibility?: ModelVisibility;
  directorVisibility?: ModelVisibility;
  imageWriterVisibility?: ModelVisibility;
  /**
   * **Which of a card's six fields reach a prompt, and to whom** — see
   * `lib/context/character-fields.ts`.
   *
   * Chat-wide rather than per-agent, unlike the visibility profiles above it: those answer
   * "may this agent see the cards at all", and this answers what is written *on* a card.
   * A card that says different things to the Director and to the Writer would be two cards.
   */
  characterCardFields?: CharacterCardFields;
  /**
   * **A character's lorebook joins and leaves the chat with them.**
   *
   * A SillyTavern card carries its lore inside itself; importing one lands it as a lorebook the
   * character owns (`Character.lorebooks`). On, switching a character into the chat switches every
   * card under the lorebooks she owns in, and switching her out switches them out (`syncRoster`,
   * the door every roster change goes through). After that each card is its own switch.
   *
   * **It decides what moves, never what is sent.** It used to be read at prompt time, where it
   * added a present character's book beside the roster — so an entry switched out of the chat
   * was sent anyway while its row said "Add to chat". The roster is the one answer now.
   *
   * It was stored as `autoIncludeConnectedWorlds`; the name changed with what it does.
   */
  lorebooksFollowCharacters: boolean;
  /**
   * **Ask every model for a reasoning block before it answers.**
   *
   * The chat-wide value, which every agent inherits and any agent may override — the same
   * arrangement as the sampler and the context limit, resolved by `agentAllowsThinking`.
   *
   * It did not exist. Connection's "Ask for reasoning" sat under a heading reading *"Every
   * request — these ride every request this chat sends, whoever sends it"* and wrote
   * `narratorSettings.allowThinking`: one agent of six. The Director, the State Manager, the
   * Story Guide, the option generator and the summariser went on asking for reasoning blocks
   * from a chat whose reader had switched them off, and the only way to reach them was six
   * separate switches on another tab. A control that names its own scope and then writes
   * something narrower is the shape §13.11 is about, and there was no field for it to write.
   */
  allowThinking: boolean;
  /**
   * **How hard a model is asked to think** while `allowThinking` is on — one of
   * `REASONING_LEVELS`, and `auto` sends nothing, which is what every request sent before this
   * existed and is still the default.
   *
   * A second fact, not a second switch for the first: whether an agent reasons is
   * `allowThinking`, and this is drawn only while that is on. Chat-wide here, per agent on its
   * card, resolved by `agentReasoning`; what each provider is sent for a level is its row's
   * `ReasoningWire` (`lib/ai/reasoning.ts`).
   */
  reasoningEffort: ReasoningLevel;
  streaming: boolean;
  /**
   * **Whether this chat looks at pictures, and how.** One switch and one choice, on the Vision
   * agent's card in Connection — see `ImageSettings`.
   */
  images: ImageSettings;
  /**
   * From `config/chat-modes.ts`, not spelled out here.
   *
   * There were three copies of this union: this line, one in `ChatStyleSelector.tsx` (a
   * component, which is where `turn-speaker.test.js` had to go looking for it), and the picker's
   * own tile list. The table is the one that has labels and explanations attached, so it is the
   * one that survives; the other two are gone.
   */
  narratorMode: NarratorMode;
  /**
   * **Several named voices share one reply**, and the transcript cuts it into a bubble each.
   *
   * This was a fourth `narratorMode`, `pseudo`, labelled "A pseudo message". It was never a way of
   * writing a chat — it was the narrator's mode plus a formatting rule — and holding it as a
   * mode meant the rule could only be had one way. It reads through `pseudoMessageOn`, never
   * directly, because the mode decides whether it is available at all: "everyone writes their
   * own" gives each card its own reply, so there is no one reply to cut up.
   */
  pseudoMessage?: boolean;
  /**
   * **The card that writes a one-voice chat** — the Narrator's, or any card the reader seats.
   *
   * "Just one character" was the one-voice style with a card seated, and its card was
   * `singleCharacterId`, null for none; the Narrator is a card like any other now, so the
   * picker's first row is its id and there is no null (`.agents/AGENT-SYSTEM.md` §9.4). Read
   * through `houseVoiceId`, never directly: where every card takes its own turn the field
   * decides nothing.
   */
  voiceCharacterId: string;
  /**
   * How this story takes turns — **eight rules, and every one of them is a chat fact**
   * (`.agents/TURNS.md` §28; the tables and their sentences are `lib/mic/policy.ts`).
   *
   * The line is identity: **anything naming a person stays live.** None of these name anybody,
   * so a host can set them before anyone has joined and they travel in a preset. Where the host
   * seated people, the window's tallies and the clock name people, and those are the room's.
   *
   * `lib/mic/rules.ts` composes them with the cast and the table into the rules *in force* — a
   * question the screen does not draw decides nothing.
   */
  /** Free for all, or a round of the voices and the people. */
  speakingOrder: SpeakingOrder;
  /** Free for all with several voices: the AI calls the next one, or one is drawn at random. */
  nextVoice: NextVoice;
  /** A round: whether the AI may call, and whether a call weaves back in or moves the round. A person's call is always honoured. */
  roundCalls: RoundCalls;
  /** Between two AI voices: wait for Next turn, pause this many seconds, or carry straight on. */
  betweenVoices: BetweenVoices;
  /** At a table: every player's turn is one window, and the AI answers once it closes. */
  batchPlayers: boolean;
  /** How a batched window closes. */
  batchCloses: BatchCloses;
  /** Lines each player may write in a window; null — no cap. A player who spends them is ready. */
  batchLineCap: number | null;
  /** How long a person's seat, or a batched window, lasts; null — no limit. Never an AI voice's. */
  playerTurnSeconds: number | null;
  /**
   * **The turn loop as the reader arranged it** — cards in order, a card as many times as it
   * should speak in a round, the narrator movable like any of them. Absent until somebody arranges
   * it; a card it has never heard of takes its place at the end (`turnLoopOf`). Names this chat's
   * cards, so it never travels in a preset.
   */
  turnLoop?: TurnCard[];
  showThinkingInUI: boolean;
  /**
   * How a reasoning box is drawn while `showThinkingInUI` is on: folded to its header, a small
   * window that follows the end as it arrives, or open whole (`config/stream-box.ts`). Read by the
   * transcript and the Director pane alike.
   */
  reasoningBox: StreamBoxView;
  /**
   * The same choice for an agent at work in the Director pane — a task it sent or an agent it
   * called: what that run's card shows of what it is writing, and then of what it reported.
   */
  agentStreamBox: StreamBoxView;
  showMessageStats: boolean;
  /**
   * Draw the Writer's tags that became nothing — refused, or unreadable — as cards in the
   * story where they were written (`ToolProblem`). On by default: a reader who granted the
   * Writer a tool and sees nothing happen needs the reason in front of them. Off hides those
   * cards and only those; a proposal card is never hidden.
   */
  showWriterToolErrors: boolean;
  /**
   * Where the Writer's tool cards stand in the transcript, or that they do not.
   *
   * `STORY_TOOL_CARD_PLACEMENTS` is the table. One control with three answers rather than a
   * switch beside a placement, because "not in the story" makes the placement decide nothing —
   * and because the reveal reads the same answer: cards that are not drawn are not paced for.
   */
  storyToolCards?: StoryToolCardPlacement;
  /**
   * Drop a `Name:` the story repeats at the start of a pseudo-message line.
   *
   * The bubble is already labelled with its speaker, so `Elena: Elena: I know.` shows the
   * name twice and there is no way to edit the second one out without editing the line.
   * Display only — the stored line keeps every character it had.
   *
   * Three answers, one field: `shown` draws the line as written; `repeated` drops a leading
   * name only when it is the bubble's own speaker's, so a different name there is still a
   * speaker change and not noise; `hidden` drops every leading `Name:` from every line,
   * which is the reader's "make it so charName: is hidden". It was a switch for the middle
   * answer alone (`hideRepeatedSpeakerNames`), and a second switch for the third would have
   * been two controls whose on-states overlap.
   */
  speakerPrefixes: SpeakerPrefixRule;
  /**
   * Whether a table-mate's draft is drawn as a bubble in the story, or stays above the
   * composer as room presence.
   *
   * A rule about how this chat's transcript is drawn — so it lives here, survives the room
   * and travels in a preset, rather than being live session state on the table (§7). The
   * *other* half is `roomStore.liveTyping`, which is the host's and answers a different
   * question: **what** they are typing, not whether the story shows that they are.
   *
   * Off puts every draft back above the composer. A draft the turn rules would refuse goes
   * there anyway, whatever this says — `composingRows` decides that first.
   */
  playerTypingIndicator: boolean;
  /**
   * How a multi-speaker reply draws a line that carries no `Name:` at all.
   *
   * Those lines are the story rather than a person — see `isProseChunk` — and there is no
   * one right way to show that. On the page with no bubble reads as narration; a bubble
   * with a time and no name reads as the room itself posting; the narrator's own bubble is
   * for chats where the narrator is a character people talk to.
   */
  narrationLineStyle?: NarrationLineStyle;
  /**
   * **The cards whose lines are drawn as prose** — in `narrationLineStyle`, as a line with no name
   * is: a whole turn of theirs, and their named lines in a pseudo message. Card ids. Never the
   * reader's own line, whoever's card they wear.
   *
   * It was `narratorLinesAsProse`, the narrator's whole turns alone, and it acted only where the
   * reply arrived whole: in a pseudo message a "Narrator:" line was the Narrator's bubble, and
   * nothing could say otherwise (the owner, 2026-11-05: *"so that Narrator: can also be treated as
   * prose"*). One list, so the narrator's answer is one fact in every mode.
   */
  proseCards: string[];
  /**
   * In a chat one character writes, cut a reply into bubbles at quoted speech.
   *
   * There is one speaker, so the `Name:` rule finds nothing and the whole reply is one
   * bubble — which is what such a chat has always drawn, and why this is off by default. On,
   * the character's spoken lines become their own bubbles and the prose between them is
   * drawn on the page by `narrationLineStyle`. It was `splitDialogueInSingleMode`, named for
   * the style that folded into One voice.
   */
  splitDialogue?: boolean;
  /**
   * Whether a bubble's header carries the time it was sent.
   *
   * A narration style that declines its header hides it either way — the two compose, and
   * `NARRATION_LINE_STYLES`' `time` column is the per-style half of the same question.
   */
  showTimestamps?: boolean;
  /**
   * Which of the two context markers are drawn across the transcript.
   *
   * See `TRANSCRIPT_MARKER_MODES`. Both are diagnostics about the prompt rather than part
   * of the story, and on a long chat they are two rules through the middle of what you are
   * reading — worth having while tuning the window, worth losing while reading.
   */
  transcriptMarkers?: TranscriptMarkers;
  /**
   * Floating chevrons that fade in to pan long or clipped messages, or step between messages.
   */
  showAutoPanChevrons?: boolean;
  /**
   * Where those chevrons stand: against the right edge of the story's area, or beside the
   * transcript's column. See `MESSAGE_NAVIGATOR_ANCHORS`.
   */
  messageNavigatorAnchor?: MessageNavigatorAnchor;
  /**
   * Offer back what Stop discarded.
   *
   * On by default: a burst cut mid-flow is the one destructive thing the animation does,
   * and the offer is the only route back. Off for players who stop bursts routinely and do
   * not want a row appearing under the transcript every time.
   */
  showHiddenReplyNotice?: boolean;
  /**
   * **Per kind of change, and per action: whether it applies without asking** (`true`) or posts a
   * card and waits (`false`) — whichever agent wrote it. Autonomy's one list; `autoApprovesFor` is
   * the one reader, and a key neither this nor the default answers asks. The keys are read off the
   * tables (`ApprovalKey`): every carded kind its switch settles, and each action.
   *
   * It was three levels — a chat-wide switch, a row per agent, a row per agent and tool — then one
   * answer per tool (2026-10-30: *"Just make it a list of tool permissions"*), then, the same day,
   * one per kind: States raises four kinds and *"there should be a way to refine the permission
   * scope even more precisely."* A tool's row is drawn from its kinds' answers, never stored. A
   * summary is a key here too (`summary_proposal`); it was `autoApproveSummaries`, a field of its
   * own beside the map that answered every other card.
   */
  autoApprove: Partial<Record<ApprovalKey, boolean>>;
  contextLimitTokens: number;
  stealthToolCalls: boolean;
  /**
   * **Prompt post-processing**, SillyTavern's (`lib/ai/post-process.ts`): the shape every agent's
   * conversation is put into on its way out — as built, merged by role, one system prompt and then
   * alternating, opening on the user too, or one user message. Settings → Advanced → Before it is
   * sent. Chat-wide: every agent's request passes the one door (`buildRequestBody`).
   */
  promptProcessing: PromptProcessing;
  /**
   * **End on a user message**: the line sent after a conversation that would end on a reply, or
   * `false` for none (`closingTurn` in `lib/ai/post-process.ts`). One field, so the switch and its
   * words cannot disagree. Settings → Advanced → Before it is sent.
   */
  closingLine: string | false;
  /**
   * **Stop strings** (`lib/ai/stops.ts`), as the reader wrote them — a line break a real one — sent
   * with every request of an agent that writes the story, `{{user}}` read once per person at the
   * table. Settings → Advanced → Before it is sent.
   */
  stopStrings: string[];
  enableRag: boolean;
  /**
   * How the retrieval query's window is measured. See `RagPolicy.windowMode` — Memory
   * Recall has cut the transcript by messages *or* by tokens since it shipped, and the
   * query that searches it could only be counted in messages.
   */
  ragWindowMode: ChunkMode;
  ragWindowSize: number;
  ragWindowTokens: number;
  /** A reply of several lines is several units of the window. See `RagPolicy.countLines`. */
  ragWindowCountsLines: boolean;
  /** Per-signal multipliers. See RagPolicy.signalWeights. */
  ragSignalWeights: SignalWeights;
  /** Which cards close reading reads. See `CloseReadingReach`. */
  ragRerankReach: CloseReadingReach;
  /** How many: the best N, or N either side of the cut. See RagPolicy.rerankDepth. */
  ragRerankDepth: number;
  /** Rank the cards whenever they are out of date, not only at a send — see `lib/rag/auto-score.ts`. */
  ragAutoScore: boolean;
  ragEmbeddingModel: string;
  ragRerankerModel: string;
  /** The minimum card score: 0 is none, the budget alone decides. See `RagPolicy.threshold`. */
  ragThreshold: number;
  ragFilterCharacters: boolean;
  ragFilterWorlds: boolean;
  /**
   * Whether character and world cards are one row of the allocation (true, default) or two, each
   * with its own share or Auto (false) — `cardBudgetsCombined` is the one reader.
   */
  combineCardBudgets?: boolean;
  /** How many further turns an admitted card stays admitted. 0 is off. */
  ragStickyTurns: number;
  /**
   * How many messages before the newest a card's keys are still read in — SillyTavern's scan depth.
   * See `RagPolicy.keyDepth`.
   */
  ragKeyDepth: number;
  /** What a card linked with one in the prompt has added to its score. See `RagPolicy.linkLift`. */
  ragLinkLift: number;
  /**
   * The floor under a card in a present character's lorebook: 0 off, 1 pinned. See
   * `RagPolicy.lorebookFloor`.
   */
  ragLorebookFloor: number;
  /** The floor under a card the Director has boosted. 1 is "must be in the story". */
  ragDirectorBoostFloor: number;
  ragReplaceRules?: ReplaceRule[];
  ragInheritChatRules?: boolean;
  /**
   * Per-category score configurations. If custom is false or absent, the category inherits
   * from the master rag settings (ragSignalWeights, ragEmbeddingModel, etc.).
   */
  faceScoreConfig?: CategoryScoreConfig;
  memoryScoreConfig?: CategoryScoreConfig;
  filerScoreConfig?: CategoryScoreConfig;
  nodeScoreConfig?: CategoryScoreConfig;
  /**
   * Rank a character's faces against what they just said, and draw the best one.
   *
   * Shares the chat's scoring engine and model — see `ExpressionPolicy`, which reads them
   * rather than offering a second picker — but nothing else about card retrieval: there is
   * no budget to admit against, so no threshold, no topK and no stickiness.
   */
  enableExpressions?: boolean;
  expressionQueryMode?: "dialogue" | "messages";
  expressionWindowSize?: number;
  /**
   * Which line decides the face when one character holds several bubbles in a row — see
   * `ExpressionPolicy["runMode"]`, and `EXPRESSION_RUN_MODES` for what each one means.
   */
  expressionRunMode?: "each" | "first" | "best";
  /** What close reading reads of a character's faces — see `CloseReadingReach`. */
  expressionRerankReach?: CloseReadingTop;
  /** How many of them: the best N. */
  expressionRerankDepth?: number;
  /** A new or edited line is ranked for its face with every signal, paid ones too — see `lib/rag/auto-score.ts`. */
  expressionAutoScore?: boolean;
  stateManagerSettings?: ModelSettings;
  storyGuideSettings?: ModelSettings;
  optionSettings?: ModelSettings;
  summarySettings?: ModelSettings;
  writerSettings?: ModelSettings;
  /** The Director's own overrides — notably `rag.enabled`, its opt-in to retrieval. */
  directorSettings?: ModelSettings;
  /**
   * The four agents that run without a pass scheduling them, and their overrides.
   *
   * Declared for the reason the six above are: `getModelSetting` reads
   * ``settings[`${agentId}Settings`]`` untyped, so these worked at runtime while being
   * invisible to everything that reasons about settings as a *shape* — and `SECTION_OF` in
   * `lib/presets/mapping.ts` is `Record<keyof ChatSettings, PresetSlot>`, so an undeclared key
   * is one a preset neither carries nor deliberately drops. Six agents' models travelled with
   * a preset and these three did not.
   */
  directorSummarySettings?: ModelSettings;
  subagentSettings?: ModelSettings;
  subagentSmartSettings?: ModelSettings;
  /**
   * The card writer's, which is the one a reader is most likely to change.
   *
   * It shipped without one: the panel that runs it named *another agent* whose model to
   * borrow, on the reasoning that a second model picker for an occasional job was one control
   * too many. The reader ruled the other way — *"it usually just inherits the master model.
   * but I can click on it and search up a different model"* — which is what every other agent
   * already offers, through the card in Pipeline & Agents that `runsOnDemand` draws it. The
   * generation panel renders that same card rather than a second control beside it.
   */
  cardWriterSettings?: ModelSettings;
  /**
   * The Vision agent's — the model that looks at a picture for everybody else. Its card is
   * drawn in Connection beside the switch that turns pictures on, and again under "Asked for,
   * not scheduled" in Pipeline & Agents, because it is one setting behind both.
   */
  visionSettings?: ModelSettings;
  /**
   * The Image Writer's — the model that makes a picture when the story asks for one. Its card
   * is beside the Vision agent's in Connection, under the switch that lets the story draw.
   */
  imageWriterSettings?: ModelSettings;
  /**
   * The Fact Writer's — the model that writes the story's facts down (`.agents/MEMORY.md` §4.1). It
   * inherits the master model until its card says otherwise; its card is on Settings → Memory as well
   * as on the loop, one setting behind both.
   */
  factWriterSettings?: ModelSettings;
  /**
   * **What makes the Director compact its own conversation.**
   *
   * The same three ids the story's summariser uses, deliberately: they are the same three
   * answers a reader has — on a count, when the space runs out, or either. What each one
   * *counts* differs, so the labels do, and `SummaryPanel` writes those beside the control
   * rather than in a second table of ids to keep in step (`DIRECTOR_TRIGGERS`).
   *
   * `pressure` is the shipped answer, at the reader's word: *"maybe do an auto-summary
   * whenever the director fills up the context."*
   */
  directorCompactTrigger?: SummaryTrigger;
  /** How many messages in the pane between compactions, when the trigger counts. */
  directorCompactEvery: number;
  /**
   * How many of the Director's own messages stay verbatim behind a compaction.
   *
   * A count of `directorMessages`, not of exchanges. Everything older is replaced in the
   * *packet* by the handover standing for it — never deleted, and never hidden from the pane.
   * The control is Context Master's Director tab, beside its window, because it is the same
   * question that tab already asks about the story: how much raw text goes in.
   */
  directorRawTail?: number | DirectorRawTailSize;
  /**
   * **Whether what the Director looked up stays in its conversation.**
   *
   * A `<read_card>` is answered inside the run and the answer is thrown away with it: the
   * loop's conversation is not stored, only the model's replies and a record of what it read
   * (`DirectorMessage.lookups`). So the Director could read a card, act on it, and next turn
   * face its own reply saying it had checked the card with no card anywhere in the packet.
   *
   * On by default. The answers are already capped where they are produced
   * (`QUERY_ANSWER_CHARS`) and bounded after that by the compaction frontier, which is the
   * same thing that bounds the conversation carrying them — so this adds no unbounded growth
   * that "Kept word for word" beside it does not already govern.
   */
  directorKeepsLookups: boolean;
  /**
   * **Whether the Director's own history drops the calls it no longer holds.**
   *
   * Its conversation is its replies, and a reply that called `<state_update>` teaches the next
   * run that `<state_update>` is a thing it does — whether or not the reader has since switched
   * the tool off. The owner: *"a special setting here to hide any tool calls in its history that
   * it doesn't have permission for / toggled off for."* On, each stored reply is replayed without
   * the calls (and their answers) of tools it is not granted now; off, as written. Set beside
   * the tools themselves, in the Director pane's context menu.
   */
  directorHidesRevokedCalls: boolean;
  /**
   * **Where each agent's output goes**, by agent id: a sink (`chat`, `director` —
   * `OUTPUT_SINKS`) or the name of a variable any block after it reads with `{{output::name}}`.
   *
   * Absent for an agent is its shipped place (`destinationOf`): the reply's last agent writes the
   * message, the Director its pane, everybody else a variable named for itself. The owner: *"In
   * prompt master, below the agent card, we can set the output variable of each agent"* — so a
   * draft agent can write `draft`, a prose agent read `{{output::draft}}` and write the chat.
   */
  agentOutputs?: Record<string, string>;
  /*
   * `toolFormat` stood here — how every agent wrote a tool call, one setting over every card. A tool's
   * card says it now (`PromptBlock.toolFormat`, round 2026-10-30E), and an agent's format is its
   * cards' (`toolFormatOfAgent`); stored values were moved onto the cards once
   * (`scripts/one-off/tool-format-on-cards.ts`).
   */
  promptOverrides?: PromptOverrides;
  /**
   * **Regex** — this chat's find-and-replace rules, in the order they run. See `ReplaceRule`. The one
   * home a rule has: a card had a list of its own too, and the owner took it out (2026-09-16), so a
   * SillyTavern card's `regex_scripts` is carried in `carriedExtensions` and not run.
   *
   * Beside `promptOverrides`, and carried with it by a Prompts preset: a rule decides what the model
   * reads of the history as much as a block decides what it is told. `replaceRulesOf` is the reader.
   */
  replaceRules?: ReplaceRule[];
  pipelineStatusBoxPosition: "top" | "bottom" | "hidden";
  /**
   * **Appearance → Background work**: whether the work going on behind the story — ranking the cards,
   * reading the memories, ranking the faces, refiling — is shown at the top of the chat while it runs
   * (`BackgroundDock`). Off, it is watched only inside the retrieval hub, and a refile still ends in
   * its summary toast.
   */
  showBackgroundWork: boolean;
  /** Ordered list of agent pipeline pass configurations — filled on every read (`normalizePipelinePasses`). */
  pipelinePasses: PipelinePassConfig[];
  /** Active master preset attached to this chat, or null/undefined if on custom settings. */
  presetId?: string | null;
  /**
   * ...and the same pointer per section — which section preset each part of this chat is on.
   *
   * The reader's ask, in two halves: *"each setting modal can have its own preset. We still
   * have the master preset, which also holds the presets that were selected."* This is the
   * chat's half; the master preset's copy of it rides in the standalone bag, so applying a
   * master restores the values **and** the names the pickers show.
   *
   * A pointer, never a source of values: a section preset is applied when it is chosen, and
   * from then on the chat's own settings are the record. Deleting the preset it names leaves
   * the chat exactly as it is with its picker reading "no preset", which is what a `SectionPreset`
   * being gone should mean and is why the picker looks the id up rather than trusting it.
   */
  sectionPresetIds?: Record<string, string | null>;
  /**
   * **Settings → Advanced** — the defaults nothing else reaches, a group per key. Each group is
   * a row table in `config/tuning.ts` and is read through `tuning(settings, group)`, never raw:
   * a stored group may predate one of its fields.
   */
  contextWindow?: ContextWindowTuning;
  composer?: ComposerTuning;
  playerLines?: PlayerLineTuning;
  editors?: EditorTuning;
  toolLoop?: ToolLoopTuning;
  lookupLimits?: LookupTuning;
  webPages?: WebPageTuning;
  summaryLimits?: SummaryTuning;
  directorLimits?: DirectorTuning;
  notebookLimits?: NotebookLimits;
  transcript?: TranscriptTuning;
  runLog?: RunLogTuning;
  memoryLimits?: MemoryLimits;
  /**
   * The lines the app writes into a prompt on its own — a Director's note, the player's spent
   * actions, a Recent Changes line — as templates with `{slots}`. Read through `lineFormatsOf`
   * (`lib/formats/line-formats.ts`), which reads a format that is not a usable one as the shipped.
   */
  lineFormats?: LineFormats;
  /**
   * **What makes a line of a pseudo message somebody speaking** — a pattern the line must open
   * with before its `Name:` (empty for none) and how long a name may run. Settings → Advanced →
   * Spoken lines. Read through `speechRuleOf`, never raw: it decides only while Pseudo message is
   * on, and a stored pattern is compiled there before anything reads by it.
   */
  spokenLines?: SpeechInput;
};

export type BatchCloses = "ready" | "host";

/** Wait for Next turn, carry straight on, or pause this many seconds and then carry on. */
export type BetweenVoices = "wait" | "straight" | number;

/**
 * **A card the Director holds in the story for a few turns** — a floor under it in the
 * Writer's ranking (`lib/director/boosts.ts`). `card` as written; `turns` how long, capped
 * by the validator — absent when the tag named none, and then the chat's own (`boostTurnsOf`).
 */
export type BoostCard = {
  type: "boost_card";
  card: string;
  turns?: number;
};

export type BubbleDensityOption = "compact" | "comfortable" | "spacious";

/** Every built-in account's id. */
export type BuiltinProviderId = keyof Catalog;

/**
 * **The two ways a chat can be written, as one table.**
 *
 * The picker was two levels: three parent tiles, one of which ("multiple characters") had two
 * sub-tiles under it and *silently chose `pseudo`* when you pressed the parent — through
 * `applyMode`, which also resets tool permissions and clears every prompt override. A tile
 * that quietly picks one of its own children and destroys work on the way is the shape §13
 * warns about, and the second level bought nothing: the modes are answers to one question.
 *
 * The stored value `mic_pass` is untouched. Tables in `config/prompts.ts` are keyed by it and
 * MULTIPLAYER.md §6 forbids adding or removing a mode lightly; what changed there was the
 * *label*, and only because the phrase "pass the mic" named two unrelated mechanisms — this
 * mode, and the turn rule a live table runs under. Both are on one screen now, so the phrase
 * belongs to the turn rule and the mode says what it does.
 *
 * ── Why there are three and not four ──────────────────────────────────────────────────────
 *
 * `pseudo`, labelled "A pseudo message", was the fourth. It was never really a way of *writing* a
 * chat — it was one way of writing plus a formatting rule: the reply comes back as several
 * named lines and the transcript cuts it into a bubble each. Everything else about it was the
 * narrator's mode. Holding it as a mode meant the rule could not be had any other way, and the
 * reader wanted exactly that: *"users may want to be able to use the speaker functionality for
 * single characters or even narrator mode."*
 *
 * So it is `chatSettings.pseudoMessage` now, and `pseudoMessage` on a row here says where the rule can
 * be had — which is every row now. It was withheld from `mic_pass` on the reading that each card
 * there takes *its own turn in its own reply*, so there is no one reply to cut up. That reading
 * was about *who writes*, and a pseudo message is about *the shape of what is written*: a card
 * taking its own turn can answer in several short messages and a line of description as well as
 * a narrator can, and a card *called* in a pseudo chat had been doing exactly that all along. The
 * reader: *"for 'everyone writes for themselves' allow it to also have pseudo message."*
 *
 * **What the field was really guarding is `ownTurns`**, and it is a second fact. In a mode where
 * one voice writes the scene, a pseudo message voices every card — they are `Name:` prefixes in
 * that one reply, not authors, and so none of them holds a seat. Where each card takes its own
 * turn, a pseudo message changes the shape of each card's reply and nobody's authorship.
 * `oneReplyVoicesEveryone` is that conjunction, and it is what the turn order reads.
 *
 * ── Why there are two and not three ──────────────────────────────────────────────────────
 *
 * "Just one character" (`single`) was the third: one card writing in the first person, chosen
 * in a picker drawn under that tile alone. It was the first row here with a different card
 * seated — the same one voice writing every AI turn, the same call taking a turn away from it,
 * the same pseudo message on top — and holding it as a style put the *card* on the mode axis:
 * every reader of the style branched on `single` to find the card, and the Narrator's card could
 * not be seated through the control Ana's was. The owner: *"merge 'one narrator' and 'solo
 * character' since they mean the same thing. So a user can chose between one voice vs multiple
 * calls."* The card is `chatSettings.voiceCharacterId`, whose first row is the Narrator
 * (`.agents/AGENT-SYSTEM.md` §9.4); a stored `single` was made `narrator`, its card carried, once,
 * by the one-off upgrade.
 */
export declare const CHAT_MODES: readonly [{ readonly id: "narrator"; readonly label: "One voice"; readonly sub: "One card writes every AI reply: the Narrator or a character you pick. Call someone to hand them a turn."; readonly pseudoMessage: true; readonly ownTurns: false; }, { readonly id: "mic_pass"; readonly label: "Everyone writes their own"; readonly sub: "Each character replies in turn. One model call per voice."; readonly pseudoMessage: true; readonly ownTurns: true; }];

/**
 * **When *Calls an agent* calls on its own** — by hand (Run, and absent), as a memory lands at the
 * node, every `every` replies, or each time the node comes to hold `count` memories (`count` again
 * at twice that, and so on).
 */
export type CallAgentWhen = { when?: "hand" | "filed" | "reply" | "count"; every?: number; count?: number };

/**
 * **A call to another agent: run it now, and read what it wrote** (`.agents/history/ROUND-2026-09-28.md` §4.2).
 *
 * Not a `StateOrchestrationEvent` and not a `DirectorAction`, because it proposes nothing itself:
 * those end in something the reader approves or the story carries, and this ends in the called
 * agent's words, which the caller reads. What the called agent proposes is carded as any run of it
 * is, credited to it — that is its run, not this tag's. A shape of its own keeps it out of
 * `harvestTools`.
 *
 * It was `<spawn_subagent>`, a throwaway helper on one of two tiers with material handed through
 * four attributes of its own. The helper is a `<task>` now (TOOL-DESIGN.md §4.2), run on a subagent
 * card through this same shape (`task`), and what a call is handed is written the one way any
 * material is written — import paths (`with`), the same words a prompt block uses.
 *
 * - `agent`: whom to call, by id or by name, as written; the answerer finds it (`callableAgents`).
 * - `note`: what this run is asked to do — the body. It arrives at the agent's `{{input}}`.
 * - `with`: import paths, handed over for this run, each fenced at its `{{input}}`.
 * - `role`: the persona it answers in, read by `{{role}}` in its stack.
 * - `id` and `inputs`: a fan-out in one step — a call waits on the ones it names, and is handed
 *   their words; a call another consumes is working, not an answer (`planCalls`).
 */
export type CallRequest = {
  agent: string;
  note: string;
  /** The persona, as written. Empty when the tag named none. */
  role: string;
  /** What the others in this step reach it by. Empty when nothing needs to. */
  id: string;
  /** The ids whose words go into this one's `{{input}}`, in the order written. */
  inputs: string[];
  /** Import paths handed over, in the order written (`characters::user`, `chatHistory::last`). */
  with: string[];
  /**
   * Present when the call is a `<task>` (TOOL-DESIGN.md §4.2): `agent` is the subagent card its
   * `model=` named, and this is what only a task says — the title its card and the status box show,
   * and the tool cards it asked to be handed, as written, for its caller's grant to ceiling
   * (`taskProblem`). Absent on a call to an agent the chat has, which runs with its own stack's tools.
   */
  task?: { title: string; tools: string[] };
};

/**
 * Whether a card's text is in the prompt because it exists, or because it earned it.
 *
 * - `"active"` — always sent, whatever retrieval thinks. The card the story is about.
 * - `"passive"` — retrieval decides when it is on; sent unconditionally when it is off.
 *
 * Absent means passive (`resolveActivation` is the one place that says so). Out of the
 * chat's roster means out of the prompt entirely — there is deliberately no third value
 * for that, because `characterIds`/`worldIds` already carry the fact (§13.2).
 *
 * This replaced two things at once: `roleSetting`'s "active"/"passive" options, which no
 * code ever branched on (only `"user"` is read — the labels were descriptive fiction),
 * and `chatSettings.ragPins`, which was per-chat state for a per-card fact and lived in a
 * debug modal instead of on the card.
 */
export type CardActivation = "active" | "passive";

/** What `resolve` answers, and what the preview needs before it can fetch a card. */
export type CardDownload = { downloadUrl: string; downloadType: CardDownloadType };

export type CardDownloadType = "png" | "json";

/**
 * **The fields a card carries, in the order every editor shows them.**
 *
 * One table, because more than one screen writes these: the chat's character manager, the
 * shelf's card editor, and — since the card writer — the model that fills them in. They were
 * separate copies that happened to agree, which is the shape CLAUDE.md opens with and the one
 * that has cost this repo the most; a field added to one of them silently did not exist in
 * the other.
 *
 * ── `description` is here now, and that is the change ─────────────────────────────────────
 *
 * It used to be excluded, with the reason written into the table: "it is the card's body, and
 * both panes give it a box of its own above these". So the most important field on a card was
 * the one field not in the list of the card's fields — it sat under a heading of its own, six
 * inches from the section named after it, and anything walking the fields (an exporter, a
 * generator, a diff) had to remember it separately. The reader's ruling: *"lets move
 * descriptions into card fields, description should be first though."*
 *
 * It leads, because it is what the model reads first and what a reader writes first.
 *
 * `alternateGreetings` is still not here: it is a `string[]`, so it needs a control rather
 * than a row, and both panes draw it under the table for that reason.
 *
 * ── Not to be confused with `lib/context/character-fields.ts` ─────────────────────────────
 *
 * That table answers *what a card says in a prompt*, and it is a different question with a
 * different answer: it carries `states`, which is not a text box, and it does not carry
 * `firstMes`, `postHistoryInstructions` or `creatorNotes`, which are never sent as card
 * content. The ids overlap because both are keys of `Character`; the lists do not, and
 * merging them would mean one of the two questions getting the other's answer.
 */
export type CardField<K extends string = string> = {
  /** Where it is stored. Also its name in a `<field>` tag, so nothing translates between them. */
  key: K;
  label: string;
  /**
   * How tall the editor draws its box. **One means a single-line field** rather than a
   * one-row textarea: a scrollable box for a word is furniture.
   */
  rows: number;
  /** Under the label, when the field needs saying what it is for. */
  hint?: string;
  placeholder?: string;
  /**
   * **What a model is told when it is asked to write this field**, and the content of the
   * card writer's shipped block for it.
   *
   * On the row rather than in `config/prompts.ts` beside the other prompt text, deliberately:
   * a keyed table over there would be a second list that has to stay in step with this one,
   * and the failure mode is silent — a field with no entry becomes an empty block, which
   * reads as a field the model was simply not told about. The field and how to write it are
   * one fact.
   */
  guidance: string;
  /**
   * **Directions to the model rather than content of the card** — rendered by the
   * `card_instructions` / `card_reminder` slots as instructions to whoever writes it.
   *
   * A guest at a table may write a card's content and never these (`plugins/multiplayer/client/guest-cards.ts`):
   * the narrator's own card carries its identity here, so a guest who could edit it was writing
   * the system prompt of every request the host's key paid for.
   */
  instructs?: true;
  /**
   * **Written for the person using the card, never sent** — the creator's notes. Drawn as a page
   * (HTML, through the reply reader's safe subset) with its text a toggle away, and in a section of
   * its own (`cardFieldSection`).
   */
  forReader?: true;
};

/** What a row on a shelf with no pictures leads with (`Library.glyph`); drawn by `ROW_GLYPHS`. */
export type CardGlyph = "story" | "prompt";

export type CardKind = "character" | "world";

export type CardLink = {
  /** The card at the other end — a character or a world; the id says which once resolved. */
  cardId: string;
  relation: CardRelation;
};

/**
 * Which catalogue a character was imported from.
 *
 * Hand-written as `"chub" | "characterhub" | "botbooru"` until the sites became a table.
 * It is the table's ids now, so a source added there is spellable here without anyone
 * remembering to widen a union — and `"characterhub"`, which was a second name for chub.ai
 * rather than a second site, could not be typed at all.
 *
 * `RemoteCharacterCard` — the normalised search result — lives beside the table for the same
 * reason: it is what a row must produce, so it belongs where the rows are.
 */
export type CardProvider = CardSourceId;

/**
 * **How much of a card or an arc to read, and from where.**
 *
 * No `section` is the *overview* — what the thing is and what sections it has, with a length
 * beside each. That is the shape a decision actually needs: which piece matters, and whether
 * it will fit. `offset` and `limit` then read one piece at a time, and the answer says what is
 * left, because a cut with nothing after it reads as a card that ends there — which is what a
 * blanket cap did, silently, to every card longer than it.
 *
 * All three arrive as the model wrote them (`NaN` for a number that was not one) so the
 * reader can decide rather than a default standing in for a mistake.
 */
export type CardReach = { section?: string; offset?: number; limit?: number };

/**
 * **How one card is bound to another.**
 *
 * Two, because there are only two things a reader ever means: this card *has* that one — its
 * states, its lore, its history are this card's to use — or the two simply belong together
 * and the story should carry both.
 *
 * **"Owned by" is not a third.** Reached from the other end it writes an `owns` link onto the
 * card doing the owning, so there is one home for the fact and the inverse is worked out
 * (`ownersOf`). A relation stored at both ends is two representations of one fact, which is
 * the drift bug AGENTS.md opens with. `with` is symmetric and is stored on whichever card it
 * was added from, for the same reason: one home, read from both sides.
 */
export type CardRelation = "owns" | "with";

/**
 * A row as the table actually holds it.
 *
 * Narrower than `CardSourceRow`, which is the contract a row must *meet*: this one keeps each
 * row's literal `id`, which is what lets `provider` be stamped from the row that produced a
 * card without a cast, and what makes the union below real rather than `string`.
 */
export type CardSource = (typeof SOURCES)[number];

/** The union `types/chat.ts` calls `CardProvider`. Derived, so it cannot disagree. */
export type CardSourceId = CardSource["id"];

/** Why shelf cards asked for whole are not all here: the PC has none of some, or could not be asked. */
export type CardsAway = Exclude<HeldAnswer, "held">;

/**
 * **A reply a retry cut, without its words** — what it takes to stand it back where it stood when
 * the retry writes nothing (`restoreCarriedTakes`): its id, its author, its place in the round.
 *
 * Every field but the take's, its other takes (those are `carriedTakes.variants`), and
 * `stateChanges`, whose state the cut put back.
 */
export type CarriedReply = Omit<Message, keyof MessageTake | "variants" | "stateChanges">;

/**
 * What a question about the cast needs of a chat — and no more, so it can be asked of a chat
 * still being assembled by its reader (`normalizeChat`) as well as of a whole one.
 */
export type CastView = Pick<Chat, "characters" | "characterIds" | "multiplayer" | "chatSettings">;

export type Catalog = typeof PROVIDER_CATALOG;

/**
 * **A pool's own scorer** (faces, the memories read, filing, the tree's branches) — while `custom`,
 * its mix and models over the chat's. A memory pool's mix also chooses its scorer (`scorerOf`,
 * `lib/memory/settings.ts`). Not in it, on purpose: what close reading reads of a pool (each pool's
 * one setting — `expressionRerankReach`, `memoryCloseReading`) and the Classification model's
 * question (the pool's line format): a copy of either here was a second home that drifted.
 */
export type CategoryScoreConfig = {
  custom?: boolean;
  signalWeights?: Partial<SignalWeights>;
  embeddingModel?: string;
  rerankerModel?: string;
  classifierModel?: string;
};

export type Character = {
  id: string;
  name: string;
  description: string;
  image: string | null;
  imageTransform?: ImageTransform;
  /**
   * Faces, ranked each turn against what this character just said.
   *
   * **UI only.** Nothing here reaches a prompt: `buildCharacterText` does not read it, no
   * module on the prompt path imports `lib/expressions/*`, and `tests/unit/expressions.test.js`
   * asserts both. A description is written for a retrieval scorer, not for the Writer,
   * and letting the two share a field is how a note to yourself ends up in the story.
   *
   * Carried rather than defaulted, like `imageTransform`: a character that has never had
   * one stores no key, so every existing chat serialises byte-identically.
   */
  expressions?: Expression[];
  /** Whether the card is always in the prompt, or retrieval's to admit. See CardActivation. */
  activation?: CardActivation;
  isAutoGenerated: boolean;
  isAutoEdited: boolean;
  isNew: boolean;
  /**
   * See `StatefulEntity`. This was `states: StateBag` *plus* `trackerValues`, with the chat
   * holding a schema of packs that decided which numbers existed — two representations of one
   * fact and a table of story genres. One list now, each entry carrying its own type.
   */
  states: EntityState[];

  /**
   * When this character was last written **to the global roster**.
   *
   * Only roster entries carry it, and only the roster reads it: it is what lets a character
   * added on one device and another added on a second both survive the merge, instead of
   * whichever roster was saved last replacing the other whole. A character embedded in a
   * chat leaves it undefined — the chat's own `updatedAt` is the stamp there.
   */
  updatedAt?: number;
  /**
   * **The lorebooks this character owns**, by id — in a chat, `Chat.worldFolders`; on the shelf,
   * world-shelf `LibraryFolder`s. Owning a lorebook owns every lorebook inside it.
   *
   * *"A character that owns a lorebook will be linked with the folder itself."* A link from the
   * character to the book rather than a field on each card naming her (the `World.bookOf` this
   * replaced), because ownership is not membership: a lorebook may belong to nobody (the world's
   * own lore), two characters may share one, and one character may own several — SillyTavern's
   * "additional lorebooks". Membership is the card's `folderId`, one field; this list holds only
   * who owns, which is one edit whichever way it is made.
   *
   * Read by retrieval (`lorebookFloors`), the roster rule (`lorebooksFollowCharacters`), the
   * exports (a character's SillyTavern card carries the cards under these as its book) and the
   * landings, which carry the books with her. Carried, not defaulted: a character who owns none
   * stores no key.
   */
  lorebooks?: string[];
  /** A shelf card's: the chat card it was saved from — see `ShelfOrigin`. */
  savedFrom?: ShelfOrigin;

  // Silly Tavern V1/V2 fields
  personality?: string;
  scenario?: string;
  firstMes?: string;
  mesExample?: string;
  creatorNotes?: string;
  systemPrompt?: string;
  postHistoryInstructions?: string;
  alternateGreetings?: string[];
  chubId?: string;
  cardSource?: CardProvider;
  cardSourceId?: string;
  /**
   * `"user"` marks the player's own character; that is the only value any code reads.
   * The old `"active" | "passive"` arms had zero readers — every consult in the tree is
   * `=== "user"` or `!== "user"` — so a Role select offering them changed nothing. The
   * real in-context fact is `activation`, above.
   */
  roleSetting?: "user";
  /**
   * Free-text labels, for finding a character in a roster that has grown past scanning.
   *
   * Nothing in the app had a tag input before this — `World` had a single free-text category
   * and `Character` had nothing, so a roster of eighty imported cards could only be searched
   * by name. Imported cards often arrive with `topics`, which was fetched and thrown away.
   */
  tags?: string[];
  /**
   * The card's own retrieval keys — the deterministic hand on the ranking. See
   * `RetrievalKey`. Carried, not defaulted, like `expressions`: a card that has none
   * stores no field and serialises byte-identically.
   */
  retrievalKeys?: RetrievalKey[];
  /**
   * Which folder on the shelf holds this card, or absent for the top level — and in a chat, which
   * of the cast's folders (`Chat.characterFolders`), filing that nothing but the manager reads.
   *
   * **On the record rather than as a list on the folder**, and that choice is what decides
   * whether two devices can disagree. A card is one record with one owner, so moving it on
   * the phone and moving it on the desktop is an ordinary last-write-wins on a single
   * record. Membership held as `LibraryFolder.cardIds` would make one *move* into two edits
   * — remove here, add there — which a union merge cannot reconcile, and "in two folders at
   * once" would be a state the types allow. This way it is not representable.
   *
   * Carried, not defaulted: a card that has never been filed stores no key, so every chat
   * and every shelf record that predates folders serialises byte-identically.
   *
   * A card whose folder has been deleted is not lost — `recordsIn` shows an orphan at the
   * top level rather than filtering it out of every view there is. A *world* card's folder is
   * more than filing: it is the lorebook the card is in, and its path is the heading the card is
   * sent under (`World.folderId`). See `lib/library/folders.ts`.
   */
  folderId?: string;
  /**
   * Where the reader dragged this card *within* that folder, and nothing else reads it.
   *
   * Carried, not defaulted, for the same reason as `folderId`: absent means nobody has
   * placed this one, which sorts to the end of its level, so a shelf nobody has arranged is
   * byte-identical to before there was such a thing. `lib/library/ordering.ts` owns it.
   */
  order?: number;
  /**
   * **The card's `extensions` from the file it came in, minus this app's own corner** —
   * SillyTavern's `talkativeness`, `fav`, `depth_prompt` and `world`, and every other app's
   * namespace — so the card goes back out carrying them.
   *
   * Not a copy of the whole card as it arrived: an edited card exporting that would carry what
   * it said before the edits. None of these can be edited here, so carrying them has no such
   * stale copy to worry about. Written only by the importer, read only by
   * `characterToSillyTavern`, under the fields that writer sets itself.
   *
   * Carried, not defaulted: a card made here stores no key.
   */
  carriedExtensions?: Record<string, unknown>;
  /**
   * **The card's own fields from the file it came in that this app does not read** — the author's
   * `creator` credit and `character_version`, V3's `group_only_greetings`, `nickname`, `source` and
   * dates — so the card goes back out saying them. They were dropped at the door, and every export
   * named this app as the card's creator.
   *
   * The same terms as `carriedExtensions`: nothing here can be edited, so nothing goes stale;
   * written only by the importer, read only by `characterToSillyTavern`, under what it writes
   * itself. V3's `assets` are not among them — see `NOT_CARRIED_CARD_FIELDS`.
   *
   * Carried, not defaulted: a card made here stores no key.
   */
  carriedCardFields?: Record<string, unknown>;
};

export type CharacterAdd = {
  type: "character_add";
  name: string;
  description: string;
  image: string | null;
};

/**
 * Whose card — the two questions a set answers.
 *
 * There were three. The middle one, `othersWhileVoiced`, asked what the *other* cards carry
 * "when writing as a single character", which was the Writer's two voices showing up on a
 * third screen: a narrated turn and a first-person turn were held to be different readers, so
 * the same cards were described twice over. Every turn is written by a card now — the
 * Narrator's is a card like Ana's — so there is no second kind of reader for the row to be
 * about; the one-off upgrade dropped it from the stored sets that named it.
 */
export type CharacterCardFields = {
  /** What every other card in the scene carries, whoever is writing. */
  others: readonly CharacterFieldId[];
  /** What the card being written as is told about itself. */
  voiced: readonly CharacterFieldId[];
};

/** The fields of a `Character` that a prompt can carry. */
export type CharacterFieldId =
  | "description"
  | "personality"
  | "scenario"
  | "systemPrompt"
  | "mesExample"
  | "states";

/** A character as the character shelf's rows and the screens beside them read one. */
export type CharacterListing = Pick<Character, "id" | "name" | "image"> &
  Partial<Pick<Character, "imageTransform" | "tags" | "folderId" | "order" | "updatedAt" | "lorebooks" | "savedFrom" | "chubId" | "cardSourceId">> & {
    /** Each face as its count reads it (`faceCount`) — the faces' pictures stay with the card. */
    expressions?: FaceText[];
  };

export type Chat = {
  id: string;
  title: string;
  updatedAt: number;
  /**
   * **When the reader last changed the chat**, which is what the home list is ordered by. See
   * `lib/chat/touched.ts`. `updatedAt` is sync's clock and moves on bookkeeping writes too, such
   * as opening the chat. This one moves on every write except those marked `quietly`.
   * It travels inside the chat record like any other field.
   */
  touchedAt: number;
  /**
   * **What each agent has spent on this story, per device** — `{ [deviceId]: { [agentId]: tokens } }`,
   * a grow-only counter (ROUND-2026-11-02 §3). Each device adds to its own entry only, where its call
   * log records the call (`countSpend`), so two devices never edit one number and the merge takes
   * the larger of each (`MERGE_RULES.chats`). A pass's `tokenCeiling` is read against the sum over
   * every device (`pastCeiling`). Absent on a chat nothing has spent on.
   */
  spent?: Record<string, Record<string, number>>;
  /**
   * The Director's own record of the story, in its order — see `NotebookSection`. Absent on every chat
   * written before it existed, and on every chat whose Director has not written one, so a
   * chat without it serialises byte-identically. Never a sync key of its own: it travels
   * inside the chat record, and it is redacted from a guest's copy.
   */
  notebook?: NotebookSection[];
  /**
   * **Cards the Director is holding in the story** — see `lib/director/boosts.ts`. Absent until
   * one is granted; carried, never defaulted, so a chat with none serialises byte-identically.
   */
  directorBoosts?: DirectorBoost[];
  /**
   * When the chat was started.
   */
  createdAt: number;
  worldIds: string[];
  characterIds: string[];
  /**
   * Born multiplayer — created from the Play Together modal to be played with guests.
   *
   * The one multiplayer fact stored on a chat: the live session (room code, roster, mic)
   * evaporates with the room and must never land here (MULTIPLAYER.md §2.2). This marker
   * is what lets the library badge the chat and the host offer to reopen a lobby around
   * it. Carried, never defaulted, so a chat without it serialises byte-identically.
   */
  multiplayer?: boolean;
  /**
   * The picture on the chat's own card.
   *
   * Optional, and carried rather than defaulted, so a chat without one serialises
   * byte-identically. Named `image`/`imageTransform` to match `Character` and `World`
   * exactly: `portraitStyle`, `PORTRAIT_FRAME`, `AdjustImageModal` and `EntityPortrait` all
   * take that pair, and a chat picture spelled any other way would be a second shape for one
   * fact — and a second crop dialog behind it.
   *
   * Absent still means "work it out": `portraitForChat` falls back to the cast, which is
   * what every chat written before this shows and what most chats will go on showing.
   */
  image?: string | null;
  imageTransform?: ImageTransform;
  messages: Message[];
  /**
   * **The takes a retry cut, waiting for the reply that takes their place** — `after` is the id of
   * the message the reply follows (null at the top), `variants` the takes it will carry, `reply`
   * the cut message itself bar its words. Landed by the reply's commit (`landCarriedTakes`); put
   * back as the reply they came from whenever no reply comes to take them (`restoreCarriedTakes`).
   *
   * Held on the chat rather than in the retry's closure, which attached them only if the whole run
   * ended with a reply at the cut *and* the chat still on screen: leaving the chat, a 429, a Stop
   * before any prose, or a card holding the story each lost every earlier take. Absent at rest.
   */
  carriedTakes?: { after: string | null; variants: MessageVariants; reply: CarriedReply };
  /**
   * **What each draft's last Clear covered, by its name** (`.agents/MACROS.md` §4.3): the name of
   * every run written to the draft when it was cleared, on every take (`runName`, `clearedNow`). A
   * draft keeps everything written to it and has no store of its own — its entries are the run
   * records whose destination named it (`draftEntries`) — so a Clear names the runs it hides, and
   * they are not read. The runs stay, in the Inspector's Raw logs.
   *
   * It was a moment (`draftsClearedAt`), compared with each run's `at`, which the clock of the device
   * that ran it wrote: a device whose clock ran ahead wrote entries a Clear pressed after them on
   * another device still read, and a Clear pressed on it hid the other's newer ones. Then, for a day,
   * a place in the story (a message and a run), which a deleted message, a re-run replacing a run, a
   * pruned run or a swipe moved — each one brought cleared entries back. Names move with nothing:
   * deleting, pruning or rewinding takes a run away with its name, swiping and retrying carry it, and
   * a run recorded after the Clear has a name the Clear does not hold. Two devices clearing at once
   * keep both lists (`lib/sync/merge.ts` merges a list of strings as a set).
   */
  draftsCleared?: Record<string, string[]>;
  directorMessages: DirectorMessage[];
  /**
   * **Compactions of the Director's own conversation.** Absent until one is written.
   *
   * See `DirectorSummary`, and note the thing it deliberately is not: a `ChatSummary`.
   */
  directorSummaries?: DirectorSummary[];
  hiddenInjections: HiddenInjection[];
  chatSettings: ChatSettings;
  characters: Character[];
  worlds: World[];
  /**
   * **This chat's lorebooks** — the folders its world cards are filed in (`World.folderId`), and
   * that its characters own (`Character.lorebooks`). See `Lorebook`. Names are unique among
   * siblings, as on the shelf (`freeLorebookName`).
   *
   * Carried, never defaulted: a chat whose cards are in no lorebook stores no key, so every chat
   * that had no category and no book serialises byte-identically.
   */
  worldFolders?: Lorebook[];
  /**
   * **The cast's folders** (`Character.folderId`) — the reader's own filing in the character manager,
   * and nothing else: no prompt, no turn and no voice reads them. The cast's order is
   * `characterIds`, folders or none; a folder draws its cards in that order. Carried, never
   * defaulted: a chat with no folder stores no key.
   */
  characterFolders?: ChatFolder[];
  /**
   * **The arcs' folders** (`StoryArc.folderId`) — filing in the story manager, shared by its three
   * kinds, read by no prompt. Carried, never defaulted, as `characterFolders`.
   */
  arcFolders?: ChatFolder[];
  storyArcs: StoryArc[];
  summaries: ChatSummary[];
  /**
   * **The story's memories** — facts and passages, filed under the reader's tree and read for
   * the next reply (`types/memory.ts`, `.agents/MEMORY.md`). Replaced `highlights`: a highlight
   * is a pinned memory now.
   */
  memories: Memory[];
  memoryHorizonIndex?: number | null;
  storyStarted?: boolean;
  // `lastStoryGuideUserMessageId` stood here: the Story Guide's private record of which
  // player line it had already answered, kept because its runner anchored to the narration
  // *before* that line and so could not use the scheduler's stamp. It anchors where the
  // scheduler says now, and the stamp is the one record of what has run.
  /** Explicitly queued next speaker (from call_character). Cleared after they speak. */
  nextSpeakerId?: string | null;
  /** Last character who spoke; null = Narrator. Used when no explicit queue. */
  lastSpeakerId?: string | null;
  speakerQueue?: string[];
  proposalBundles?: ProposalBundle[];
  /**
   * **The face each line wears, as the screen that ranked it chose** — `lib/expressions/chosen.ts`.
   * The answer only (a few bytes a line), so every screen draws what one paid for; the ranking
   * itself, candidates and scores, stays in the device's cache.
   */
  chosenFaces?: Record<string, ChosenFace>;
  awaitingApprovalContinuation?: boolean;
  pipeline?: {
    passStamps: Partial<
      Record<
        PassId,
        {
          anchorMessageId: string;
          /** `error`: the pass failed here and the reader chose Continue — done with, not run. */
          status: "ok" | "skipped" | "error";
          at: number;
        }
      >
    >;
    /**
     * **Passes that failed, waiting for the reader to say Continue or Retry** — keyed like
     * `passStamps`, and a different fact from them: a stamp says what has been dealt with at an
     * anchor, this says what went wrong there and has not been answered. The turn holds on it
     * (`passFailuresHolding`), so a pass that keeps failing stops the story out loud instead of
     * being tried again behind the reader's back. Absent is none; a stamp written under the same
     * key clears it.
     */
    failedPasses?: Partial<Record<PassId, { anchorMessageId: string; error: string; at: number }>>;
  };
};

/**
 * **Every cut a press can ask for, and what each one is about to throw away.**
 *
 * Four doors: Prune and Fork on a story bubble, and Prune and Fork on a Director message. A
 * fork is a cut made on a copy (`forkChat`), so the four are two directions — *this and
 * everything after it goes*, *this and everything before it stays* — on two lists.
 *
 * Each is named by the id it was pressed on and resolved when it runs, because an index taken
 * when the bar was opened names a different turn once anything lands. Missing means the thing is
 * already gone, which is a no-op rather than an error: two presses of one confirmation must not
 * cut twice.
 */
export type ChatCut =
  /** A story bubble and every bubble after it — the cut retry takes (`cutFromTurn`). */
  | { kind: "storyFrom"; turnId: string }
  /** A story bubble and every bubble before it are kept — fork's (`cutThroughTurn`). */
  | { kind: "storyThrough"; turnId: string }
  /**
   * A Director message and every message after it in the pane — and, with `story`, the story
   * turns written after the one it belongs to (`paneStoryTurn`): the same cut from the other side.
   */
  | { kind: "directorFrom"; messageId: string; story: boolean }
  /** A Director message and everything above it in the pane, over the story as it stood then. */
  | { kind: "directorThrough"; messageId: string };

/**
 * **A folder in a chat's card manager** — the three fields every folder shares, the shelf's included.
 * A chat's lorebooks are these (`Chat.worldFolders`), and so are the cast's and the arcs' folders
 * (`Chat.characterFolders`, `Chat.arcFolders`); what a folder holds is `folderId` on each card, never
 * a list here. `lib/cards/chat-folders.ts` is the walks.
 */
export type ChatFolder = {
  id: string;
  name: string;
  parentId: string | null;
};

export type ChatMessageProps = {
  message: Message;
  turnId?: string;
  /**
   * Absent means the control is absent — a guest without the right to edit sees no
   * pencil, rather than a pencil whose press the host would refuse. The permission is
   * decided by whoever renders the list; this bubble only honours the absence.
   *
   * `images` is the line's pictures as the editor left them, or absent when the edit did not
   * touch them — a line's pictures are edited from the same box its words are. `files` is the
   * same for its documents.
   */
  onEdit?: (id: string, content: string, images?: readonly MessageImage[], files?: readonly MessageFile[]) => void;
  /**
   * Whether this bubble is where the message's pictures are drawn — the message's last row,
   * told by the list (`isLastTurnForMessage`). Every chunk of a pseudo reply is handed the same
   * `Message`, so drawn per bubble a picture is the same picture six times.
   */
  carriesImages?: boolean;
  onDelete?: (id: string) => void;
  onRetry?: (id: string) => void;
  /**
   * Behind the bar's `⋯`. Takes the turn id, exactly as `onRetry` and `onDelete` do: a fork
   * is cut at a *message* and this bubble may be one chunk of one, so the caller resolves
   * which message that is — `parseChunkTurnId` is the one resolver, and `handleRetry`
   * already reads it — rather than this file learning chunk-to-message addressing twice.
   *
   * It used to take nothing at all, and the list passed a closure per bubble that had
   * captured the turn. That is a fresh function on every render, so **`memo` below never
   * held**: every bubble in the transcript re-rendered on every render of the list — once
   * per streamed token — and each one re-parsed its whole text (`MarkdownText` was not
   * memoised either). The cost of one token was the length of the entire story, and a long
   * chat crawled. `tests/react/transcript-memo.test.tsx` compares the props now.
   */
  onFork?: (turnId: string) => void;
  /** Cut the story here: this turn and everything after it. Same addressing as `onFork`. */
  onPrune?: (turnId: string) => void;
  /**
   * The chevrons under the bubble, present only on the turn that can be swiped — which is
   * the last one, and only once it is whole. Decided by the list, which is the only thing
   * that knows where this bubble sits; a bubble cannot see the end of the transcript.
   */
  onSwipe?: (step: 1 | -1) => void;
  /**
   * **What stands under this bubble and belongs to it** — the Writer's tool cards.
   *
   * A card is drawn where its tag was written, which for the last one in a reply is after the
   * last bubble. Rendered by the list *beside* the bubble it followed, it landed between the
   * bubble and the swipe chevrons — so the arrows for changing the take sat above the card,
   * attached to the prose, and the card looked like the next thing in the story rather than
   * part of this turn: *"just treat the tool card as part of the bubble so that the chevrons
   * appear below the tool card."*
   *
   * So it is inside the turn — in the box that arrives with it and carries its chevrons — and
   * it stands in the **Writer's column** whichever side the bubble is on (`WriterLine`):
   * a card is the Writer's, and *"tool cards will always be on the other side like any other
   * narrator object"*, under a line the reader is impersonating and under a guest's line at a
   * table as much as under the Writer's own.
   */
  below?: React.ReactNode;
  /**
   * A surface that never edits — the prune dialog's bubbles, the settings preview, an indicator.
   * Not "a turn is being written": that is `TranscriptLock`, which the controls read for
   * themselves so a turn starting does not re-render every bubble.
   */
  readOnly?: boolean;
  rewindMarked?: boolean;
  showMessageStats?: boolean;
  /** Chat-wide: whether any bubble header carries the time. Composes with the style's own `time`. */
  showTimestamps?: boolean;
  speakerCharacter?: Character | null;
  isUserPersona?: boolean;
  isFirstInGroup?: boolean;
  /**
   * How many bubbles this speaker's run holds, from `groupTurns`. A large avatar is drawn
   * over the bubbles below it, so a run shorter than the picture has to reserve the rest.
   */
  groupSize?: number;
  /** Which bubble of that run this is, so the reserve lands under the last one. */
  indexInGroup?: number;
  /**
   * Which bubble of the run stands beside its picture (`TurnGrouping.portraitAt`). 0 hangs it
   * from the first; a later bubble is where it stands and reaches up from.
   */
  portraitAt?: number;
  /**
   * The run this bubble belongs to, named by its first row — what the picture's walk down the
   * run is keyed on (`usePortraitWalk`). Absent outside a transcript, where nothing walks.
   */
  runId?: string;
  speakerName?: string;
  formattedTimestamp?: string;
  contentOverride?: string;
  /**
   * **The chat's speaker rule** (`speechRuleOf`), which the speaker's own `Name:` is taken off the
   * front of the words by. Told by whoever renders the bubble, which has the chat; a bubble that
   * read the shipped rule for itself would show a name the transcript had already read off.
   */
  speech: SpeechRule;
  /**
   * What was written under this bubble when a find-and-replace rule drew it differently
   * (`RenderedTurn.written`) — what the editor opens on. A rule never rewrites a stored message, so
   * an edit that opened on the drawn text would save the rule's output over what was written.
   */
  written?: string;
  /**
   * **This row is a picture written in the prose** (`RenderedTurn.picture`): it is drawn the way a
   * line's pictures are, outside any bubble, and there is no bubble — the row's words were only
   * its markup. Two strings rather than the record, so the memo below holds on a primitive.
   */
  pictureSrc?: string;
  pictureAlt?: string;
  isStreamingTurn?: boolean;
  /**
   * Which take this message is showing and how it got there — from the transcript, so every
   * bubble of one reply moves the same way. See `takeArrival`. Absent outside a transcript.
   */
  arrival?: TakeArrival;
  /**
   * Present when this turn is a line nobody claimed, carrying the style to draw it in.
   * Absent for an ordinary turn — the two are different kinds of thing, not a flag and a
   * mode that could disagree about which is in force.
   */
  narration?: NarrationLineStyle;
  /**
   * The face this bubble wears, when retrieval has ranked one. Resolved by the list rather
   * than looked up here: the ranking lives in a module cache that React cannot see, and a
   * bubble that read it directly would not re-render when it changed.
   */
  expression?: { image: string | null; transform?: ImageTransform } | null;
  /** Retrieval is still choosing this bubble's face — see `expressionActivityDot`. */
  expressionRanking?: boolean;
  appearance?: AppearanceSettings;
  animation?: AnimationSettings;
};

/**
 * **One chat's two runs, kept apart** — this device's own, and one somewhere else is writing.
 *
 * They were one record with a `relayed` flag, set by the relay on every frame and cleared by every
 * other write — so any write of this device's (an agent's stream, a summary's spinner, the chat
 * opened with a turn owed) left another device's run standing here as `isGenerating` with the flag
 * gone: a picture that said this device was writing. `writingHere` held the library copy back as if
 * it were, and Stop fell through to a local stop and a cut of a chat the other device was writing.
 * Two facts in two fields: a write to one cannot produce the other.
 */
export interface ChatPipelines {
  /** This device's run. `setPipelineState` writes here and only here. */
  own: PipelineState;
  /**
   * A run another of the owner's devices (`lib/pipeline/live-stream-sync.ts`) or a table's host
   * (`plugins/multiplayer/client/story-sync.ts`) is writing, drawn here — whole, as the relay last gave it. Null
   * when none is drawn. Only `setRelayedRun` writes it.
   */
  relayed: PipelineState | null;
  /**
   * The last run drawn here, kept past its end for the progress box the Inspector keeps up
   * (`keptRun`). Written by the two setters beside the run itself, so it cannot miss a frame.
   */
  kept?: KeptRun;
}

/** The built-in accounts that write stories — a row with a `chat` service. */
export type ChatProviderId = {
  [K in BuiltinProviderId]: Catalog[K] extends { chat: object } ? K : never;
}[BuiltinProviderId];

export type ChatService = {
  chatUrl: string;
  modelsUrl: string;
  modelsFallbackUrl?: string;
  /**
   * The header the listing takes the key in, where the listing speaks another wire than the chat:
   * Gemini's native listing (`x-goog-api-key`) beside its OpenAI-compatible chat. Absent: the
   * dialect's (`modelHeaders`).
   */
  modelsKeyHeader?: string;
  /** With no key the listing answers 401 (Anthropic, OpenAI…) and the browser would be empty with no reason given. */
  requiresAuthForModels: boolean;
  /**
   * Ids in the listing that are not chat models — OpenAI's names embedders, speech and image
   * models beside the chat ones and says nothing about which is which.
   */
  hideModels?: RegExp;
  /** A prefix the listing puts on every id and the chat endpoint does not want (Gemini's `models/`). */
  stripIdPrefix?: string;
  /** Which wire format it speaks — see `lib/ai/dialects.ts`. */
  dialect: DialectId;
  /**
   * What a bare number in the listing's price means when the listing does not say. Verified
   * against the live feeds: OpenRouter publishes per-token strings and no `unit`; NanoGPT
   * publishes per-million numbers and says `per_million_tokens` on every row.
   */
  pricingUnit: PricingUnit;
  /** A local server: every model it lists costs nothing, whatever the listing says (it says nothing). */
  free?: boolean;
  /**
   * Whether it hands the request on to somebody else and lets us say to whom — the routing
   * control exists only where this is true (§13.11).
   */
  routesUpstream: boolean;
  /**
   * What it needs added to a request before it will say what the request cost.
   *
   *  - `openai` — `stream_options: { include_usage: true }`, only while streaming: a streamed
   *    OpenAI-shaped reply carries no usage unless asked, and a whole one carries it unasked.
   *  - `none` — it reports without being asked (Anthropic), or does not report.
   *
   * There was an `openrouter` value that also sent `usage: { include: true }` for the dollar cost.
   * OpenRouter retired it — "deprecated and have no effect"; the cost now comes on every response.
   */
  usageOptIn: "openai" | "none";
  /**
   * How it caches a prompt's prefix: `breakpoints` takes `cache_control` on a content block
   * (Anthropic, and OpenRouter passing it on); `automatic` caches on its own and may refuse a
   * block carrying a marker it has never seen; `none` has no documented cache — the same wire.
   */
  promptCache: "breakpoints" | "automatic" | "none";
  /**
   * The body field that keeps one conversation's requests on the machine still holding its prefix
   * (`cacheKeyBody` in `lib/ai/routing.ts`), and where that is documented. Absent: none is sent.
   */
  cacheKey?: { field: string; why: string };
  /** Whether a chat completion here can answer with a picture (`modalities: ["image","text"]`). */
  makesPictures: boolean;
  /** Which sampler knobs it takes, and what it calls each one and the reply cap — `lib/ai/request-shape.ts`. */
  sampling: SamplingWire;
  /** Whether it takes stop strings, and how many — `lib/ai/stops.ts`. Absent: none are sent. */
  stops?: StopWire;
  /** How it takes a reasoning level, and which models take which — `lib/ai/reasoning.ts`. */
  reasoning: ReasoningWire;
  /**
   * The user message a conversation is opened with when it would open on anything else
   * (`shapedFor` in `lib/ai/completion.ts`). Only a reader's own server sets it, and only
   * with "Start with a user message" on (`CustomEndpoint.userFirst`); absent, nothing is added.
   */
  userFirst?: string;
};

export type ChatSettings = BaseSettings & {
  provider: Provider;
  model: string;
  /** Only providers that route upstream read this — see `ProviderConfig.routesUpstream`. */
  providerRouting: ProviderRouting;
  isNew?: boolean;
  writerVisibility: ModelVisibility;
  storyGuideVisibility: ModelVisibility;
  stateManagerVisibility: ModelVisibility;
  optionVisibility: ModelVisibility;
  directorVisibility: ModelVisibility;
  /**
   * The Image Writer's — of which its builder reads `rawHistory` alone:
   * how much of the story it is shown before the sentence. See `lib/context/visibility-keys.ts`.
   */
  imageWriterVisibility: ModelVisibility;
};

export interface ChatState {
  activeChatId: string | null;
  activeChat: Chat | null;
  /**
   * **Why the open chat is not here**, once the PC has been asked (`ensureHeld`): `"none"`, the library
   * has no chat of this id; `"unreachable"`, the PC could not be asked, and nothing is known. Until it
   * is answered, an `activeChatId` with no `activeChat` is a chat still on its way, and the screen
   * says it is loading; once answered, it says which of the two rather than loading for ever. It said
   * "not in your library" for both, so a phone on flaky Wi-Fi was told its chat did not exist.
   * Unreachable is asked again when the server next answers. Cleared by every `setActiveChatId`.
   */
  activeChatAway: Exclude<HeldAnswer, "held"> | null;
  
  uiState: UIState;
  /**
   * **Each chat's turn, under that chat's id.** Read through `pipelineFor`.
   *
   * This was one record for the whole app with an owner field inside it, and it went wrong in
   * two directions. Every screen read it as its own, so a chat you merely *opened* showed the
   * turn another chat was running — "Generating story…", a Stop that reached into somebody
   * else's run, an indicator that "disappears on its own" on the other chat's timer. The owner
   * field and `pipelineFor` fixed the reading. The writing stayed last-writer-wins: a summary
   * started in chat B while chat A narrated took the record over and reset A to rest, so going
   * back to A showed an idle composer over a reply still arriving and offered no Stop — and A's
   * next chunk took it back and wiped B's summary spinner. The agent streams and the in-flight
   * agent set named no chat at all, so they were written into whichever chat held the record.
   *
   * A record per chat is the smallest thing any of this is true of (AGENTS.md §13.20), so two
   * chats' work cannot touch each other's however their writes interleave. An absent entry is
   * a chat with nothing happening, which `pipelineFor` spells as the shared `IDLE_PIPELINE`.
   *
   * Each record holds two runs apart (`ChatPipelines`): this device's own, and one somewhere else
   * is writing, drawn here. Read the one on screen through `pipelineFor`.
   */
  pipelines: Readonly<Record<string, ChatPipelines>>;

  // Actions
  setActiveChatId: (id: string | null) => void;
  /**
   * Write the open chat. **False when the write was not taken** — no chat open, or another device
   * writing it (`writeRefusedElsewhere`) — so a caller that holds an edit keeps it and says nothing
   * of success. A mutation that changes nothing is taken: there was nothing to write.
   */
  updateActiveChat: (updater: (chat: Chat) => Chat | void) => boolean;
  /**
   * Merge a patch into the open chat's settings — **and refuse it for a guest.**
   *
   * A guest's copy of a shared chat is a view of somebody else's record. A setting written
   * into it is accepted by the screen, never sent anywhere, and thrown away by the next
   * snapshot: the worst of both, because the control moves and then silently springs back.
   * The turn rules are chat settings now, so this is the door the whole settings dialog
   * writes through and the one place that refusal belongs.
   *
   * Deliberately **not** in `chatMutator`'s guest branch: `story-sync`'s `applyAppend`
   * writes the guest's own transcript through that, and refusing there blanks the story
   * instead of locking the dialog.
   */
  patchChatSettings: (patch: Partial<ChatSettings>, after?: (chat: Chat) => void) => boolean;
  
  setUIState: (updater: Partial<UIState> | ((prev: UIState) => Partial<UIState>)) => void;
  /**
   * Record something about a chat's turn. **The chat is not optional**: a write that does not
   * say who it is for is what let one chat's run be drawn in another, and a required first
   * argument is the only form of that rule a new call site cannot forget. A write with no chat
   * (a screen with nothing open) has nothing to describe and is dropped.
   */
  setPipelineState: (
    chatId: string | null,
    updater: Partial<PipelineState> | ((prev: PipelineState) => Partial<PipelineState>)
  ) => void;
  /**
   * Draw — or, with null, stop drawing — a run of the chat that somewhere else is writing: another
   * of the owner's devices (`lib/pipeline/live-stream-sync.ts`) or a table's host
   * (`plugins/multiplayer/client/story-sync.ts`). **The relays' door, and nothing else's**: `setPipelineState`
   * is this device's and cannot reach it (`ChatPipelines`).
   */
  setRelayedRun: (chatId: string, updater: PipelineState | null | ((prev: PipelineState | null) => PipelineState | null)) => void;

  /** Publish or retire one agent's live stream in one chat. Passing null removes the entry. */
  setAgentStream: (chatId: string, agentId: AgentId, stream: ParsedStream | null) => void;
  /** What a called run is writing (`runStreams`); `null` when it has stopped. */
  setRunStream: (chatId: string, run: string, stream: ParsedStream | null) => void;
  /** Add or remove an agent from one chat's in-flight set. Idempotent in both directions. */
  setAgentActive: (chatId: string, agentId: AgentId, active: boolean) => void;
  /** Expand or collapse one agent's raw-output panel. */
  setAgentLogExpanded: (agentId: AgentId, expanded: boolean) => void;
  
}

export interface ChatSummary {
  /**
   * Stable identity. Everything addresses a summary by this — the hub's edit/delete, the
   * Use/Ignore toggle, React keys. `(kind, tier, startTurn)` was the old composite and it
   * was display data pretending to be identity: a roll-up could move it under an open
   * editor, and two records could legally share it.
   */
  id: string;
  /**
   * The messages this summary compresses, inclusive. Read only through
   * lib/context/summary-range — the range used to be parsed back out of `content`,
   * which the model writes.
   *
   * There is no `turnIndex` beside it. That field held the index from which the summary
   * became visible, and was only ever written as `endTurn + 1`; `visibleFrom()` derives
   * it. Two numbers for one seam is how a chat ends up with turns that are neither
   * summarized nor shown.
   */
  startTurn: number;
  endTurn: number;
  content: string;
  /**
   * How many compressions deep this is. 0 compresses raw turns; n compresses tier n-1.
   *
   * `startTurn`/`endTurn` always name *raw* turns whatever the tier, so a tier-1 summary
   * and the tier-0 ones beneath it cover the same span — which is why selection has to
   * pick a cover rather than show everything that qualifies, or the model reads the same
   * events twice.
   */
  tier: number;
  /** Which lens wrote it: a `SUMMARY_KINDS` id. Only the spine kind moves the frontier. */
  kind: string;
  // No `source` beside it. It said who wrote the block, and the only reader was the seam:
  // yours replaced its turns, the summarizer's waited for a tight window. One object with
  // two behaviours needs a control to tell them apart, and now there is one rule instead —
  // see `bindingSeam`. The scheduler never read it: it works around every record it finds.
  /** When it was committed. Orders alternatives over one span; the cover tie-break stays array order. */
  createdAt: number;
  /** The one-run instruction it was generated under, if any. Provenance; no reader re-applies it. */
  note?: string;
  /**
   * Ignored: in no cover, holding no *live* frontier. The hub's per-block Use/Ignore
   * toggle — disabling the newest summary of a span is how you roll back to the previous
   * one. Written `true || undefined`, never `false`, so an untouched record stores no
   * key. The scheduler still *plans* around disabled spans (`plannedThrough`), so saying
   * Ignore does not summon a fresh auto-summary of the same turns.
   */
  disabled?: boolean;
  isNew?: boolean;
}

/** A line's face as it was chosen: the face, and the score that chose it (what "best of the run" compares). */
export type ChosenFace = { id: string; score: number };

/** How a window of the transcript is counted: in whole messages, or in tokens. */
export type ChunkMode = "messages" | "tokens";

/** A picture a chunk stands for — its address and its words, already passed as safe to load. */
export type ChunkPicture = { src: string; alt: string };

/**
 * **Which candidates close reading — the reranker — reads**, per pool (round 2026-10-06).
 *
 * - `none` — it reads nothing: the model never loads and nothing of its opinion is assumed.
 *   This is the one switch for "close reading is off" for a pool; its weight starts above 0
 *   (`signalWeightRange`), so a weight of 0 is not a second way to say it.
 * - `best` — the N the cheap signals rank highest. Right where the single best pick matters: a
 *   face.
 * - `edge` — the N either side of where the pool's budget cuts, so the reranker decides what
 *   makes the cut rather than re-sorting items that are in anyway. Cards and memories: each is
 *   admitted by score until its share is spent, and neither sends the order it was admitted in
 *   (cards go in the roster's order, memories in the story's), so what close reading can change
 *   about a prompt is which of them make the cut.
 */
export type CloseReadingReach = "none" | "best" | "edge";

/** A pool with no budget walk — faces, where one is drawn — has no edge to read. */
export type CloseReadingTop = Exclude<CloseReadingReach, "edge">;

/** What a press of Send acts on: the composer as it stands. */
export type ComposerSend = {
  /** The draft, as typed. */
  text: string;
  /** The pictures and documents beside it. */
  images: readonly MessageImage[];
  files: readonly MessageFile[];
  /** A character equipped to answer, who is called by the press. */
  calling: string | null;
  /** State changes armed over the composer, spent on the turn the press takes. */
  armed: readonly ArmedAction[];
  /** The composer is writing a Director's note, which the press files rather than sends. */
  note: NoteAddressing | null;
  /** Where the reveal stands: a press mid-burst cuts what the reader has not been shown. */
  cursor: TurnCursor | null;
  typing: boolean;
  /**
   * The reveal is still handing a reply out — a run walking it or parked at a Continue or a Pause,
   * or an indicator standing for a bubble the reader has not been given. With a reply the cursor is
   * behind on, what turns an empty press into Continue (`continuesReveal`).
   *
   * One field. There were two — this and `revealing`, the run *or* a Continue offered — and the send
   * asked one predicate of the first and another of the second, at two points with two sets of
   * exclusions: a resumed chat's empty press was a turn by one and Continue by the other, and the
   * Inspector's projection asked neither, so it drew a reply the press only continued as cut.
   */
  handingOut: boolean;
  /** The table playing this chat takes lines into a window (`tableBatches`): an empty press there is Ready. */
  batched: boolean;
};

/** The composer: which of its extras it draws, where a counted note opens, and what one line may carry. */
export type ComposerTuning = {
  /** The `+` beside Send: a line sent with no reply asked for. */
  sendWithoutReply: boolean;
  /** Continue beside Send while a reply waits for the reader, and Pause while replies flow. */
  continueInComposer: boolean;
  /** A faint ring on that button, filling over the reading pause the replies are waiting out. */
  continueWait: boolean;
  /** The menu's "Add Director's Note". */
  directorNote: boolean;
  /** The menu's "States & Inventory", and the Arm on a chip over the composer, which opens it. */
  states: boolean;
  /** Whether sending armed state changes files a Director's note into the story. */
  armedStateNote: boolean;
  /** The menu's "Impersonate Character". */
  impersonate: boolean;
  /** The menu's "Call Character". */
  callCharacter: boolean;
  /** The menu's "Run an agent". */
  runAgent: boolean;
  /** The menu's "Attach", and a file pasted into or dropped on the box. */
  attach: boolean;
  /** The smiley at the right end of the box, which opens the emoji picker. */
  emoji: boolean;
  /** Where "A set number" starts a new Director's note, in replies. */
  noteLifetime: number;
  /** Pictures one line may carry. */
  maxPictures: number;
  /** The longest side a picture is stored at, in pixels — attached to a line or made by the Image Writer. */
  pictureMaxDim: number;
  /** Documents one line may carry. */
  maxFiles: number;
  /** The largest file read at all, in megabytes. */
  maxFileMegabytes: number;
  /** The most text one document may carry, in characters. */
  maxFileChars: number;
};

/**
 * Who is composing a line right now — **one table, keyed by the face on screen.**
 *
 * Two different things say "something is coming" and they are deliberately different facts:
 * the reveal's in-transcript row means *a line exists and is being withheld from you*, and a
 * player's draft means *a line does not exist yet*. What they share is a **seat**: a pseudo
 * chunk about to reveal a line for `Mira:` and the person playing Mira with their hand on
 * the keyboard are one face, and drawing both is the transcript promising the same line
 * twice. Keying on the worn seat is what makes that unrepresentable rather than something a
 * reader has to notice — the withheld turn takes the seat and the draft behind it is gone.
 *
 * The withheld turn is **handed in** by the transcript, never recomputed here. It is the one
 * surface that knows which turn the reveal is holding, and a second derivation of it would
 * be the shape this repo's first law is about.
 *
 * `place` is decided once, here, and the three values are one field — so "drawn on two
 * surfaces at once" is unrepresentable rather than avoided by convention.
 */
export type ComposingPlace =
  /** In the story, where the line would land. */
  | "transcript"
  /** In the table-talk pane, where that line will land. */
  | "ooc"
  /** Above the composer as room presence: real fingers, no promise about the story. */
  | "room";

/** A line being withheld outranks a line that does not exist yet. */
export type ComposingRank = "turn" | "draft";

export type ComposingRow = {
  /** The face this is about: the character they wear, else the chair they sit in. */
  key: Seat;
  rank: ComposingRank;
  place: ComposingPlace;
  /** Whose fingers, or `null` for the reveal's withheld turn — nobody is typing that one. */
  ownerId: string | null;
  /** The account, and the character if they are wearing one — "Ana (Mira)". */
  name: string;
  /** What goes under a portrait: the character's name, or the account's. */
  label: string;
  character: Character | null;
  /** Their draft so far, when the host has switched live keystrokes on. */
  preview: string | null;
};

/**
 * How a prompt is fitted into its window.
 *
 * Two modes, and they are the two the panel shows. There used to be three on screen —
 * "Auto" was `mode: "fit"` with the shipped order, which is not a third mechanism, and
 * telling the two apart needed a React-local flag to stop the picker snapping back.
 */
export type ContextPolicy = {
  /**
   * `fit` — each section takes what it needs; when the total will not fit, sections are
   * given up from the bottom of `priority` upward.
   * `allocation` — each section is reserved a share of the window first, and a section
   * wanting less than its share donates the remainder to the ones that want more.
   */
  mode: "fit" | "allocation";
  /**
   * Most important first. #1 is kept longest; the last entry is given up first. Every
   * section appears exactly once.
   *
   * This was `evictionOrder`, stored in the opposite direction, and the panel's numbered
   * list therefore counted down from "first to be sacrificed" — the reverse of what a
   * ranked list reads as. Renamed rather than reversed in place, so the compiler had to
   * visit every reader instead of leaving one silently inverted.
   */
  priority: ContextSection[];
  /**
   * Relative weights, normalised when resolved — so they are shares whatever they sum
   * to, and the panel can edit one without having to rebalance the others itself.
   * Read in `allocation` mode only.
   */
  shares: Record<ContextSection, number>;
  /**
   * What happens to a share its section does not use. `allocation` mode only.
   *
   * `share` — the shipped behaviour: a section wanting less than its share hands the
   * remainder to the ones that want more, so nothing is trimmed while the whole prompt
   * fits and a share is a floor.
   * `strict` — a share is the whole of it. Room a section does not use is not used, and a
   * section over its share is cut back to it. Costs window, buys a prompt whose shape does
   * not move from turn to turn.
   */
  spread: "share" | "strict";
  /**
   * Sections whose share is whatever they are asking for this turn, taken off the top
   * before the rest is divided.
   *
   * A share is a percentage of a window, and some sections have a *size* rather than a
   * preference: the system prompt costs what its blocks cost, and adding one in Prompt
   * Master should widen the section rather than be trimmed out of the bottom of it. This
   * is the standing form of the Fit button — the same arithmetic, applied every turn
   * instead of once.
   */
  autoFit: ContextSection[];
  /**
   * The order the sections on a share stand in, on Context master's bar and in its list — which
   * is to say **whose neighbour each share is**: the bar's handles stand between adjacent shares,
   * and dragging one trades room between those two.
   *
   * Read by nothing that builds a prompt. A share is a weight and the division does not care what
   * order the weights are in, so this is the drawing's own fact, and it is stored because the
   * reader arranges it by hand (round 2026-10-03C: *"adjust what neighbors it will have"*). Every
   * section once, like `priority`; absent on a chat that has never been rearranged, and
   * `completeShareOrder` reads that as prompt order (`BUDGET_SECTIONS`), which is the order the
   * bar always drew them in — so a stored chat draws exactly as it did and nothing is migrated.
   */
  shareOrder?: ContextSection[];
};

/**
 * The parts of a prompt a budget can act on.
 *
 * `system` is the prompt-block stack — the base prompt, the tool descriptions and the
 * reminder, i.e. everything Prompt Master authors. It is budgetable at whole-block
 * granularity; see `SystemUnit` in lib/context/budget.ts for why that unit and not a
 * finer one.
 *
 * **Arcs, guidelines and highlights were reserved off the top and are sections now.** The
 * reason they were not was that each was rendered to one string before the budget ever saw
 * it, so there was nothing to divide — the same thing that was once true of the cards, and
 * fixed the same way: they are offered as items and rendered *after* admission, so a cut
 * drops a whole arc rather than half a sentence. The reader could not weigh them, could not
 * rank them, and the fit report could only say "N held back" for all three at once —
 * Context Master had no band for Story Arcs at all, which is where this started.
 *
 * What is genuinely still reserved is what has no items to divide into: the speaker's
 * persona profile, the Director's scenario summary and the no-thinking directive. Those are
 * per-turn correctness, not prose the reader wrote, and a prompt that drops the profile
 * writes the wrong character rather than a shorter reply.
 */
export type ContextSection =
  | "system"
  /**
   * The cards, three ways and two at a time: `cards` while the chat combines them
   * (`combineCardBudgets`, the default), `characterCards` and `worldCards` while it does not — each
   * kind a row of the allocation with its own share or Auto (`activeSections`). It was one row and
   * a hidden halving, which held only while the row had a finite share: on Auto, as it ships, the
   * switch decided nothing, and on a share it was always 50 : 50.
   */
  | "cards"
  | "characterCards"
  | "worldCards"
  | "arcs"
  | "guidelines"
  | "memory"
  | "recall"
  | "history";

/** How much of every agent's window the prompt may not use. */
export type ContextWindowTuning = {
  /**
   * The share of the window held back for the token estimate's error, as a fraction —
   * `resolveContextBudget` takes it off every agent's window beside the reply buffer.
   */
  safetyMargin: number;
};

/** What one of the table's gates knows: one count, the same on every screen. */
export type ContinueGateProgress = {
  /** Which gate — what a press from this screen names. */
  id: string;
  /**
   * Whether the count means anything to draw. Under `anyone` the first press moves the table, so
   * there is nobody to count and an X/Y would be a number about a wait that does not exist.
   */
  counted: boolean;
  /** How many of the table have pressed, counted against who is *currently* seated. */
  pressed: number;
  total: number;
  /** This account already pressed — the button reads "waiting", not "continue". */
  mine: boolean;
  complete: boolean;
};

/**
 * How a portrait sits inside its 3/4 frame.
 *
 * Every grid in the app renders these at `aspect-[3/4]` with `object-cover`, so a wide or
 * tall source is cropped — which cuts the head off exactly the images people care most
 * about. This replaced a three-way `imageFocus: "top" | "center" | "bottom"`, whose
 * Segmented control ate a quarter of the editor's portrait rail for three fixed answers;
 * the Adjust dialog writes a free pan and zoom instead.
 *
 * `x`/`y` are `object-position` percentages (0–100, 50/50 is centred); `scale` is applied as
 * a transform inside the `overflow-hidden` well, so 1 is exactly what `object-cover` alone
 * would show — above 1 is closer, below 1 leaves the frame room the picture does not fill.
 * Optional, and carried through rather than defaulted, so a card that never adjusts stores no
 * key at all — `undefined` is dropped by `JSON.stringify`, the same reasoning as
 * `Character.updatedAt`. `portraitStyle` in `lib/image-utils.ts` is the single read site and
 * defaults it.
 *
 * `dx`/`dy` are **how far past the picture's edge** the frame has been moved, in frames — and
 * only that: while the frame is over the picture the position is `x`/`y`, and these are absent.
 * One position, split where the picture ends, because `x`/`y` cannot say it on their own: a
 * percentage of the overflow is nothing at all on an axis the picture exactly fills, which is
 * every axis of a picture already the frame's shape. `lib/crop-region.ts` keeps the split
 * canonical (`regionShowing`), so one framing is never two stored values.
 */
export type CropRegion = { x: number; y: number; scale: number; dx?: number; dy?: number };

/**
 * **A reader's own server** — `custom:` and its id in `SERVER_ONLY_DOCUMENTS.providerEndpoints`.
 * See `CustomEndpoint` in `lib/providers.ts`.
 */
export type CustomProviderId = `custom:${string}`;

/** The dialect a decisions service speaks — one, today: TypeSafe's, as NanoGPT serves it. */
export type DecisionDialectId = "decisions";

/** A provider's decision service: where it is in `config/providers.ts`, its models in `config/providers.json`. */
export type DecisionService = {
  url: string;
  dialect: DecisionDialectId;
  /** Model ids, the recommended one first — what the card offers when no listing names one. */
  models: readonly string[];
  /**
   * Where the provider lists its decision models among its chat models rather than on a page of
   * their own: the chat listing's rows whose ids match, read with their prices (NanoGPT's Jev).
   */
  inChatListing?: RegExp;
  /**
   * Dollars per million input tokens, by model id, as measured where the listing publishes no price
   * of its own (`lib/memory/cost.ts`). Absent: no estimate without a listed price.
   */
  measuredPrices?: Readonly<Record<string, number>>;
};

/**
 * **A block as it is authored: everything except where it sits.**
 *
 * A stack says where its blocks go by *being in an order*, and `order` is that order written
 * down — `renumberStack` rewrites it from the sequence on every change, and Prompt Master,
 * the shelf and the preset importer all go through that. The shipped defaults table was the
 * one author that wrote both by hand, and the two disagreed: the pseudo-message block was typed
 * into the array after the four import blocks while carrying `order: 5`. Prompt Master draws
 * a stack in array order and the compiler sorts by `order`, so the same block was the
 * second-to-last paragraph on the screen and the second paragraph in the prompt. Nothing was
 * lying; there were two answers.
 *
 * Omitting the field is what stops that recurring. A default block cannot state a position,
 * so the array *is* the position, and `getDefaultBlocksForModelAndMode` renumbers on the way
 * out — the same call every other writer of a stack already made.
 */
export type DefaultPromptBlock = Omit<PromptBlock, "order">;

/**
 * What one provider's wire looks like.
 *
 * Everything above this file speaks one shape — the OpenAI chat-completions body every
 * builder produces, and `{content, reasoning}` deltas coming back. That shape used to be
 * assumed in four separate places: the `Authorization: Bearer` header written twice in
 * `completion-streamer.ts`, `choices[0].delta.content` in the SSE reader, and
 * `choices[0].message` in the non-streaming branch. Adding a provider that does not speak
 * it meant editing all four and hoping.
 *
 * A dialect is those four answers, together, for one API. `openai` is the shape this app
 * has always sent, written out unchanged, so every provider that speaks it keeps sending
 * byte-identical requests.
 *
 * **What a dialect does not decide:** which model, what the prompt says, or how much room
 * anything gets. It converts, and nothing else — so a provider cannot quietly change what
 * an agent was asked.
 */
export type DialectId = "openai" | "anthropic";

export type DiceTerm =
  | { sign: 1 | -1; count: number; sides: number; keep?: KeepRule }
  | { sign: 1 | -1; constant: number };

export type DirectorAction =
  | ({ type: "inject" } & NoteDirection)
  | { type: "call_character"; characterId: string };

/** One card the Director is holding in the story, and the message count at which it lapses. */
export type DirectorBoost = { cardKey: string; untilTurn: number };

export type DirectorMessage = {
  id: string;
  role: string;
  content: string;
  thinking?: string;
  agentId?: string;
  speakerCharacterId?: string | null;
  /** The runs this reply records — the pane's Director run. Same shape as on Message. */
  runs?: AgentRun[];
  /**
   * What this reply read out of the chat — see `LookupRecord`. Carried, never defaulted.
   *
   * The helpers it spun up were a sibling record, `subagentRuns`, and are on the `timeline`
   * now as `tool_use` items with a result — one record of a finished run, not two.
   */
  lookups?: LookupRecord[];
  /**
   * **What this reply did, in the order it did it** — see `lib/director/timeline.ts`.
   *
   * Written by the loop, which is the only party that knows; carried, never defaulted. A reply
   * stored before this existed has none, and the pane draws it the way it always did.
   *
   * A `steps` field stood beside this, holding each step's raw text and observation so the
   * timeline could be rebuilt from it. Nothing ever read it: two stored answers to one
   * question, one of them derivable from the other, is §13.1 — and the derivable one was the
   * copy nobody was keeping in step.
   */
  timeline?: DirectorTimelineItem[];
  stateChanges?: StateChange[];
  timestamp?: number;
  isBackground?: boolean;
  /** The Writer turn this card was produced for. */
  anchorMessageId?: string;
  /**
   * The director message this card is grouped under, when it is a child card.
   *
   * A real field for the same reason as the two below: this used to be written as a
   * `directorMessageId="…"` attribute inside `content` and recovered by regex at eight
   * sites. Grouping drives Approve All and the pipeline gate, so a content edit that
   * disturbed the attribute could split one proposal into several unapprovable ones.
   */
  parentMessageId?: string;
  /**
   * The proposal this message is a card for. A real field rather than an attribute
   * inside `content`, so it survives content edits and cleanup can prune by it.
   *
   * **Which actions in that bundle are this card's is not here**, and deliberately: the
   * action says so (`ProposalAction.cardMessageId`), one end of the link with one home, and
   * `buildBundleIndex` walks it in both directions. It was declared here as an unused
   * `actionId?` for a long time while the pane recovered the same fact by comparing payloads
   * — see `assignActionCardIds` for what that cost.
   */
  proposalRef?: { bundleId: string };
  /**
   * **The agent whose `<call_agent>` this run answered**, when one did. A called run's cards are an
   * answer to that agent, not the agent's review of the message, so the next run of the agent on
   * the same message does not replace them — and a called run replaces nothing either
   * (`clearLastToolPass`). Absent on a scheduled or a hand run.
   */
  calledBy?: string;
};

/**
 * **A tag that answers rather than proposes.**
 *
 * They are one family because the loop handles them in one place: the reply is read, each
 * question is answered, and the answers open the next step as an observation. A call spends a
 * whole request running another agent; the lookups spend nothing but a read of what the chat
 * already holds, which is why they are gated on their own permission and never counted against
 * the calls a run may make.
 *
 * `kind` rather than a second `type` field: these are not state events and must never be
 * mistaken for one by a reader that switches on `type`.
 */
export type DirectorQuery = DirectorQueryBody & {
  /**
   * The tag as the model wrote it, so an answer can be put back **under the call that asked**
   * rather than in a block at the end of the step. Set by `readDirectorCalls` off the span;
   * absent on a query built any other way, which the layout treats as "after everything".
   */
  tag?: string;
};

export type DirectorQueryBody =
  | ({ kind: "call_agent" } & CallRequest)
  /** A character's or world's card, by name or id — whether or not it is in the prompt. */
  | ({ kind: "read_card"; name: string } & CardReach)
  /** An arc, by title or id, with where it sits in the tree. */
  | ({ kind: "read_arc"; name: string } & CardReach)
  /**
   * What a card is bound to, both ways — what it owns, what owns it, what it is linked with,
   * and the lore filed under it. The reader: *"add tools so agents may see what card is linked
   * to others."* A card's own text says none of this: a link lives on one card and is read
   * from both ends (`linksFor`), so an agent reading the far card would find nothing.
   */
  | { kind: "read_links"; name: string }
  /**
   * Any place a search answers with, by its address (`character:ID:description`, `memory:m12`,
   * `message:ID`, `notebook:ID:text` — `fieldAt` reads it, names too): `<read at="…">`, so a search's
   * answer can be read in full without turning the address back into a name for another tool.
   * Its kind is the tag's own name, so `specOfKind(kind)` finds the tool as it does for every query.
   */
  | ({ kind: "read"; at: string } & Omit<CardReach, "section">)
  /**
   * **Every way of finding text in the story, one tool** (`lib/text/search.ts`): the fields of
   * `scope` ranked by BM25 for `query`'s words, or every place `query` occurs (`match` exact or
   * regex), each answered with the address `<replace>` takes. `node` narrows the memories to a
   * branch of the memory tree; with no words and the memories in scope, the answer is the tree's
   * outline (`.agents/MEMORY.md` §4.3). `<grep>`, `<memory_search>` and `<search_lore>` are read as
   * this (`ToolSpec.aliases`).
   */
  | ({ kind: "search"; query: string; scope?: string; node?: string; match?: "words" | "exact" | "regex"; page?: number } & Ranked)
  /**
   * Dice, thrown by the app. `dice` is standard notation; `vs` a target to meet; `for` a card,
   * whose state named by `mod` is added — the ledger's figure, not the model's memory of it.
   * `why` is the one clause the card shows.
   */
  | { kind: "roll"; dice: string; vs?: number; for?: string; mod?: string; why?: string }
  /** Deterministic mathematical calculation evaluated by the app. */
  | { kind: "calc"; expr: string }
  /** The Writer's ranking as it stands: what is in, what was cut and why. */
  | { kind: "read_context"; top?: number }
  /**
   * A picture, put to the Vision agent. `picture` is its number in the transcript, `card` a
   * card whose portrait to look at — one of the two; `ask` what is wanted of it, or the whole
   * picture described when left out.
   */
  | { kind: "look"; picture?: number; card?: string; ask?: string }
  /**
   * A picture, made by the Image Writer from the sentence and filed on the line the tag was
   * written in. The one query whose answer is not words: the sentence back to the model says
   * which picture it became, and the picture itself is the asker's to place.
   */
  | { kind: "generate_image"; prompt: string }
  /** Web search across the internet returning top result snippets. */
  | ({ kind: "web_search"; query: string } & Ranked)
  /** Web page fetch and readable markdown extraction. */
  | { kind: "web_fetch"; url: string; maxChars?: number; start?: number }
  /**
   * **A tool a plugin registered** (`addToolSpecs`): its name, and the call as the grammar read it —
   * what its own answerer is handed (`lib/plugins/api/tools.ts`). Filed and drawn under `tool`
   * (`queryKindOf`), never under this kind.
   */
  | RegisteredQuery;

/**
 * A fixed amount of the Director's conversation kept verbatim, in messages or tokens.
 */
export type DirectorRawTailSize = { unit: "messages" | "tokens"; amount: number };

/**
 * **A compaction of the Director's own conversation — the pane's `/compact`.**
 *
 * The Director's history is pinned in its packet: it is the thing it is replying to, so it
 * cannot be given up to the fitter the way a card can. On a long story that history is the
 * whole window, and the agent whose job is knowing what is in the story stops being told
 * what is in it. This is what replaces the older half of it: one written block standing in
 * for a run of exchanges, with everything after the frontier still sent verbatim.
 *
 * **Non-destructive, like every other compression here.** `directorMessages` keeps every
 * message for the life of the chat — the pane draws them all, a summary can be ignored or
 * deleted, and the raw exchange comes straight back. What changes is the *packet*, decided
 * fresh each time it is built. That is the same ruling `lib/chat/seams.ts` records for the
 * story: "nothing is ever removed from a chat by fitting".
 *
 * ── Why this is not a `ChatSummary` ────────────────────────────────────────────────────────
 *
 * A `ChatSummary` names its range with `startTurn`/`endTurn`, and those are indices into
 * `chat.messages`. The Director's conversation is a different list, of a different length,
 * that moves independently. Filing a compaction as a `ChatSummary` with a new `kind` would
 * put two different meanings behind one pair of numbers — and `shiftRangeAfterDeletion`,
 * `selectSummaryCover`, `coveredThrough`, `firstUnsummarizedIndex` and the whole memory
 * canvas would all read them without knowing.
 */
export type DirectorSummary = {
  id: string;
  /**
   * The last director message this covers, by id.
   *
   * **The id is the record; the indices are a cache.** Indices into `directorMessages` shift
   * the moment one is deleted or a rewind takes a run, and a range that has silently slid
   * describes messages it never read. The same rule `reanchorNotebook` states: the block
   * belongs to the moment, not to the line.
   */
  throughMessageId: string;
  /** How many messages it stands for, for the pane's marker. Re-derived from the id. */
  covers: number;
  content: string;
  createdAt: number;
  /** The model that wrote it, as the runner resolved it. Handed back, never guessed. */
  model: string;
  /** Estimated by the same estimator the packet is measured with — never a second answer. */
  tokens: number;
  /** The reader's Ignore. Same meaning as `ChatSummary.disabled`: kept, and out of the prompt. */
  disabled?: boolean;
};

/**
 * Everything a reply asked for, in the order it asked — one reading, not three.
 *
 * `kind` says which family a tag belongs to, because the three answer different questions
 * about a tag and a caller usually wants only one of them. The reading itself is `scanXml`
 * against `TOOL_SPECS`, and what a call *becomes* is the spec's own `build`; a call that
 * builds to nothing (an empty `<read_card/>`) is left out here and reported by `unreadTags`
 * as unreadable.
 */
export type DirectorTagSpan =
  | ({ kind: "query" } & TagSpan<DirectorQuery>)
  | ({ kind: "action" } & TagSpan<DirectorAction>)
  | ({ kind: "event" } & TagSpan<StateOrchestrationEvent>);

export type DirectorTimelineItem =
  | { kind: "thinking"; text: string }
  /**
   * **One use of a tool, from the first sight of its name to what came back.**
   *
   * A call and its return were two items, and the return sat at the end of the step; the two
   * ways a call fails were two more. One item now, and the *same* item throughout: the scanner
   * names it mid-stream (`streaming`), the close settles it (`called`), and the answer or the
   * refusal lands on it (`returned`, `failed`, `refused`) without its position in the list
   * moving — which is what lets the pane keep a card the reader opened while it was arriving.
   *
   * `tag` is what the rail's mark and the card's noun are keyed on: an event type, a query
   * kind, or the name as written when nothing built. `wrote` is the tag as the model wrote it,
   * and is what every sentence to the reader quotes.
   */
  | {
      kind: "tool_use";
      tag: string;
      wrote: string;
      label: string;
      status: ToolUseStatus;
      /** The tag as written — or as much of it as has arrived. */
      rawTag?: string;
      /** A call's: the agent called, as written. */
      agent?: string;
      /** A call's note — what it was asked. (Named for the helper's brief it was first.) */
      brief?: string;
      role?: string;
      inputs?: string[];
      /** A call's handed import paths. */
      with?: string[];
      /** Present on a `<task>`: the title it was given and the tool cards it asked for (`CallRequest.task`). */
      task?: { title: string; tools: string[] };
      /** What came back, once it has. */
      result?: {
        findings: string;
        durationMs?: number;
        model?: string;
        /** Estimated by the loop's own estimator — the call log holds the real usage. */
        estimatedTokens?: number;
        error?: string;
        /** The reader stopped it on its card, and its caller carried on (`CallRun.stopped`). */
        stopped?: true;
        /** Whether the caller was shown it. False for a call another call consumed. */
        reported?: boolean;
      };
      /** Why it failed or was refused, in the sentence the model was given. */
      detail?: string;
    }
  | { kind: "prose"; text: string }
  /**
   * How the run finished, and how many requests it took.
   *
   * Appended by the timeline builder and only when it says something — a one-step run that
   * settled is what an ordinary reply looks like, and a line under every one of them would be
   * furniture. The *rule* is the producer's, so neither renderer has to decide whether this
   * run was worth remarking on: they draw what is there.
   */
  | { kind: "run_end"; end: LoopEnd; steps: number };

/** The Director's own limits: how long it holds a card, when the story is unwatched, when it compacts. */
export type DirectorTuning = {
  /** How many turns a `<boost_card>` holds when it names none. */
  boostTurns: number;
  /** The most turns one may name. */
  boostMaxTurns: number;
  /** Turns without a Director run before the story counts as unwatched. */
  unwatchedTurns: number;
  /** How full the Director's window has to be before it compacts on pressure, as a fraction. */
  compactAt: number;
  /** The fewest messages worth a compaction. */
  compactMinimum: number;
};

/** What the card's boxes edit on a change: one row of the table above, or a plugin's kind's own. */
export type EditableFields = { identityKey?: string; proseKey: string; instructs?: true };

/** The app's own editors: Prompt master's block editor and a card's fields. */
export type EditorTuning = {
  /** The `{{` list as a prompt block or a card field is written — and Prompt master's `<` list. */
  suggest: boolean;
};

/**
 * Panels, cards and wells — the boxes the interface is built out of.
 *
 * The brief's central complaint was "box inside a box inside a box", and the cause is
 * visible in the class strings this replaces: nearly every container carried both a
 * background *and* a border, so nesting three of them drew three rules. The rule here is the
 * one Linear and Vercel follow — **separate surfaces by shade, not by line** — so `Surface`
 * has no border by default and only grows one where two surfaces of the same tone meet.
 *
 * Elevation is a number rather than a colour, and it maps onto the `surface-*` ramp: the
 * higher the number the closer the surface is to the reader. `plain` exists for a group that
 * needs padding and radius without becoming another box.
 */
export type Elevation = "plain" | "sunken" | "base" | "raised" | "floating";

export type EmbeddingDialectId = "openai" | "cohere";

export type EmbeddingService = {
  url: string;
  dialect: EmbeddingDialectId;
  /**
   * **A router's own words for the side of the search, sent whatever the model** — in place of the
   * model's own field (`ModelHint.purpose`), which the router is trusted to put into each upstream's
   * words. A model's prefix still goes, since it is in the text. Absent everywhere but a router: a
   * model's hint is the model's (`modelHint`), never typed on the rows that serve it.
   */
  purpose?: PurposeField;
  /** The most texts one request may carry. A longer list is sent in several. */
  batch: number;
  /**
   * The most tokens one request may carry between all its texts, where the provider documents
   * such a limit — absent everywhere it is not documented, never guessed. A batch of long cards
   * over it is refused whole, and would be refused again every ranking.
   */
  maxRequestTokens?: number;
  /** Model ids to suggest, the recommended one first. The field takes any id besides. */
  models: readonly string[];
  listing?: RetrievalListing;
};

/**
 * **A call that has ended this turn, and how** — the progress box's row for it once it has left the
 * running list (`PipelineState.endedCalls`). Stopped is the reader's Stop on its card (`CallRun.stopped`).
 */
export type EndedCall = LiveCall & { outcome: "done" | "failed" | "stopped" };

/**
 * What a character and a world each are, so the state-update logic is written once.
 *
 * The same decision tree — find the entity, route the target key to its name field, its
 * prose field or its state bag, apply the action — was written three times, with a
 * near-identical character branch and world branch inside each: once in
 * `applyStateOrchestrationEvent`, once in `isStateEventNoOp`, once in
 * `buildAutomationAlertText`. Six copies of one routing rule.
 *
 * Two differences between the two kinds. The first is deliberate and is preserved exactly;
 * the second was a defect and is fixed:
 *
 *  1. **A world answers to two names for each field, a character to one.** `title` or
 *     `name` reaches a world's title; `content` or `description` reaches its body. A
 *     character's are `name` and `description` only. Widening the character's aliases
 *     would start routing keys that currently land in its state bag.
 *
 *     (There was a second: a character's `inventory` was a list the first time it was
 *     written, a world's never. That key is a typed tracker now — `lib/trackers/` — and the
 *     bag holds prose for both kinds under one rule, so the asymmetry is gone rather than
 *     preserved. The stored lists were carried across once, by the one-off upgrade.)
 *
 *  2. **A card's own name and prose were state keys too** — `name`/`description` on a character,
 *     `title`/`name`/`content`/`description` on a world — routed to the card's fields on an edit and,
 *     for a character being created, into its state bag, so one key meant two things depending on a
 *     fact the writer could not see. They are `<replace>`'s now, and `<state_set>` refuses them
 *     (`stateUpdateProblem` asks `routeKey`), so a key is a state wherever it lands.
 */
export type EntityKindId = "character" | "world";

export type EntityState = {
  /** How a tag addresses it, and how the drawing keys it. Unique across the whole card. */
  id: string;
  label: string;
  kind: StateKind;
  /** For an `item`: how many are held. One at zero is gone, with what was inside it. */
  value: number | boolean | string | string[];
  /** `number` only. **Both present means it draws as a bar**; neither, and it is a figure. */
  min?: number;
  max?: number;
  unit?: string;
  emoji?: string;
  /** A line about it, on an item mostly — "the one with the chipped grip". */
  description?: string;
  /**
   * **What this one is made of, and what is in it** — `item` only.
   *
   * There is no "is it a container" switch and there must not be one: what makes something a
   * container is that an item is inside it, which this list already says. A switch beside it
   * would be a second answer to one question, and the two would come apart the first time
   * anybody moved the last bullet out of a gun.
   *
   * Facts and contents are not two lists either. A nested `thing` is what the thing *holds*; a
   * nested anything-else is what is *true* of it. The drawer reads that off the kind, which is
   * the same rule everywhere else in this file.
   */
  states?: EntityState[];
  /** In the state drawer. Absent reads as on — a state nobody can see is one nobody can debug. */
  showInMenu?: boolean;
  /** In the chip bar over the composer. Absent reads as off; a HUD of everything is no HUD. */
  showInHud?: boolean;
  /** Whether the player may move it by hand. Absent reads as on. */
  playerEditable?: boolean;
  /**
   * **The card this state *is*** — the whole of linkage, and it lives here.
   *
   * A link *is* a state — see `lib/cards/links.ts` for the reader's words and the whole
   * relation model. It needs no new verb anywhere: a transfer carries it with the item, so
   * handing the sword over
   * hands the card over; a delta on the count needs no link semantics; the drawer, the HUD
   * and the prompt already draw it. A card-level "owns" list would be the second inventory
   * this repo deleted once.
   *
   * `cardId` names **any** card — a character or a world, in either direction. It used to be
   * `worldId` and could only ever point at a world, which made "this place holds these
   * people" unrepresentable and left a separate `Character.locationId` field to say it. That
   * field is gone: *"if a user wants a character to be in a world card location, they simply
   * make the world card own the character."* One relation, one home, every inverse derived.
   *
   * Carried, never defaulted: a state with no card behind it stores no key, so every
   * existing chat serialises byte-identically.
   */
  link?: CardLink;
};

/** A level that asks for something — every one but `auto`. */
export type ExplicitLevel = Exclude<ReasoningLevel, "auto">;

export type Expression = {
  id: string;
  /**
   * What this face is called — on its tile, and in the retrieval hub's ranked stack.
   *
   * Ranked *with* the description rather than beside it. A reader who types "furious" as the
   * title and leaves the description empty has said what the face is for, and a name that
   * counted for nothing while an identical word two fields down decided everything is the
   * drift this repo keeps deleting. `expressionText` is the one place that joins them.
   */
  title?: string;
  /** What the ranker reads. Empty means this face is kept but never chosen. */
  description: string;
  /** A data URL at `PORTRAIT_MAX_DIM`. `null` on the default row only — see above. */
  image: string | null;
  /**
   * One transform, two crops. An expression is drawn as a circle on a bubble and as a
   * square panel, so the crop stage shows both outlines at once and a single pan/zoom is
   * judged against each. Absent on the default row means the portrait's own transform.
   */
  transform?: ImageTransform;
};

/**
 * How big a face is drawn on a bubble.
 *
 * `circle` is the ordinary profile picture every chat has always had. `large` is the
 * portrait frame — taller than wide, the shape a visual novel puts a character in, and the
 * same rectangle the character editor crops to. It is the reason the crop stage shows two
 * outlines: one transform has to work in both.
 */
export type ExpressionAvatarSize = "circle" | "large";

/** What a face count reads of a face: never its picture. */
export type FaceText = Pick<Expression, "id" | "title"> & { description?: string };

/**
 * **The provider's own stop reason, and whether it is one a reply ends on of its own accord.**
 *
 * Read so an empty reply can be told apart from an empty *response* (`refuseUnfinishedEmpty`): a
 * recorder with nothing to record answers "" and stops (`stop`, `end_turn`), while a provider short
 * of capacity answers "" too — DeepSeek with `insufficient_system_resource`, a gateway under load
 * with no stop reason at all. Taking both as "nothing to record" marked a span of story read with no
 * facts written from it, and nothing ever read it again. `reason` is the provider's word, kept to
 * say what happened; `normal` is decided here, once, for every caller.
 */
export type Finish = { normal: boolean; reason: string };

/**
 * **Where the floor is — derived, on your own and at a table.**
 *
 * The table used to *hold* this: a `MicState.holder` the host advanced door by door, beside a
 * chat whose own turn state said the same thing a second way. Six doors in the room store each
 * moved the holder by the mode, and every table bug TURNS.md §21–§26 records was two of those
 * doors disagreeing — or the holder naming a seat the chat no longer had (`floorIsStranded`, a
 * whole predicate for noticing it). Whose turn it is is already on the chat: the turn is held for a
 * person's card, or owed to a voice. This reads it, so a stranded holder is not a state there is.
 */
export type FloorInput = {
  chat: Chat;
  /** The rules in force. */
  rules: TurnRules;
  /** The table, or null on your own. */
  table: MicTableView | null;
  /** The window's tally as the room holds it, or null. Stale tallies are ignored (`windowFor`). */
  window: WindowTally | null;
  /** The run in flight: `isGenerating` and `generatingSpeaker` from the pipeline slice. */
  generating: { active: boolean; speakerId: string | null };
};

/**
 * **Where the table stands, derived** — `lib/mic/floor.ts` builds it from the chat and the run.
 *
 * `up` is the person's seat, or `TABLE_SEAT`, whose turn it is; null when the turn is a voice's or
 * nobody's. `gap` is the story stopped between two AI voices (Next turn, or a pause). `open` is the
 * people's turn with no particular person's place up — a round of voices that ran out, a story
 * nobody has started — which anyone may take.
 *
 * `open` is said rather than read off `up === null`, because null also means "a voice is owed the
 * turn and has not started writing", and a gate that read the two the same let anybody talk over a
 * round set to carry straight on, or over a table with the AI switched off.
 */
export type FloorView = {
  up: Seat | null;
  writing: boolean;
  gap: boolean;
  open: boolean;
  window: WindowTally;
};

/**
 * What a shelf's folder is: a folder, or — a folder of world cards being a lorebook — a lorebook,
 * drawn as a book, and owned by the characters whose `lorebooks` name it. A word rather than a
 * component, for the reason `BadgeTone` is: `lib/` says which, and the component that draws a folder
 * (`FolderGlyph`) owns the picture.
 */
export type FolderKind = "folder" | "lorebook";

/** A shelf's folder words and kind — see `Library.folders`. */
export type FolderWords = { singular: string; plural: string; kind: FolderKind };

/** A font the app or a chat is set in: one of the four shipped families, or one the reader added. */
export type FontChoice = FontFamilyOption | UserFontId;

export type FontFamilyOption = "sans" | "serif" | "mono" | "rounded";

export type FontSizeOption = "xs" | "sm" | "base" | "lg";

/**
 * A replace's plan as it was when proposed: the places it changes and the addresses it left for a
 * later one (past the cap) — or why it could not be planned, which the apply then says.
 */
export type FrozenReplace = { places: ReplacedPlace[]; left: string[] } | { problem: string };

/**
 * **What a chat last asked a model for** — SillyTavern's `{{lastGenerationType}}`: `normal` for a
 * line sent, `regenerate` for a retry, `swipe` for a new take, `quiet` for an agent run by hand.
 *
 * Told by the door the request went through (`hooks/useChatEngine.tsx`), never worked out from the
 * chat afterwards: a retried reply and a fresh one look alike once they land. Noted by the
 * orchestrator when the run takes the slot, from the start event the door sent: a door noting it
 * before the wait wrote it under whatever run was still building prompts, and a run the machine
 * started noted nothing and read the last door's answer. Kept in memory for
 * the page's life, per chat — SillyTavern forgets it when the chat changes, and here each chat
 * keeps its own — and read by the prompt build, which is a leaf that cannot ask the doors.
 */
export type GenerationType = "normal" | "regenerate" | "swipe" | "quiet";

/**
 * **Whether these records are here whole, and if not, why not.**
 *
 * - `"held"`: every one is here, answered once it is.
 * - `"none"`: the PC answered, and some are not among what it holds — or this device keeps everything,
 *   so it holds every record the PC has, and one it lacks is one there is not.
 * - `"unreachable"`: the PC could not be asked, or its answer could not be read. Nothing is known about
 *   the record, and a screen must not say it is not in the library: on flaky Wi-Fi it was, and the
 *   reader was told their chat did not exist.
 *
 * Asked before reading a record the screen has only a listing of; a caller that goes on to read it
 * registers it first (`holdWhile`, `keepOpenWhile`), or it may be let go again before it is read.
 */
export type HeldAnswer = "held" | "none" | "unreachable";

/**
 * The documents a surface holds, whether a picture may join them — the chat's Vision switch — and
 * what they may be: the chat's limits (`attachmentLimits`), asked when a file arrives.
 */
export type HeldDocuments = {
  files: readonly MessageFile[];
  setFiles: (next: MessageFile[]) => void;
  pictures: boolean;
  limits: () => Omit<AttachmentLimits, "maxPictures" | "pictureMaxDim">;
};

export type HiddenInjection = {
  /**
   * The note's own name, and the only way to address one.
   *
   * Everything used to address a note by the turn it sat at, which is not a name: three
   * notes sit at one turn the moment the Director writes one for Ana, one for Ben and one
   * for the narrator. Deleting any of them deleted all three, editing any of them rewrote
   * all three, and filing a second note against a turn *replaced* the first without a word.
   *
   * When the note comes from a proposal this is the action's id, so approving the same
   * action twice files the same note twice rather than two notes — the duplicate that
   * `commitSingleActionViaBundle` was written to stop is now unrepresentable rather than
   * guarded against.
   */
  id: string;
  /**
   * The message this note follows; `null` sits it above the whole transcript.
   *
   * Not an index into `messages` — see `lib/chat/injections.ts` for the four hand-written
   * re-keying rules that disagreed while it was one, and which of them the reader saw.
   */
  afterMessageId: string | null;
  content: string;
  directorMessageId?: string;
  /** Whose prompt this note is for. **Absent is the default and means everyone's.** */
  targetCharacterId?: string;
  /**
   * How many more replies this note steers before it leaves the prompt. **Absent is the
   * default and means forever** — a standing rule rather than a nudge.
   *
   * *Replies*, not messages, and that is the whole of why it is spelled this way: the
   * reader writes a note, then types their line, then the model answers. Counted in
   * messages, the reader's own line would spend a one-turn note before anything had read
   * it, and the shortest lifetime the feature offers would be the one that never works.
   *
   * Nothing decrements it. What has been spent is counted off the transcript by
   * `repliesLeft`, because a stored countdown is a second copy of "how far the story has
   * moved since this note" and the two would part company at the first rewind — the note
   * would come back with the turns and stay dead. Rewinding, retrying and swiping all put
   * a spent note back in force by construction, since the replies that spent it are gone.
   */
  lifetimeReplies?: number;
  /**
   * The account that wrote it, at a shared table. **Absent is the default and means the
   * host's** — which is every note in a solo story and every note the story's owner writes.
   *
   * An owner id (`lib/auth/owner.ts`), not a character: a note is not spoken by anybody, and
   * tying it to a card would make "mine" wrong the moment its author claimed somebody else.
   * It is what lets a note be visible to the person who wrote it whatever the table's
   * visibility policy says, which is the one rule no policy may override.
   */
  authorOwnerId?: string;
  /**
   * Set by the host when it hands a note to somebody it is not for: the addressing and the
   * lifetime stand, the **text is gone**, and the card draws a lock.
   *
   * Only ever written by `noteForGuest`, on the way out of the host's tab. Redacting on the
   * screen that draws it instead would make "sealed" a promise the wire breaks — the text
   * would be a console away — so this is what arrives, not what is filtered.
   */
  sealed?: true;
};

/**
 * How each kind of card spells its id: what it falls back to when the name reduces to nothing,
 * and how much of a long name it keeps.
 *
 * A character has no prefix and no cap, because `characterIds` is the name the reader and the
 * model both write — a card called Ana is `ana`, and the Director addresses it by that. The
 * rest are prefixed so a bare id says what kind of thing it is in a lookup or a state change.
 */
export declare const ID_KINDS: { readonly character: { readonly prefix: ""; readonly fallback: "character"; readonly maxLen: undefined; readonly namespace: "card"; }; readonly arc: { readonly prefix: "arc"; readonly fallback: "arc"; readonly maxLen: 28; readonly namespace: "arc"; }; readonly world: { readonly prefix: "world"; readonly fallback: "world"; readonly maxLen: 28; readonly namespace: "card"; }; readonly face: { readonly prefix: "face"; readonly fallback: "faces"; readonly maxLen: 28; readonly namespace: "face"; }; readonly prompt: { readonly prefix: "prompt"; readonly fallback: "prompt"; readonly maxLen: 28; readonly namespace: "prompt"; }; readonly background: { readonly prefix: "bg"; readonly fallback: "background"; readonly maxLen: 28; readonly namespace: "background"; }; readonly font: { readonly prefix: "font"; readonly fallback: "font"; readonly maxLen: 28; readonly namespace: "font"; }; };

export type IdKind = keyof typeof ID_KINDS;

/**
 * **How a picture the reader sends reaches the story.**
 *
 * Two ways, and they are a choice rather than a pair of switches because exactly one of
 * them is true of any line:
 *
 *  - `described` — the Vision agent is shown the picture once and says what it shows, and
 *    *that sentence* is what every writing agent reads in the picture's place. Any model can
 *    write the story; one request per picture, ever.
 *  - `picture` — the Writer is sent the picture itself, on every turn the line is in its
 *    window. Only a model that takes images can, and it costs the picture's tokens each time;
 *    the other agents still read a marker, and can ask the Vision agent through `<look>`.
 *
 * `enabled` is the one switch: off, there is nothing to attach and no tool to look with. It
 * is written by the Vision card in Connection and read by the composer, the builders and the
 * `look` tool, and nothing else decides it.
 *
 * `generate` is the other switch, and a separate fact: whether the story may *make* a picture
 * — the Image Writer's card, and the `generate_image` tool's paragraph in the Writer's and
 * the helpers' stacks. A chat can draw without looking and look without drawing.
 *
 * How much of the story the Image Writer is shown is **not here**. It was — `historyTurns`, a
 * number box beside the card — and it was the one agent whose history window lived outside
 * Context master. It is `imageWriterVisibility.rawHistory` now, the same field and the same
 * screen as every other agent's.
 */
export type ImageSettings = {
  enabled: boolean;
  uploads: "described" | "picture";
  generate: boolean;
};

/**
 * ...and the circle carries its own.
 *
 * One region cannot describe both frames. `object-cover` resolves against the box it is
 * given, so a 1:1 avatar and a 3/4 portrait built from the same numbers show *different*
 * parts of the picture — which is why the crop dialog's ring, drawn over a 3/4 stage, could
 * not tell the truth about what a bubble would draw.
 *
 * These are two facts, not two copies of one: where the portrait sits in its frame, and which
 * part of it is the face. The reader places the ring and `regionForRing` turns it into this,
 * so what is stored is the answer the ring gave rather than a second thing that has to agree
 * with it.
 *
 * **Absent means "the same crop as the portrait"** — exactly what every picture rendered
 * before there was a ring, so no stored card changes and none of them grows a key. `AVATAR_SHAPES`
 * says which shapes read it; `portraitStyle` is where it is resolved, once.
 */
export type ImageTransform = CropRegion & {
  avatar?: CropRegion;
  /**
   * What fills the frame where the picture does not reach and behind its transparent pixels —
   * a `#rrggbb` colour. **Absent is transparent**: whatever is behind the picture where it is
   * drawn shows through, which is what every picture did before there was a choice. One value
   * for both of the picture's frames, since it is a fact about the picture, not about a crop.
   */
  fill?: string;
  /**
   * Whether the frame is locked to image boundaries. **Absent means locked (true)** —
   * false allows panning and zooming past boundaries into void.
   */
  locked?: boolean;
};

/**
 * **A block sent among the story's turns, at a depth** — a paragraph (its words, its role, its
 * switch, its condition) that stands where the turns are rather than where its card is.
 *
 * `depth` counts the turns as sent, from the end: 0 is after the last turn, 1 before it, and a depth
 * past the first turn the history carries puts it at the top of the history. It has no `order`: the
 * Chat History card's `inserts` array is the order, and two at one depth go in it. It grants no
 * tools — its card is the transcript's, and the transcript's card grants none.
 */
export interface InsertBlock {
  id: string;
  title: string;
  content: string;
  role: PromptRole;
  enabled: boolean;
  /** When it is in at all — as a block's `condition`, read by `blockIsFor`. */
  condition?: string;
  depth: number;
}

/**
 * **One thing said on a wire** — a room intent at a table, a run frame between the owner's own
 * devices. The outbox only needs its kind (what supersedes what) and stamps its name.
 */
export type Intent = {
  kind: string;
  data?: unknown;
  /**
   * **This event's own name, so a retry cannot happen twice.**
   *
   * Stamped by the outbox on every `event`, and read on the far side (the room store, at a
   * table), which drops a second arrival from the same sender. A POST that
   * reached the room and lost its answer on the way back reads, to the sender, exactly like one
   * that never arrived — so it is sent again, and the room carries both. Every intent a guest
   * sends is an `event`, and none of them was safe to apply twice: a line committed twice, an
   * edit to chunk 2 of a reply applied to the chunk that had moved into its place.
   *
   * Absent on `state` and `frame`, which are values and pictures: the second copy of one says
   * what the first did.
   */
  eventId?: string;
};

/** A fence that closed and could not be used, and the sentence for the model. */
export type JsonProblem = { index: number; raw: string; tag: string; detail: string };

export declare const KIND_APPROVAL: { readonly world_add: { readonly approval: "setting"; readonly autoApply: false; readonly permission: "world_add"; }; readonly character_add: { readonly approval: "setting"; readonly autoApply: false; readonly permission: "character_add"; }; readonly state_update: { readonly approval: "setting"; readonly autoApply: false; readonly permission: "state_update"; }; readonly arc_add: { readonly approval: "setting"; readonly autoApply: false; readonly permission: "story_arc"; }; readonly arc_update: { readonly approval: "setting"; readonly autoApply: false; readonly permission: "story_arc"; }; readonly memory_add: { readonly approval: "setting"; readonly autoApply: false; readonly permission: "memory"; }; readonly memory_update: { readonly approval: "setting"; readonly autoApply: false; readonly permission: "memory"; }; readonly memory_node: { readonly approval: "setting"; readonly autoApply: false; readonly permission: "memory_tree"; }; readonly summary_proposal: { readonly approval: "setting"; readonly autoApply: false; readonly permission: null; }; readonly agent_add: { readonly permission: "agents"; readonly approval: "reader"; readonly autoApply: false; }; readonly agent_update: { readonly permission: "agents"; readonly approval: "reader"; readonly autoApply: false; }; readonly agent_remove: { readonly permission: "agents"; readonly approval: "reader"; readonly autoApply: false; }; readonly boost_card: { readonly approval: "setting"; readonly autoApply: false; readonly permission: "boost_card"; }; readonly notebook_set: { readonly permission: "notebook"; readonly approval: "setting"; readonly autoApply: true; }; readonly state_define: { readonly approval: "setting"; readonly autoApply: false; readonly permission: "states"; }; readonly state_delta: { readonly approval: "setting"; readonly autoApply: false; readonly permission: "states"; }; readonly state_transfer: { readonly approval: "setting"; readonly autoApply: false; readonly permission: "states"; }; readonly link_cards: { readonly approval: "setting"; readonly autoApply: false; readonly permission: "states"; }; readonly replace: { readonly approval: "setting"; readonly autoApply: false; readonly permission: "replace"; }; readonly registered: { readonly permission: null; readonly approval: "reader"; readonly autoApply: false; }; };

/**
 * **Dice, resolved in code and never by the model.**
 *
 * A story reaches moments whose outcome should not be the writer's to pick — an attack, a
 * search, a persuasion, a leap — and a model asked to "roll" writes the number it wants. So the
 * roll is a *query*: the model names the dice and the target, the app draws the numbers, and
 * the result comes back as an observation the model then writes the scene from. Nothing about a
 * roll is a proposal — a die is not a change to the world; what the writer does with it is.
 *
 * Standard notation, deliberately small: `NdS` terms and constants joined by `+` or `-`
 * (`1d20+3`, `2d6`, `d100`, `3d6+1d4-1`). Limits are stated rather than clamped, because a
 * clamped `100d1000` would answer a question nobody asked.
 */
export type KeepMode = "kh" | "kl" | "dh" | "dl";

export type KeepRule = { mode: KeepMode; n: number };

/**
 * **The last run of a chat, as the progress box last drew it** — its roster with how each agent
 * ended, and the words each one last wrote. The pipeline forgets all of it at rest
 * (`PIPELINE_AT_REST`) and forgets an agent's words the moment it finishes (`rosterRows` reads a
 * stream only while its agent runs), so a box kept up after the turn had nothing to show.
 */
export type KeptRun = {
  run: PipelineState;
  /** Still being written — the next frame of a run in flight joins it rather than starting another. */
  live: boolean;
  /** When it came to rest, or null while it is live. */
  endedAt: number | null;
};

export type KindTable = typeof KIND_APPROVAL;

/**
 * **The least and most a knob is sent as**, where a wire documents a range narrower than the
 * slider's (`SAMPLER_FIELDS`). A value past it is sent as its edge, and the slider stops there too
 * (`samplerSent`) — Anthropic answers a temperature of 1.5 with a 400.
 */
export type KnobRanges = Partial<Record<SamplerKnob, readonly [min: number, max: number]>>;

/**
 * **How a shelf's level can be drawn, and whether that drawing has room for a picture** — the one
 * table the browser reads to decide whether a folder previews its cards, and the test reads to hold
 * each shelf's `layout` to whether its records carry a picture.
 */
export declare const LAYOUT_PICTURES: { readonly grid: true; readonly list: false; readonly blocks: false; };

/** The rows `mayActOnMessage` reads — a screen drawing a line's edit and delete subscribes to them. */
export declare const LINE_RIGHTS: readonly ["editOwnLines", "deleteOwnLines", "editAnyLine", "deleteAnyLine"];

/** What a screen may be told about the door — the hash is not in it. */
export type LanStatus = {
  enabled: boolean;
  username: string;
  hasPassword: boolean;
  /** The shortest password the switch takes, so the screen's hint is this file's number (`LAN_PASSWORD_MIN`). */
  passwordMin: number;
  /** The port the network reaches this server on, so the screen can print a whole address. */
  port: number | null;
  /** The port the reader chose, or null when the network shares the main server's. */
  customPort: number | null;
  /** This machine's addresses on its networks, IPv4, as a phone would type them. */
  addresses: string[];
  /**
   * Whether something is actually listening on those addresses — the stored switch is a wish
   * until the listener is up, and the screen says the difference (`lib/server/lan-listener.ts`).
   */
  listening: boolean;
  /** Why the listener could not open, in a sentence, or null. */
  error: string | null;
};

/** Levels a model family takes, and how it is told to stop — or `null`, a model that does not reason. */
export type LevelRule = {
  levels: readonly ExplicitLevel[];
  /** The body fields that stop it thinking. Absent: it cannot be stopped, or it is not safe to try. */
  off?: Readonly<Record<string, unknown>>;
  /** What it does when no level is sent, where the provider documents it — said beside "Model default". */
  default?: ModelDefault;
} | null;

/**
 * A shelf, its records `T` and what its rows know of a record (`L`, its listing: `lib/library/listing.ts`).
 * A shelf held whole has no listing of its own, and its `L` is its record. The rows' drawing reads `L`,
 * so one function draws a card held whole and a card held only as its listing; what reads `T` reads a
 * card whole.
 */
export type Library<T extends LibraryRecord = LibraryRecord, L extends LibraryRecord = T> = {
  id: LibraryId;
  /** Where it is stored and synced. The only place this is spelled. */
  key: SyncCollection;
  /** What the shelf is called on screen. */
  label: string;
  /** What one record is called, for a button that acts on one. */
  singular: string;
  /** What several are called — "Export 5 characters". Its own word, since "sets of faces" is no `s` away. */
  plural: string;
  /**
   * **What a folder on this shelf is, and what it is called** — a folder, or on the world shelf a
   * lorebook, which is what a folder of world cards is (round 2026-10-02, 2.1). Every folder word the
   * shelf says is spelled from this — "New lorebook", "Delete lorebook", "1 lorebook", "Find a
   * lorebook…" — and its kind is how it is drawn (`FolderGlyph`). Read off the row as `counted` reads
   * `singular` and `plural`, never by a branch on the shelf's name.
   */
  folders: FolderWords;
  /**
   * **Which kind of card this shelf's records are**, where they are cards at all — a character or a
   * world card, which leave as the card formats (`CARD_EXPORT_FORMATS`) and are what a Dahlia file
   * and a link name. Absent on a shelf of anything else: its records leave as the record they are.
   *
   * A declaration rather than `shelf.id === "characters"` wherever a card's kind is asked, for the
   * reason `choice` gives: a shelf's name in logic is a second shelf's second branch.
   */
  cardKind?: CardKind;
  /**
   * **Whether a preset file picked on this shelf lands its prompt blocks here**, as a folder named
   * for the preset (`landPresetOnPromptShelf`) — the prompt shelf's, as a lorebook file lands on the
   * world shelf. A declaration for the reason `cardKind` gives; the import screen lands them too.
   */
  takesPresets?: true;
  /**
   * **What a card on this shelf leads its row with**, on a shelf drawn as rows (`layout` "list" or
   * "blocks"), where a picture would be — and what its select circle stands in for (`TileSelect`).
   * A name rather than a drawing, as `edit.portrait` is: the row is in `lib/`, and the drawing is
   * `ROW_GLYPHS`'.
   */
  glyph?: CardGlyph;
  /** Shown when the shelf is empty, and it says how something gets onto it. */
  emptyHint: string;
  /**
   * How a level of this shelf is drawn: a grid of picture cards, or a list of rows. Grid when
   * absent, which is what every shelf with a portrait on it wants.
   *
   * "Since story arcs don't have images so a grid doesn't really make sense." A grid is an
   * `aspect-[3/4]` gallery, and a gallery whose every card is the same stand-in silhouette is
   * five columns of identical grey rectangles with a title under each — the picture is the only
   * thing a grid is for, and a shelf that has none is paying its whole width for nothing.
   *
   * It is not a free choice: `tests/unit/library.test.ts` holds it to whether the row offers a
   * picture *at all* (`edit.portrait` or `edit.portraitFrom`), in both directions, through
   * `LAYOUT_PICTURES`. A list row draws no picture, so a shelf claiming both would be drawing a
   * card it cannot fill; and a grid with nothing to put in it is the thing this exists to stop.
   *
   * **`blocks` is the prompt shelf's**: each record a row in the stack's frame — its name, the tags
   * that say what it is, and a line of what it says — in one column, with a pane beside it showing
   * the whole of the block or folder pointed at (round 2026-10-30C made the shelf and the import
   * picker draw blocks one way; round 2026-10-30D made it a list and a pane, `ShelfPreview`).
   */
  layout?: ShelfLayout;
  /** The cards held whole — every card, on a device that keeps everything. What reads a card's text reads this. */
  read: () => T[];
  /**
   * **Every card on the shelf, as its rows draw it** (`shelfListings`): a card held whole as itself,
   * and a card a device keeping what is open holds only as its listing as that — a record-shaped
   * subset (`lib/library/listing.ts`) the row's own `nameOf`, `faceOf` and `subtitleOf` draw, filed
   * by `folderId` and `order` like any card. What a grid, a count, a name check or a move reads. A
   * screen that needs the card's text or its files asks for it whole (`withWholeCards`), and a write
   * made from a listing is folded over the card fetched whole (`saveMany`), so a listing is never
   * written as the card. On a device that keeps everything, and on a shelf held whole, it is `read`.
   */
  listings: () => L[];
  write: (items: T[]) => void;
  /**
   * Make a raw record whole.
   *
   * On the row because records reach a shelf from three directions — the reader's own edit,
   * the server's copy at boot, and an imported file — and only the first is already whole.
   * The import path skipped this at first, so a file missing a field handed the grid a card
   * with a blank heading and no error anywhere; the reason `read` is safe is that every record
   * is made whole as it arrives, and an import is another device's copy arriving by another route.
   */
  normalize: (raw: Partial<T>) => T;
  /**
   * **Whether a raw record is one of this shelf's at all** — asked of a file before `normalize`
   * makes it whole.
   *
   * `normalize` defaults every field it does not find, which is right for a record that is
   * merely missing one and wrong for a record that was never this kind: a character card, a
   * chat export or a lorebook picked on the prompt shelf's Import button became a row of
   * "New prompt block"s, and the toast counted them as imported. Each row names the field
   * only its own records carry; `tests/unit/library.test.ts` holds every shelf to refusing
   * every other shelf's record.
   */
  accepts: (raw: unknown) => boolean;
  /**
   * Write a record, and hand back the record **as filed** — under a free name, which may not be
   * the one it was given (`fileOnShelf`). Returned because a screen holding the record has to
   * show what the shelf kept: the card editor went on saying "Bel" over a card the shelf had
   * filed as "Bel (2)".
   */
  save: (item: T) => T;
  /**
   * **Write back an edit made to a copy held across time** — `base` the copy the screen opened or
   * last saved, `edited` that copy with the reader's edit — folded over whatever the shelf took
   * since (`editedOver`), then filed as `save` files it. What a card editor writes through: saving
   * its draft whole reverted another device's edit that arrived while it was open, with nothing
   * said. `save` is for a record made whole from what the shelf holds now.
   */
  saveEdited: (base: T, edited: T) => T;
  /** One card off the shelf, held whole or only listed — `removeMany` of one. */
  remove: (id: string) => void;
  /**
   * **Several records written — and, given, several taken off — in one write**, each filed as `save`
   * files one: under a name free on the shelf *as the ones before it left it*, so a batch cannot
   * file two cards under one name. Returns the records as filed.
   *
   * One storage write, one sync delta and one event however many cards a gesture touches (round
   * 2026-10-02, 2.3): a selection of twelve moved through `save` was twelve of each, and twelve
   * re-reads of every open grid, for one press.
   */
  saveMany: (items: readonly T[], removing?: readonly string[]) => T[];
  /**
   * **Whole records written over cards that may be held only as their listing** — a second "Save to
   * shelf" over the card the first made. The cards are fetched whole first and replaced, as a save
   * over a held card is. Answers once it has written: what was filed, and why any was not.
   */
  saveOver: (items: readonly T[]) => Promise<ShelfWrite<T>>;
  /**
   * **Edits made on a screen that drew the cards** (`ListedEdit`: what it drew, and that with the
   * change) — a move, a renumbering, a lorebook given — folded over each card whole, fetched first
   * where it is only a listing. Answers once it has written; the door says why a card was not.
   */
  editListed: (edits: readonly ListedEdit<L>[], removing?: readonly string[]) => Promise<ShelfWrite<T>>;
  /** Several records off the shelf in one write — `saveMany` with nothing to save. */
  removeMany: (ids: readonly string[]) => void;
  /**
   * **Put a record on the shelf as a card of its own**, and hand back the record as filed.
   *
   * `save` is an edit: it writes whatever id it is given, and the store matches by id. Every
   * *arrival* went through it too, each caller minting an id against whatever it remembered to
   * pass — the Hub's import passed nothing and minted `ana` onto a shelf holding an Ana, "Save
   * to your character shelf" wrote a chat's `ana` over a different shelf Ana with the same
   * slug, and the faces editor minted `face-ana-s-faces` a second time over the first set.
   * Each save kept the name unique and overwrote the record anyway, because the name rule
   * excludes the record's own id and the id was the other card's.
   *
   * So the taken set belongs to the thing that stores: a free id is kept, a taken one (or a
   * uuid, or one that spells a role) is minted from the name against every id in the shelf's
   * id space — the character and world shelves share one, because a link names a card by id
   * alone. Returned so a caller can open, file or toast the card it actually made.
   */
  add: (item: T) => T;
  /**
   * **Several records put on the shelf as cards of their own, in one write** — each id kept or
   * minted against every id in the shelf's id space *and the ones minted before it*, so two files of
   * one card land as two cards. What an import of several files lands through.
   */
  addMany: (items: readonly T[]) => T[];
  /** Which kind of id this shelf's records carry — how `add` mints one, and which shelves share its namespace. */
  idKind: IdKind;
  /** The heading on a card, and what the search box matches first. */
  nameOf: (item: L) => string;
  /**
   * The same record under a different name.
   *
   * The partner to `nameOf`, and the reason `save` can promise a shelf never holds two cards
   * with one name: the generic code can read a name off any shelf, but until this existed it
   * could not *write* one, so the "(2)" rule would have had to be written once per shelf
   * against three different field names. `tests/unit/library.test.ts` walks the rows and
   * demands `nameOf(rename(x, "n")) === "n"` — a row that renames the wrong field fails
   * without anybody remembering to check it.
   */
  rename: (item: T, name: string) => T;
  /** Also matched by the search box — a roster this deep is unusable by name alone. */
  tagsOf: (item: L) => string[];
  /** The card's picture, or null for a record that has none. */
  faceOf: (item: L) => { image: string | null; transform?: ImageTransform };
  /**
   * The line under the name. Faces use it for the count, which is the whole of the reader's
   * "add a visual for how many facial expressions it has".
   */
  subtitleOf: (item: L) => string | undefined;
  /** What a record can be edited as, on the shelf itself. See `LibraryEdit`. */
  edit: LibraryEditing<T>;
  /**
   * **A picture file, as one of this shelf's records** — on a shelf whose records *are* pictures,
   * the background shelf (round 2026-10-07). Present, the shelf's Import takes picture files as well
   * as its own JSON — each one a record named after the file, its picture stored at the size its kind
   * is stored at (`pictureMaxDimFor`) — and its export offers the pictures themselves. Absent on every
   * shelf whose picture is one field of a card.
   */
  fromPicture?: (name: string, image: string) => T;
  /**
   * The tag in the corner of a card, or nothing.
   *
   * Data, not a component: `lib/` returns the words and a `Badge` tone, and the grid renders
   * them. A row that returned JSX would put React in the storage layer, and a row that
   * returned a colour would ignore the theme.
   */
  badgeOf?: (item: L) => { text: string; tone: BadgeTone } | undefined;
};

/**
 * A change to a record, in the terms every shelf shares.
 *
 * The docblock at the top of this file used to say editing was deliberately absent, because
 * "a character detail pane and a world detail pane have almost nothing in common". That is
 * still true of the *chat's* managers — states, activation, faces, in-chat toggles — and it
 * was never true of the four things a card has when it is sitting on a shelf: a name, one
 * long piece of text, some tags, and a picture. Those are what this covers. Everything
 * type-specific stays in the manager it was already in.
 *
 * Presence matters, not truthiness. `image: null` clears the picture and `imageTransform:
 * undefined` resets the crop, so a row that read `change.image ?? item.image` would make
 * removing a portrait impossible — the failure that this shape makes unwritable.
 */
export type LibraryEdit = {
  body?: string;
  tags?: string[];
  image?: string | null;
  imageTransform?: ImageTransform;
};

/**
 * **A library edit pressed at a seat that does not hold the chat.**
 *
 * **`fields` is what makes it an edit rather than an overwrite.** A manager builds its save as
 * `{...base, ...partial}` where `base` is the seat's own (possibly stale) copy, and `upsertEntity`
 * does `list[idx] = normalize(entity)` — no merge, no comparison. So a guest editing a card's lore
 * silently reverted every state change the host had applied since their last snapshot, with no
 * `StateChange` recorded, so nothing could undo it. So the seat names the keys it actually changed
 * and the holder takes only those, onto its own current record. Absent means a card that did not
 * exist there — nothing to clobber, and the whole record is the edit.
 */
export type LibraryEditPayload =
  | {
      entity: "character" | "world";
      action: "upsert";
      record: Record<string, unknown>;
      fields?: string[];
    }
  | { entity: "character" | "world"; action: "delete"; id: string }
  | { entity: "character" | "world"; action: "setActive"; id: string; active: boolean }
  | { entity: "character"; action: "absorb"; id: string }
  | { entity: "folder"; of: "world" | "character"; action: "upsert"; record: ChatFolder }
  | { entity: "folder"; of: "world" | "character"; action: "delete"; ids: string[] };

export type LibraryEditing<T> = {
  /**
   * **The card's own fields**, when this shelf's records have a table of them rather than one
   * long body — `lib/cards/fields.ts` is where they are written.
   *
   * A descriptor rather than `if (shelf.id === "characters")` in the editor, for the reason
   * `choice` gives one line down: a literal shelf name in logic is the same mistake as a
   * literal agent name, and it is why a second shelf with fields is a second row and not a
   * second branch.
   *
   * A shelf declares this **or** a body, never both — the character shelf's body *is* its
   * description, so drawing the body box beside a field table that now leads with Description
   * would be two controls over one string. `bodyOf` stays on the row because it is still the
   * honest answer to "what is the text on this card", which the grid and the export ask; what
   * it no longer is, on a shelf with fields, is a *control*.
   */
  fields?: readonly CardField<string>[];
  /**
   * **Its records are prompt blocks**: the body is a prompt's text, written in the box Prompt master
   * writes one in (`PromptTextArea` — every macro and every tool tag offered as you type), and a
   * role is sent with it (the editor's Role select). A declaration for the reason `fields` gives;
   * the editor asked `shelf.id === "prompts"` for both.
   */
  prompt?: true;
  /** The one long text field, or absent on a shelf whose records have none. */
  bodyLabel?: string;
  bodyHint?: string;
  bodyOf?: (item: T) => string;
  /**
   * Which silhouette stands in for a missing picture — and, by being here at all, that the
   * picture is the record's own to change. It is also what the picture is *of*, which decides its
   * frame and its size (`TILE_FRAME`, `pictureMaxDimFor`): a background lies 16:9 and is stored for
   * a screen.
   */
  portrait?: "character" | "world" | "background";
  /**
   * A picture the record *has* and does not own: where it comes from, in the words printed
   * under it. The rail is drawn and cannot be edited.
   *
   * This and `portrait` are two halves of a question the editor used to ask as one. The absence
   * of `portrait` meant both "not yours to change" *and* "there is one anyway", so the only
   * shelf whose cards have no picture at all — the story shelf — was given a silhouette of a
   * person under the sentence "a set's picture is the first face in it", which was never true
   * of a story card and was spelled in the editor besides. A row with neither field gets no
   * rail, and the caption is drawn by the same branch as the rail it captions.
   */
  portraitFrom?: string;
  /** One writer per row, so a newly editable field is one line here rather than three. */
  patch: (item: T, change: LibraryEdit) => T;
  /**
   * A small fixed choice the record carries — the arc's kind, and nothing else so far.
   *
   * A descriptor rather than `if (shelf.id === "arcs")` in the editor. A literal shelf name
   * in logic is the same mistake as a literal agent name, and it is the reason a second
   * shelf with a dropdown would be a second branch instead of a second row.
   */
  choice?: {
    label: string;
    hint?: string;
    options: readonly { value: string; label: string }[];
    of: (item: T) => string;
    set: (item: T, value: string) => T;
  };
  /**
   * A list of faces the record *is* — where a character has a description and a world has its
   * lore, a set has these.
   *
   * Another descriptor rather than a shelf name in a branch, and the reason this one exists at
   * all is that the shelf could hold sets nobody could open: the editor said "a set's picture
   * is the first face in it; edit the faces on a character", so fixing one word in a saved set
   * meant applying it to somebody, editing it there and saving a second set. The editor is
   * `FaceEditor`, the same one the character manager renders.
   */
  faces?: {
    hint: string;
    of: (item: T) => Expression[];
    set: (item: T, faces: Expression[]) => T;
  };
};

/**
 * Which shelf — what you have saved outside any one chat, to drop into the next one.
 *
 * Here rather than in `lib/library/registry.ts`, where it was, because `LibraryFolder` below
 * needs it and this file imports nothing: a stored shape that had to reach into `lib/` for a
 * type would put a cycle between the registry, storage and the folders module, and the three
 * of them already point at each other in the other direction.
 */
export type LibraryId = "characters" | "worlds" | "faces" | "arcs" | "prompts" | "backgrounds";

/**
 * The one thing every shelf's records share, and all the generic code may assume.
 *
 * `folderId` is one of them now: where a record is filed is the same question on every
 * shelf, so the browser can move a card between folders without knowing what kind of card it
 * is holding. It is optional and carried, never defaulted — see `Character.folderId`.
 *
 * `order` is where it sits *within* that folder, and `lib/library/ordering.ts` is the only
 * thing that reads or writes it. Absent means "nobody has placed this one", which sorts to the
 * end of its level — so a card that has never been dragged serialises exactly as it did, and
 * every shelf that nobody has arranged looks exactly as it did.
 */
export type LibraryRecord = { id: string; updatedAt?: number; folderId?: string; order?: number };

/** The formats, by the `ChatSettings.lineFormats` key each is stored under. */
export type LineFormatId =
  | "directorNote"
  | "playerActions"
  | "recentChange"
  | "memoryRead"
  | "memoryFile"
  | "memoryBranch"
  | "memoryChanged"
  | "faceMatch"
  | "cardMatch"
  | "askAnswer"
  | "askDeclined";

export type LineFormats = Record<LineFormatId, string>;

/**
 * Where a press stands to place its line: the reveal's cursor, and — for a press that stopped the
 * Writer mid-reply — which reply it stopped (`pipelineOrchestrator.interrupt`). A projection stops
 * nothing, so it has no `writing`.
 */
export type LinePlace = Pick<ComposerSend, "cursor" | "typing"> & { writing?: string | null };

/**
 * **Two cards bound together, or a bond taken off.**
 *
 * A link *is* a state carrying another card's id (`.agents/LINKAGE.md` §7.1), so this rides
 * the States grant rather than a permission of its own — there is nothing here an agent that
 * may write states cannot already write by hand, only a name for it. The reader asked for the
 * name: *"add tools so agents may link cards together."*
 *
 * `from` is the card the link is written on, which is the whole of where the fact lives: an
 * ownership is stored on the owner and a symmetric bond on whichever card it was made from.
 * The far reading is derived and is never a second record.
 */
export type LinkCards = {
  type: "link_cards";
  /** The card the link is written on — a character or a world, by name or id. */
  from: string;
  /** The card at the other end. */
  to: string;
  relation: CardRelation;
  /** Taking one off is the same tag with `action="unlink"`, so undoing needs no second tool. */
  action: "link" | "unlink";
  evidence: string;
};

/**
 * **An edit made to a card as a screen drew it** — `from` the card or listing drawn, `to` that with the
 * change. Its own type, so a whole record written over a card (`saveOver`) and an edit made from a
 * listing (`editListed`) cannot be passed for each other.
 */
export type ListedEdit<L> = { from: L; to: L };

/**
 * **Which calls are running right now**, as one pure step over the list.
 *
 * The pane cannot see "in flight" and the loop cannot see the store, so the loop reports a
 * `LoopProgress` and this is the rule for what that does to the list. A function rather than
 * four lines inside the callback in `lib/ai.ts`, because it is the only part of the
 * arrangement that can be *wrong* — and a chip that never clears is worse than no chip at all:
 * it says the app is working after it has stopped.
 *
 * **Only the running ones.** A call that has finished is on the reply's own record (a `tool_use`
 * item on `DirectorMessage.timeline`), which is what the card draws and what survives a reload.
 * Two records of one finished run is the pair that always comes apart.
 */
export type LiveCall = {
  /** The id the model gave the call, or `""`. */
  id: string;
  /**
   * The call's run, by the id it is filed and stopped under (`CallContext.run`, `stopRun`) — minted
   * before it starts, so whatever draws the chip can stop that run and nothing else.
   */
  run: string;
  /** The agent called, as written. */
  agent: string;
  /** The agent called, by the id it answers as — or as written, when no agent answers to it. */
  agentId: string;
  /** The agent that made the call: whose pane draws the chip, and where the status box nests it. */
  caller: string;
  role: string;
  note: string;
  /** Present on a `<task>`: its title, which the chip and the status box name it by. */
  task?: { title: string; tools: string[] };
  startedAt: number;
};

/** How a confirming button sizes itself and looks at rest — armed, it is always `danger`. */
export type Look = {
  size?: Size;
  /**
   * The variant before the first press: `ghost` in a row of controls — a trash that
   * reddens under the pointer says "deleted" before anything is, which the owner refused — `floating` where
   * the button stands over a picture that a transparent one would vanish into.
   */
  resting?: Variant;
  className?: string;
};

/**
 * One lookup the Director asked, as the pane draws it.
 *
 * Stored because the trace marks what a run *did*, and a read
 * that left no record could only be recovered by parsing the run log back — which is the shape
 * §13.12 exists to prevent. Bounded the same way, by the per-answer cap the lookups already
 * apply, and absent when the run looked nothing up.
 */
export type LookupRecord = {
  step: number;
  /**
   * `read_card`, `read_arc`, `search` or `roll` — a `LookupQuery["kind"]` — or, on the
   * reader's own line, `call_agent` too: an agent the reader called there answers the Director this
   * way, having no run of the Director's to be said back in (`readerLineRecords`).
   */
  kind: string;
  /** What was asked, in the loop's own words: a card's name, a question, a turn. */
  label: string;
  findings: string;
  /**
   * The tag as the model wrote it, so the next packet can lay the answer **under the call**
   * in the stored reply exactly as the run did — `exchangeOf` finds it in `content`. Absent
   * on a record written before this existed; those answers stand after the reply, as they
   * always did.
   */
  tag?: string;
};

/** How much a lookup answers with — `read_card`, `search`, `read_context`. */
export type LookupTuning = {
  /** The most one answer may carry into the next prompt, in characters. */
  answerChars: number;
  /** How many results a ranking answers with when the tag asks for no number. */
  results: number;
  /** The most it answers with however large a `top` is written. */
  maxResults: number;
  /** How much of the ranking `read_context` shows unasked. */
  contextResults: number;
  /** The most places (fields) one `<replace>` changes; the rest are named back to the run (`replaceReceipt`). */
  maxReplaceTargets: number;
};

/**
 * Why a Director run ended. Always one of these — a loop that just stops is a loop nobody
 * can debug.
 *
 * Here rather than in `lib/director/loop.ts` because it is **stored**: the trace carries it,
 * and the pane and the run log are two renderers of that one record. `LOOP_END_LABELS`, beside
 * the code that decides them, is the one place each of these has a sentence.
 */
export type LoopEnd =
  /** Nothing left to say back: no observation, so another step would ask the same question. */
  | "settled"
  /** The run's output budget. */
  | "token ceiling"
  /**
   * The reader pressed Stop on the Director pane's reply, and it was kept as far as it got: nothing
   * in it ran, was answered or was proposed (`stoppedStep`), so the next run can be told so.
   */
  | "stopped"
  /**
   * The step's only news was news the model had already been given.
   *
   * Distinct from `settled` because the two look identical from outside and mean opposite
   * things: one is a Director that finished, the other is one that wrote the same broken call
   * twice and had nothing new said back to it.
   */
  | "repeated itself"
  /** The run reached its maximum step safeguard. */
  | "step ceiling";

/**
 * **A lorebook: a folder of world cards** — on the world shelf (a `LibraryFolder` of shelf
 * `worlds`) and in a chat (`Chat.worldFolders`). Its cards name it by `World.folderId`; the
 * characters who own it name it in `Character.lorebooks`. It may hold lorebooks — a book with
 * chapters, "The Reach › Places" — and its path from the top is the heading its cards are sent
 * under. `lib/cards/lorebooks.ts` is everything the shape implies.
 *
 * The three fields a `LibraryFolder` shares, so every walk over lorebooks takes either kind.
 */
export type Lorebook = ChatFolder;

/**
 * The stacking order, named.
 *
 * These were bare numbers at the call sites — `z-50` eight times, `z-[60]` once and
 * `z-[9999]` five times — with no way to tell which were deliberate and which were someone
 * adding a nine until their panel appeared.
 *
 * **Nobody picks one any more.** A dialog opened inside another is a *page* of it now
 * (`components/ui/Pages.tsx`), so the only dialog that can stand over another is one that says
 * it floats — the crop — and `Modal` works out its layer from whether it is inside a dialog.
 * `top` is not a modal's layer at all: it is the `{{` list, which must beat every dialog.
 */
export declare const MODAL_LAYERS: { readonly base: "z-50"; readonly nested: "z-[60]"; readonly question: "z-[70]"; readonly top: "z-[9999]"; };

/**
 * **One thing the story keeps.**
 *
 * Anchored to the messages it came from (`sourceMessageIds`), which is what lets a rewind take it
 * back with them, lets "From turn 41" link to the line, and lets the reader ask for only what the
 * prompt no longer carries. The turn number itself is not stored: it is the source's index, read
 * when it is drawn, so deleting an earlier line cannot leave it naming the wrong turn.
 */
export interface Memory {
  /**
   * Short and stable, so a tool can name it: `m12`. The next is one past the highest the chat
   * has ever used (`nextMemoryId`), so a number an undo record still names is never handed out
   * again.
   */
  id: string;
  kind: "fact" | "passage";
  /**
   * A fact's sentence (≤ 30 words, names not pronouns — a fact names its people, and a few words
   * worth keeping verbatim go inside it in quotation marks). A passage has none: its words are its
   * messages' (`passageText`), so an edit to the line is the edit to the passage and there is no
   * second copy to fall out of step with it.
   */
  text?: string;
  /** The story's own time, as written ("three nights later"). */
  when?: string;
  /**
   * The messages it came from, in story order — the anchor that rewind, delete and retry prune by
   * (`pruneMemoriesWithoutSources`), and what "From turn 41" and "only what the prompt no longer
   * carries" read. A passage's are its messages. Empty for a memory written by hand, or by an
   * agent about no message in particular — and an empty list is never pruned by its sources.
   */
  sourceMessageIds: string[];
  /**
   * Older memories this one replaces. The replaced ones stay, marked by this list alone (their
   * replacement is derived, `supersededByMap`), and are never sent — so undoing the replacement
   * brings them back without anything to restore on them.
   */
  supersedes?: string[];
  /**
   * **Pinned**: always sent, first of the memories and the last of them the budget gives up — what a
   * highlight was, and what "core" meant until round 2026-10-08C (`.agents/MEMORY-NODES.md` §1).
   */
  pinned?: boolean;
  /** Who wrote it: an agent id, `"player"` for the reader's hand, `"app"` for a passage. */
  author: string;
  createdAt: number;
  /**
   * Where it is filed now: node ids, or `UNSURE_NODE`. Empty or absent is **Unfiled** — new, left
   * by a deleted branch, or waiting for a node. Ids rather than labels, so a reworded node keeps
   * its memories and a replaced tree leaves them visibly unfiled rather than wrongly filed.
   */
  nodes?: string[];
  /** How it got there — the last filing's record (`MemoryFiling`). Absent until it is filed. */
  filing?: MemoryFiling;
  /**
   * Waiting for the Fact Writer to make a node for it (`.agents/MEMORY.md` §5.3). Cleared by the
   * node run whatever the run does, so a memory never waits twice.
   */
  waitingForNode?: true;
  /** The hub's amber dot: written since the lens was last open. */
  isNew?: true;
  /**
   * **A few words on where the fact stands in the story** (MEMORY-NODES.md §7.3), written by the Fact
   * Writer beside the fact ("during the study night at Player's dorm"). Read with the fact by every
   * Classification question — filing, reading, the change check — and sent to the Writer only when a
   * macro asks (`{{memories::context}}`).
   */
  context?: string;
  /**
   * **Waiting at a node that files its own children** (MEMORY-NODES.md §6): that node's id, until its
   * next pass files the memory further down.
   */
  waitingAt?: string;
  /**
   * **Burned by a rule** (MEMORY-NODES.md §4.3): out of the tree, never sent or read. The rule's event
   * on the reply set it, so a rewind past that reply clears it; the hub's Burned card restores it.
   */
  burned?: {
    /** The rule, as `nodeId/ruleId`. */
    rule: string;
    at: number;
    /** The reply whose upkeep burned it: a rewind or a delete that takes the reply restores the memory. */
    on?: string;
  };
}

/**
 * **The memory tools** (`.agents/MEMORY.md` §4.3) — one family on the state tools' pattern: a memory
 * written, memories changed, and a question added to or moved in the reader's tree.
 *
 * Every reference arrives as written — a node by its id or its label path ("Bonds › Debts"), a memory
 * by its id, a turn by its number — and is resolved by the apply against the chat as it stands when
 * the action lands (AGENTS.md §13.5): a `<memory_update node="Bonds › Debts">` written after the
 * `<memory_node>` that makes Debts, in one reply, finds it.
 */
export type MemoryAdd = {
  type: "memory_add";
  /** The memory: one fact, names not pronouns; a line kept word for word goes in quotation marks. */
  text: string;
  /** The story's own time, as written ("the night before"). */
  when?: string;
  /**
   * The turns it came from, by their numbers (`from="41,42"`) — `NaN` for one that was not a number,
   * for the validator to name. Absent: the run's span for the Fact Writer, no source for any other.
   */
  from?: number[];
  /** Where to file it, as written: a node's id, its label path, or `unsure`. Files it whatever the filer is. */
  node?: string;
  /** Pinned: always sent. */
  pinned?: boolean;
  /** A few words on where it stands in the story — read with it when it is filed and read. */
  context?: string;
};

/**
 * **The order the tree chooser takes the branches in** (§12): the best-answering branch's memories
 * first, then the next; or each top-level branch in turn, its best memory before any branch's second,
 * so one side of the tree cannot fill the share and leave the other unsent.
 */
export type MemoryBranchOrder = "best" | "turns";

/**
 * **How the memories are chosen when they do not all fit** (`.agents/MEMORY-NODES.md` §10): the newest
 * first, asking nothing; by the tree, one Classification request over every branch's definition, then
 * the best branches' memories first; or by reading every memory (`MemoryReader`). When they all fit,
 * none of these runs: every one is sent.
 */
export type MemoryChooser = "newest" | "tree" | "read";

/**
 * **Who files a new memory under the tree** (§5.1): Classification, Close reading, Embedding,
 * the Fact Writer as it writes (`node=`), or nobody — the reader by hand.
 */
export type MemoryFiler = "classifier" | "closeReading" | "embedding" | "fused" | "writer" | "player";

/**
 * **How a memory came to be where it is** — kept so the canvas can show the reader which question
 * pulled it there (or failed to), and so they can reword that question rather than guess.
 */
export interface MemoryFiling {
  by: "classifier" | "closeReading" | "embedding" | "fused" | "writer" | "player" | "agent" | "rule";
  /** The model string when a model filed it (`provider::model`, or a checkpoint). */
  model?: string;
  at: number;
  /**
   * Every asked node's answer, 0..1 — what the canvas draws on each card when the memory is
   * picked. All of them, not only the winners: a near miss is what tells the reader a question
   * is worded too narrowly.
   */
  scores?: Record<string, number>;
  /** The placement rule's settings at the time, so a refile's different answer can be explained. */
  rule?: { branches: number; fitsAt: number; sureAt: number };
  /**
   * **What the filing asked, as one key** (`filingAsked`, `lib/memory/asked.ts`): the tree it walked,
   * the memory's words as read, and the models. A rule that refiles after every reply asks again only
   * once this no longer matches what it would ask — a memory that fit none of a node's sub-nodes was
   * asked about again after every reply, and paid for, for the same answer. Absent on a filing that
   * asked nothing (by hand, a failure, a move), so its next refile asks.
   */
  asked?: string;
  /**
   * **Why it could not be filed** — no key, a refusal, a server that was not there. The memory
   * stays Unfiled with this on its row: a filing is a record the reader reads, so a failure is
   * said, never quietly replaced by some other answer.
   */
  problem?: string;
}

/**
 * **How the Classification model is asked** — the transport's numbers, not the design's
 * (`.agents/MEMORY.md` §8): how many questions go in one decision request, and how many requests
 * are out at once when a read or a refile asks about hundreds of memories.
 */
export type MemoryLimits = {
  /** Questions in one decision request — a memory each, or a node each when filing. */
  questionsPerCall: number;
  /** Decision requests in flight at once. */
  callsAtOnce: number;
};

/**
 * **One question of the reader's tree.**
 *
 * The tree is a setting (`chatSettings.memoryTree`), carried by presets and the new-chat
 * template; each chat keeps its own copy. Siblings are in array order — there is no `order`
 * field, because a position stored as a sequence *and* a number is two facts (AGENTS.md §13.2).
 * Positions on the canvas are not stored either: the layout is a function of the tree.
 */
export interface MemoryNode {
  /**
   * Stable within the chat: a preset's own (`bonds/romance`), or a slug of the label for one made
   * later (`nodeIdFor`). Memories point at it, so it never changes when the node is reworded.
   */
  id: string;
  label: string;
  /**
   * **What belongs under it**, as a dictionary says it — a noun phrase, not a question ("how someone
   * usually acts, jokes and carries themselves"). It was a question (`ask`) until round 2026-10-08C
   * (`.agents/MEMORY-NODES.md` §7.1): a definition can be sent over the memories it holds, which a
   * question could not. Filing asks whether a memory belongs under "label: definition". May be empty
   * on a node with children: an empty definition makes the node a pure group, transparent to filing
   * (`placeMemory`).
   */
  definition: string;
  /** The parent's id; absent is the top level. */
  parent?: string;
  /**
   * **Outside the tree** (round 2026-10-08D): a top-level node no walk starts at. It and its branches
   * are reached only through a link (*Branches to*, `link`) from a node in the tree, asked down from
   * the top — so a branch can be one a memory reaches only on some paths. Never set below the top.
   */
  outside?: true;
  /** Who made it: `"player"`, a preset's id, or an agent's id. Shown on the card. */
  by?: string;
  /**
   * When its definition was last written — so a memory filed before it reads "filed under an
   * earlier wording" rather than as though the new definition had placed it.
   */
  definedAt?: number;
  /**
   * **What this node does** (MEMORY-NODES.md §11), declared here. The tree is the class hierarchy: a
   * node's children inherit every behaviour it declares, and override one by declaring it again or
   * switch it off with `off` (`behavioursOf`). Replaced `holds`, `rules` and `files` (round 2026-10-08C).
   */
  behaviours?: NodeBehaviour[];
}

/**
 * **A question of the reader's tree, added, reworded or moved.** No `node` adds one under `parent`;
 * with `node`, it changes that one. `parent` is `""` for the top level. `remove` is a removal the
 * model asked for, which is refused by name: deleting a branch is the reader's, on the canvas.
 */
export type MemoryNodeEvent = {
  type: "memory_node";
  node?: string;
  parent?: string;
  label?: string;
  /** The node's question — the body. */
  definition?: string;
  remove?: true;
};

/** When no node fits a memory (§5.3): file it under Unsure, or ask the Fact Writer for a new node. */
export type MemoryNothingFits = "unsure" | "newNode";

/**
 * **What was read for one reply, and what was sent** — set on the reply it was read for, and kept
 * with the take (`MessageTake`), so a swipe shows each take's own read. Bounded: the near list is
 * the best 30 that were read and not sent, so a trace costs about 1.5 KB a reply.
 */
export interface MemoryRead {
  at: number;
  /** `all`: everything fit, and nothing was asked. `newest` and `tree`: the chooser past the share. */
  how: MemoryReader | "all" | "newest" | "tree";
  /** The model that read — and, when the chosen one failed, what read instead and why. */
  model?: string;
  fellBack?: { to: "embedding"; why: string };
  /**
   * Why nothing could be read at all — no Meaning model to fall back to (an APK without weights), or
   * it failed too. Said on the trace, so a reply that carried no memories says why it carried none.
   */
  problem?: string;
  /** How many memories were candidates, how many were read, and how the shortlist was cut past the cap. */
  candidates: number;
  read: number;
  shortlist?: MemoryShortlist;
  /** The branches' answers for this scene, when the tree chose. */
  branches?: Record<string, number>;
  /** Sent, in rank order, with scores; and the best 30 that were read and not sent. */
  sent: [id: string, score: number][];
  near: [id: string, score: number][];
  costUsd?: number;
}

/**
 * **How the memories are read for the next reply** (Settings → Memory, `.agents/MEMORY.md` §6.1):
 * Classification, Embedding, Close Reading, or Blended retrieval fusion.
 */
export type MemoryReader = "classifier" | "embedding" | "closeReading" | "fused";

/** How the candidates are cut to the read's cap: by Embedding, by the tree, or newest first. */
export type MemoryShortlist = "embedding" | "tree" | "newest";

/**
 * **How the tree is asked**, when a memory is filed and when the scene is read against it
 * (`.agents/MEMORY-NODES.md` §12): every leaf at once, its parents only grouping it; or down the tree,
 * each parent's definition asked first and a gate — its children are asked only on the paths it lets
 * through, and a branch it shuts is never asked at all.
 */
export type MemoryTreeAsk = "leaves" | "walk";

/**
 * **Memories that exist, changed** — their words (a body is a *new* memory that replaces the named
 * ones; nothing is edited in place), their place, or whether they are always sent.
 */
export type MemoryUpdate = {
  type: "memory_update";
  /** The memories it names, by id, in the order written. */
  memories: string[];
  /** A new version, replacing every named memory. Absent: the named memories are moved or marked. */
  text?: string;
  node?: string;
  pinned?: boolean;
  /** For the new version, as on `memory_add`. */
  when?: string;
  context?: string;
  from?: number[];
};

export type Message = {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  /** Pictures sent with this line. Absent when none, so a plain line serialises as it always did. */
  images?: MessageImage[];
  /** Documents sent with this line, as their text. Absent when none, for the same reason. */
  files?: MessageFile[];
  /**
   * **Text a card wrote, not a reply a model did** — a greeting committed from the card. Drawn as
   * written: one message, its author's, never cut into lines (`splitsIntoChunks`). In a pseudo chat
   * it used to be given one `Name:` on its front, so its first paragraph was the character's and
   * every later one was narration, with a name the card never wrote shown on top. Absent otherwise.
   */
  asWritten?: true;
  /**
   * **Words an agent outside the reply sent to the chat** (its output `chatHistory`), as a message of
   * their own after the reply: the agent's id. Drawn as the story, with no label (the owner's
   * ruling, 2026-11-05), and never a turn — whose turn it is, what the passes after the Writer are
   * about and where the options stand are read past it (`isReply`). Absent on every other message.
   */
  addedBy?: string;
  thinking?: string;
  raw?: string;
  /**
   * **Where this reply was cut short** — the reader talking over a pseudo reply at a bubble it had
   * not finished showing (a guest too, at a table), Stop at what was read, or a prune from one of
   * its bubbles. An offset into the reply as the model wrote
   * it (its `raw` with the reasoning out, as it was before the cut rewrote it), so the Inspector
   * can mark the place in the request's reply and still show what came after. Told by the cut
   * (`cutChatAt`), never worked out by comparing what is left with what was written. A take's,
   * like `raw`: a swipe to another take does not carry it. Absent on a reply nobody cut.
   */
  cutAt?: number;
  /**
   * **The reader's line that cut this reply short** — its id: a line sent while the reply was
   * still being written (the stream stopped for it) or still being handed out (the reply cut at
   * what had been shown). Told by the press that placed the line (`placePlayerLine`, a guest's at
   * the host), so the Inspector's Runs view draws the line where it cut the reply in, rather than
   * guessing from whatever line happens to follow: a Stop and a line typed a minute later leave the
   * same transcript. A take's, like `cutAt`. Absent on a reply no line cut, and on one cut before
   * this was told.
   */
  interruptedBy?: string;
  /** Other takes on this turn — see `MessageVariants`. Absent means this is the only one. */
  variants?: MessageVariants;
  /**
   * Every agent's runs about this message, oldest first — see `AgentRun`. Replaced a map of one
   * log per agent, which before that was two strings partitioned by build-time labels
   * (`<!-- State Manager -->`) that could not represent an agent defined by the user.
   */
  runs?: AgentRun[];
  /**
   * **A passage the app cut ends at this message** (`lib/memory/after-reply.ts`): the next cut starts
   * after the newest message carrying it. Kept on the message, as the Fact Writer's span is read off
   * its runs, so a rewind or a delete takes the mark with the message it stood on, and the reader
   * deleting the passage does not move it — read off the passages there were, a deleted passage was
   * cut again at the next reply. Not a take's field: a swipe changes the words, not what was cut.
   */
  passageCut?: true;
  stateChanges?: StateChange[];
  /** The Writer's tags this take wrote that became nothing — see `ToolProblem`. Absent when none. */
  toolProblems?: ToolProblem[];
  /** The rolls thrown while this take was written, drawn in the story — see `RollRecord`. */
  rolls?: RollRecord[];
  timestamp?: number;
  optionChosen?: boolean;
  customOptionChosen?: boolean;
  options?: string[];
  /** Character who spoke this assistant message; null/undefined = Narrator */
  speakerCharacterId?: string | null;
  /**
   * **The turn-loop entry this line was the turn for**, stamped where it was written — absent on a
   * line taken out of order (a call that wove in, a person cutting in) and on every line outside a
   * round. The round's position is the last of these (`roundPosition`), so it moves with the
   * transcript through a rewind or a delete rather than living in a cursor beside it.
   */
  roundEntry?: string;
  /**
   * Taken out of the prompt by hand — the Use/Ignore switch a summary block has, one level
   * down.
   *
   * Off means this turn is in **no prompt at all**: not quoted as raw history, and not
   * compressed into a block either, because "hidden from context" would be a strange
   * promise if the model could still read a paraphrase of it. `turnIsSent` is the one
   * predicate every walk asks — see `lib/context/turns.ts` for why there is exactly one.
   *
   * Written `true || undefined`, never `false`, so an untouched message stores no key. The
   * turn stays in the transcript and on screen; this is about the payload, not the story.
   */
  excluded?: boolean;
  /**
   * **What was read of the story's memories for this reply, and what was sent** — see
   * `MemoryRead`. A take's own, like `runs`: each take was written from the read made for it,
   * so a swipe shows that take's. Absent on a reply no memory was read for.
   */
  memoryRead?: MemoryRead;
  /**
   * **What ran after this take and read it, parked while another take is shown** — see `TakeWork`.
   * Only ever on a take off screen: leaving a take parks it here (`parkTakeWork`), and arriving at
   * one puts it back and removes the field (`restoreTakeWork`), so a message on screen never holds it.
   */
  afterTake?: TakeWork;
};

/** What a seat may do to a line of the story — asked of the rows that cover it. */
export type MessageAction = "edit" | "delete";

/**
 * **A document sent with a line** — a text file, or a Word or OpenDocument file read to its text
 * in the browser (`lib/files/read.ts`). The text is what the model reads (`lib/files/prompt.ts`);
 * the name, kind and size are what the chip under the bubble shows. The file itself is not kept:
 * what was sent is the text, and a line that kept the bytes too would carry the file twice.
 */
export type MessageFile = {
  id: string;
  name: string;
  /** The browser's type for it, or the one its extension names when the browser gave none. */
  mime: string;
  /** The file's own size in bytes, before it was read — what the reader recognises it by. */
  size: number;
  text: string;
};

/**
 * A picture attached to a line — the reader's, or a guest's at the table.
 *
 * `dataUrl` is the same inline JPEG every stored portrait already is, downscaled to
 * `ATTACHMENT_MAX_DIM` on the way in so a chat with a dozen of them stays a chat and not an
 * album. `description` is what the Vision agent said it shows, and it is **the text the
 * writing model reads in its place** when the chat sends pictures as words
 * (`ImageSettings.uploads`). Absent until described; a picture the chat sends as itself never
 * needs one. `imageSight` in `lib/images/sight.ts` is the one reader of the pair — the prompt
 * builder and the hint under the bubble both ask it, so the hint cannot claim the model saw
 * something the prompt did not carry.
 */
export type MessageImage = {
  id: string;
  dataUrl: string;
  description?: string;
  /**
   * The sentence the Image Writer was given, when this picture was *made* rather than sent —
   * a Writer's `<generate_image>`, or a helper's. Present on a made picture and absent on
   * a sent one, so it is also what tells the two apart: a made picture is read as the sentence
   * it was made from, whatever the chat does with the reader's own (`imageSight`), and is never
   * put to the Vision agent unasked.
   */
  prompt?: string;
  /**
   * How a picture the *reader* had drawn reaches the Writer — the composer's own door to the
   * Image Writer, where the sentence is theirs and the picture goes with their next line.
   * `picture` sends it as itself, `caption` sends the sentence it was drawn from. Absent on
   * every other picture: the story's own made pictures are always their sentence, and a sent
   * picture is the chat's `uploads` to decide. `imageSight` is the one reader.
   */
  sendAs?: "picture" | "caption";
  /**
   * Where the tag that made this picture sat in the reply's `raw` — `RollRecord.atOffset` for
   * the same call — so the picture stands in the story **where the Writer asked for it**,
   * between the bubbles, rather than under the reply's last bubble. Absent on a picture the
   * reader sent or drew from the composer, which goes with their line.
   */
  atOffset?: number;
};

/**
 * **Where the transcript's message arrows stand.**
 *
 * *"Add a setting for the message navigation chevron to either anchor to the right edge or
 * anchored near the chat."* Two answers about one pair of arrows (`MessageNavigator`):
 *
 *   - `edge` — against the right edge of the story's area, stepping in from under a docked
 *     Inspector. Where they have always stood, so it is the default: a chat nobody touches
 *     keeps its arrows where its reader last saw them.
 *   - `story` — just past the right edge of the transcript's column, in the gutter beside the
 *     words, so the eye does not cross the gutter to reach them.
 *
 * The two only differ where the gutter beside the column is wider than the arrows. Where it is
 * not — a phone, a pushed pane, a docked Inspector taking the whole gutter — the arrows cannot
 * stand beside the column without covering it or the pane, so both answers draw them in the
 * same place, and nothing about that is a second rule: it is the one lane (`MessageNavigator`)
 * running out of room.
 *
 * Whether the arrows are drawn at all is `showAutoPanChevrons`, and this is only offered while
 * they are: a placement for arrows that are not drawn decides nothing.
 *
 * The table is here so the picker and the reader cannot describe different things.
 */
export type MessageNavigatorAnchor = "edge" | "story";

/**
 * One take on a turn: the words, and what the model showed of writing them.
 *
 * `raw` and `thinking` are here rather than left on the message because they *describe*
 * these particular words. A take that carried only its text would leave the previous
 * take's completion and reasoning attached to it — which is the falsehood
 * `rewriteMessageIn` exists to prevent, arriving by a new door.
 *
 * Nothing about the turn's *place* in the story is a take: its id, its timestamp and its
 * `stateChanges` undo log describe the position, and the position does not change when
 * the reader swipes.
 *
 * `Pick`ed rather than written out, and `TAKE_FIELDS` in `lib/chat/take-fields.ts` is checked
 * against it in both directions. It was a hand-written copy that knew `rolls` and not
 * `images`, so a picture the Writer made mid-reply stayed on the message when the reader
 * swiped — drawn under a take that never asked for it, at an offset into that take's `raw` —
 * and a re-roll lost it outright, because the discarded take was lifted without it.
 *
 * `toolProblems` is the take's too: its tags are read once, when it lands, and what they proposed
 * is parked with it (`afterTake`). It was re-derived from `raw` at every swipe, and so was every
 * card the tags made — posted fresh, pending, the reader's Approve forgotten.
 *
 * `runs` is carried too: a reply written by a stage of several agents keeps the drafts it was
 * written from on the message (`lib/pipeline/stage.ts`), and a swipe away and back would
 * otherwise lose them — the "Output of an agent" slot of a pass that runs after the reply would
 * then read nothing.
 *
 * `asWritten` is the take's too: a card's greetings are the takes of the opening line
 * (`lib/chat/greeting.ts`), and a take written past the last of them is the model's. On the
 * message alone, swiping from a greeting to a written take left the model's words drawn as the
 * card's, uncut, and swiping back drew the greeting cut into lines with a name it never wrote.
 *
 * `options` and `afterTake` are what was done on the take's words: the suggested replies, and
 * everything else (`TakeWork`) — its own tags' cards among them. They were left to the swipe — the
 * options deleted, every other agent's work left in force under the next take's words — so swiping
 * back showed take A with the state changes take B's State Manager had made, and paid to read A's
 * facts a second time.
 */
export type MessageTake = Pick<Message, "content" | "thinking" | "raw" | "cutAt" | "interruptedBy" | "rolls" | "images" | "runs" | "asWritten" | "memoryRead" | "options" | "afterTake" | "toolProblems">;

/**
 * A turn's other takes, on either side of the one it is showing.
 *
 * **A zipper, not a list and an index.** The obvious shape — every take in one array plus
 * the number of the current one — states where the reader is twice, in the index and in
 * `content`, and every bug in this repo is two representations of one fact drifting. The
 * specific drift is not hypothetical: an edit rewrites `content` and would leave the
 * indexed entry saying what the turn used to say, so swiping away and back would silently
 * undo the reader's edit.
 *
 * Here the shown take lives in `content` and nowhere else. There is no index to fall out
 * of range, no entry to disagree with the text on screen, and "which take is this" is
 * `before.length + 1` — derived, so it cannot be wrong.
 */
export type MessageVariants = {
  before: MessageTake[];
  after: MessageTake[];
};

/**
 * **The table a chat is being played at, if any** — read by the one walk (`lib/speaker.ts`).
 *
 * The walk is the chat's own on your own and at a table alike (TURNS.md §28.5): a room adds
 * people to the round and nothing else. But the people are live session state, held by the
 * multiplayer plugin, and the turn system is core — it must walk solo with the plugin absent. So
 * the walk asks the table port (`lib/table/port.ts`) at the moment of asking; nothing here is a
 * copy that could fall out of step.
 *
 * A guest's tab answers the same view — it holds the roster and the claims the host broadcast —
 * so a guest's strip walks the round the host is enforcing.
 */
export type MicTableView = {
  chatId: string;
  players: readonly { id: string; isHost: boolean }[];
  claims: Record<string, string>;
};

export type ModalBackdropOptions = {
  onClose: () => void;
  /**
   * Whether this modal is currently on screen. Defaults to true, for the common case where
   * the component early-returns when closed and so is not mounted at all.
   *
   * Needed for panels holding several dialogs that render conditionally — `PromptMasterPanel`
   * has four. Hooks cannot be called conditionally, so all four call this on every render;
   * without the flag all four would sit on the Escape stack at once and Escape would close
   * whichever registered last rather than the one you can see.
   */
  open?: boolean;
  layer?: ModalLayer;
  /** Opacity and blur, which are the caller's look. */
  backdrop?: string;
  /** Padding the backdrop itself carries. */
  padding?: string;
  /** Centred dialog, a sheet against the bottom edge, or a working surface. */
  placement?: ModalPlacement;
  /**
   * Set when a click outside must *not* dismiss — for a modal holding work that a stray
   * click would discard. Escape still closes it; pressing Escape is deliberate in a way
   * that a misclick is not.
   */
  keepOnBackdropClick?: boolean;
};

export type ModalLayer = keyof typeof MODAL_LAYERS;

export type ModalPlacement = "center" | "sheet" | "workspace";

/** What a model does when no level is sent: think at a level, or not think at all. */
export type ModelDefault = ExplicitLevel | "off";

export type ModelLevelRule = { match: RegExp; rule: LevelRule; why: string };

export interface ModelPrompt {
  /** An agent id — the same ids `lib/agents/catalog.ts` is keyed by. */
  id: string;
  /**
   * How this agent behaves and how often it runs, shown in Prompt Master.
   *
   * There is no `name` beside it. That was a second copy of the catalog's label and it had
   * drifted on three of six rows — "Narrator Model" against "Narrator", "The Director
   * (OOC)" against "Director", and "Dialogue Options Generator" against "Option
   * Generator", which is the exact string `catalog.ts` was written to delete. Ask
   * `agentLabelFor(settings, id)`.
   *
   * There is no `ownedTools` either. Six rows declared one and nothing anywhere read it;
   * the real gating is `getDefaultToolsForModelAndMode`, and two of the six rows already
   * disagreed with it.
   */
  guide: string;
  basePrompt: string;  // Core system prompt
  /** The shipped reminder text, where the agent ships one: a written agent has none (`authoredDefaultBlocks`). */
  reminder?: string;
  /** Authored without positions — the array is the order. See `DefaultPromptBlock`. */
  blocks?: DefaultPromptBlock[];
  /**
   * **This agent's blocks that do not ship in its stack** — offered in Add block (Ready-made,
   * `prebuiltCatalogue`) for a reader who wants one back. A card that ships is on, so a block the
   * default leaves out is left out here rather than shipped switched off: the Fact Writer's
   * "Earlier messages", which it reads only when the reader asks for context.
   */
  offered?: DefaultPromptBlock[];
}

export type ModelSettings = {
  /**
   * **Provider override for this agent** (round 2026-10-12).
   * When absent or undefined, the agent runs on the chat's master provider.
   */
  provider?: Provider;
  model?: string;
  /**
   * **Called with another kept key** (round 2026-10-08D): the two-word name of one of its provider's
   * kept keys (`lib/server/key-names.ts`), its card's "Use the master key" off. Absent is the key in
   * use. Outside the inherit gate (`AGENT_OVERRIDE_KEYS`): a key is not a model or a sampler.
   */
  keyName?: string;
  allowThinking?: boolean;
  /**
   * This agent's reasoning level, over the chat's `reasoningEffort` — `agentReasoning` resolves
   * both. Outside the inherit gate for `allowThinking`'s reason (`AGENT_OVERRIDE_KEYS`).
   */
  reasoningEffort?: ReasoningLevel;
  contextLimitTokens?: number;
  /** Per-agent retrieval overrides. Anything omitted falls back to the chat-wide value. */
  rag?: Partial<RagPolicy>;
  maxTokens?: number;
  temp?: number;
  topP?: number;
  topK?: number;
  minP?: number;
  topA?: number;
  repPen?: number;
  frequencyPenalty?: number;
  presencePenalty?: number;
  dryMultiplier?: number;
  dryBase?: number;
  dryAllowedLength?: number;
};

/**
 * How much of the story one agent is sent — sizes only; whether a source is sent at all is its
 * card's switch in the agent's stack. Every field is required: `resolveVisibility` merges a
 * stored profile over the shipped default, so a reader never receives a partial one.
 * `minUnsummarizedTurns` was the last optional field here, and the `?? 2` each reader wrote
 * to cope with it had drifted into three copies.
 */
export type ModelVisibility = {
  /**
   * **How much raw transcript is kept, and in what** — or `null` for the budget's call.
   *
   * Was `unsummarizedTurns: number | null`, which could only ever say a count of turns. A
   * turn is not a fixed size — one line of dialogue and a page of narration are both one —
   * so "keep 8" is a promise about the story's shape and says nothing about what it costs,
   * and a reader who wants a *slice of the window* had no way to ask for one.
   *
   * One number and its unit, not two fields: `{ unit: "turns", amount: 8 }` and
   * `{ unit: "tokens", amount: 4000 }` are the same setting measured two ways, and a pair of
   * nullable counts would make "both set" a state the type allows and nothing resolves.
   */
  rawHistory: RawHistorySize | null;
  /**
   * How many memory blocks ride behind the raw turns, or "dynamic" for as many as fit,
   * or a fixed budget in blocks or tokens.
   */
  summaryBlocks: number | "dynamic" | SummaryLimitSize;
  minUnsummarizedTurns: number; // Minimum raw turns when dynamic pruning is active
  /*
   * `worldCards`, `characterCards`, `storyArcs`, `storyGuidelines` and `chatHistory` were switches
   * here, and are gone (2026-10-26, `.agents/CONTEXT-MASTER.md` §3): each was a second copy of the
   * switch on the card that brings the material in, kept in step by hand. The card in the agent's
   * stack is the switch now, so a profile holds sizes alone. `coreMemories`, `storyGuideInjections`
   * and `recentChanges` went the same way earlier.
   */
};

/**
 * How a line nobody claimed is drawn — see `isProseChunk`.
 *
 * `NARRATION_LINE_STYLES` in `config/appearance.ts` is the table: what each one is called,
 * and what it does to the bubble, the avatar and the name. The id lives here because
 * `ChatSettings` needs it and the table imports from this file.
 */
export type NarrationLineStyle = "prose" | "prose-wide" | "bubble" | "narrator";

export type NarratorMode = (typeof CHAT_MODES)[number]["id"];

export type NextVoice = "called" | "random";

/**
 * **One behaviour of a node** (MEMORY-NODES.md §11.2) — a small module with a plain name and its own
 * settings, one row of `BEHAVIOURS` in `lib/memory/behaviours.ts` each. `off` switches an inherited
 * one off here, and for this node's children.
 */
export type NodeBehaviour = (
  | { is: "forget"; unsent: number }
  | { is: "expire"; age: number }
  | { is: "cap"; keep: number }
  | { is: "moveOn"; age: number; to: string }
  | { is: "weakFits"; below: number }
  | { is: "alsoFile"; to: string }
  | { is: "promote"; sends: number }
  | { is: "watch" }
  | ({ is: "fileChildren" } & NodeFiling)
  | ({ is: "rule"; id: string } & NodeRule)
  /**
   * **Keys** — the card keys' rule, over a memory filed here (`keyedScores`, `lib/memory/file.ts`): a
   * memory whose words miss a Require key, or hold an Exclude key, does not fit this node whatever its
   * filer said; a Boost key that fires lifts its fit. Every filer's answers pass through it.
   */
  | { is: "cardKeys"; keys: { text: string; mode: "boost" | "require" | "also" | "exclude" }[] }
  /**
   * **Branches to another node** (round 2026-10-08D): down the tree, the walk may go on from here to
   * `to` as though it were one more child of this node — asked beside this node's own children, and
   * taken only if it fits, so it can be passed by. A link to a node outside the tree is the only way
   * into it.
   */
  | { is: "link"; to: string }
  /**
   * **Calls an agent** (round 2026-10-08D): an agent of the chat run on demand from the node's panel,
   * handed `prompt` and the memories filed under the node — a node's own helper the reader calls when
   * they want it.
   */
  | ({ is: "callAgent"; agent: string; prompt: string } & CallAgentWhen)
) & { off?: true };

/** Who files a node's children, and how often: on arrival, every N replies, or by hand. */
export type NodeFiling = { by: "classifier" | "closeReading" | "embedding" | "fused" | "player"; every?: number | "hand" };

/**
 * **A custom rule** (MEMORY-NODES.md §4) — the *Custom rule* behaviour: when it runs, what must hold,
 * what it does. One row of each table in `lib/memory/rules.ts` per test and per action. The named
 * behaviours compile to these (`BEHAVIOURS[…].rules`), so there is one engine under them all.
 */
export interface NodeRule {
  /** As a memory is filed here, or after every reply (every `every` replies). */
  when: "filed" | "reply";
  every?: number;
  /** Every test must hold; none is always. With `any`, one of them is enough. */
  if: RuleTest[];
  /**
   * **Any of the tests, not all of them** (round 2026-10-08D). One switch for the whole rule rather
   * than an "and" or an "or" between each two tests: mixing them needs brackets, and a reader who
   * wants that writes two rules.
   */
  any?: true;
  then: RuleAction;
}

/**
 * Who a note is for and how long it lasts — everything about a note except its text and
 * its place in the story.
 *
 * `Pick`ed from the stored shape rather than written out, because this travels the length
 * of the app: the tag parser reads it, the proposal carries it, the card draws it, the
 * composer primes it and `injectNote` files it. Every one of those used to name
 * `{ content, targetCharacterId }` by hand, so adding this second field would have been
 * five hand-written lists that had to agree — the shape §13 keeps warning about.
 */
export type NoteAddressing = Pick<HiddenInjection, "targetCharacterId" | "lifetimeReplies">;

/** A note as it is proposed or typed: what it says, plus who it is for and how long it lasts. */
export type NoteDirection = NoteAddressing & Pick<HiddenInjection, "content">;

/** How much the Director's notebook may hold: how many sections, and how long one may be. */
export type NotebookLimits = {
  /** The most sections the Director may keep at once. */
  sections: number;
  /** The most one section may hold, in characters. */
  characters: number;
};

/**
 * **One section of the Director's notebook** — a name the Director gave it, and its words.
 *
 * The notebook was five blocks the code named (premise, plan, open threads, secrets, player
 * read). The owner: *"lets make it so each section isn't hardcoded. the director can add / make
 * its own premise or plan, and keep track of anything it wants."* So the Director makes its own
 * sections, names them, rewrites, renames and removes them; the shipped prompt suggests a premise
 * and a plan as good first ones, and nothing in code knows either name.
 *
 * Still bounded (DIRECTOR.md §2): a free-form pad grows until it *is* the context problem it was
 * meant to solve. How many sections a notebook may hold and how long one may be are the chat's
 * (`notebookLimits`, Settings → Advanced), and a write past either is refused, not cut.
 */
export type NotebookSection = {
  /**
   * Stable across a rename — the undo record and the pane key on it. Never shown and never
   * written by a model: the tag names a section by its `title`.
   */
  id: string;
  /** What the Director called it. Unique in the notebook, by `sameSectionName`. */
  title: string;
  text: string;
  /**
   * **Kept in front of the Director**: carried at the top of its packet (the Pinned notes card)
   * and recited once more at its end — the few things it must not lose, which were the premise
   * and the beat when the code named them. Unpinned sections are carried after the indexes.
   */
  pinned?: true;
  /** Veiled in the pane until the reader asks — what knowing would spoil. */
  spoiler?: true;
  /**
   * The last story message when this was written; `null` before the story has one.
   *
   * What the packet marks a section *stale* by: a plan written twelve turns ago is not wrong,
   * but the Director should be told how old it is. Re-anchored the way a note's
   * `afterMessageId` is when the message it names is deleted or rewound past, so the mark
   * never points at a turn that is gone.
   */
  asOfMessageId: string | null;
  updatedAt: number;
};

/**
 * One write to a notebook section, named as the model wrote it: its words whole, a new name, a pin,
 * a spoiler mark — or, from `<notebook_remove>`, the section taken out. One event for both tags,
 * because they are one record with one undo. `STATE_EVENT_KINDS.notebook_set.validate` says what is
 * wrong with one — a section that is not there, a notebook full, a section over its cap — so the
 * model is told rather than silently defaulted.
 */
export type NotebookSet = {
  type: "notebook_set";
  section: string;
  /** The section's words, whole; empty when the write only renames, pins or marks it. */
  text: string;
  rename?: string;
  pin?: boolean;
  spoiler?: boolean;
  remove?: true;
};

export type Outbox = {
  depth: number;
  state: (intent: Intent, to?: string | undefined) => void;
  event: (intent: Intent, to?: string | undefined) => Promise<boolean>;
  frame: (intent: Intent, to?: string | undefined) => void;
  close: () => void;
};

export type OutboxOptions = {
  /** The POST. Never throws: a failure is an answer (`PostAnswer`), not an exception. */
  post: (intent: Intent, to?: string) => Promise<PostAnswer>;
  /** Sleep, injectable so a fixture can drive the backoff without waiting out its own test. */
  wait?: (ms: number) => Promise<void>;
};

export declare const PADDING: { readonly none: ""; readonly xs: "p-2"; readonly sm: "p-3"; readonly md: "p-4"; readonly lg: "p-6"; };

export declare const PROVIDER_CATALOG: { openrouter: { label: string; keyHint: string; sillyTavern: { source: string; modelField: string; unset: string; }; balance: { url: string; method: "GET"; auth: "bearer"; reads: "openrouter-key"; }; chat: ChatService; embeddings: EmbeddingService; rerank: RerankService; }; nanogpt: { label: string; keyHint: string; sillyTavern: { source: string; modelField: string; }; balance: { url: string; method: "POST"; auth: "x-api-key"; reads: "nanogpt-balance"; }; chat: ChatService; embeddings: EmbeddingService; decisions: DecisionService; }; anthropic: { label: string; keyHint: string; sillyTavern: { source: string; modelField: string; }; chat: ChatService; }; openai: { label: string; keyHint: string; sillyTavern: { source: string; modelField: string; }; chat: ChatService; embeddings: EmbeddingService; }; google: { label: string; keyHint: string; sillyTavern: { source: string; modelField: string; }; keyEnv: string[]; chat: ChatService; embeddings: EmbeddingService; }; deepseek: { label: string; keyHint: string; sillyTavern: { source: string; modelField: string; }; balance: { url: string; method: "GET"; auth: "bearer"; reads: "deepseek-balance"; }; chat: ChatService; }; xai: { label: string; keyHint: string; sillyTavern: { source: string; modelField: string; }; chat: ChatService; }; mistral: { label: string; keyHint: string; sillyTavern: { source: string; modelField: string; }; chat: ChatService; embeddings: EmbeddingService; }; groq: { label: string; keyHint: string; sillyTavern: { source: string; modelField: string; }; chat: ChatService; }; together: { label: string; keyHint: string; chat: ChatService; }; fireworks: { label: string; keyHint: string; sillyTavern: { source: string; modelField: string; }; chat: ChatService; embeddings: EmbeddingService; rerank: RerankService; }; cerebras: { label: string; keyHint: string; chat: ChatService; }; voyage: { label: string; keyHint: string; embeddings: EmbeddingService; rerank: RerankService; }; cohere: { label: string; keyHint: string; embeddings: EmbeddingService; rerank: RerankService; }; jina: { label: string; keyHint: string; embeddings: EmbeddingService; rerank: RerankService; }; brave: { label: string; keyHint: string; keyEnv: string[]; search: { url: string; dialect: "brave"; about: string; signup: string; }; }; tavily: { label: string; keyHint: string; search: { url: string; dialect: "tavily"; about: string; signup: string; }; }; serper: { label: string; keyHint: string; search: { url: string; dialect: "serper"; about: string; signup: string; }; }; };

export type ParsedDice = { text: string; terms: DiceTerm[] };

export type ParsedStream = {
  thinking: string;
  content: string;
  raw: string;
  timeline?: DirectorTimelineItem[];
  /**
   * The reply stopped because it ran out of room, not because it was finished.
   *
   * Set by the transport — the provider's own stop reason, or this app's own cap on how much
   * a reply may be — and never by `parseStreamText`, which is given text and has no way to
   * know how it ended. It matters because a reply cut at the ceiling ends mid-tag, which
   * reads downstream as a tool the model opened and never closed: the same evidence, a
   * different culprit, and a different fix.
   */
  truncated?: boolean;
  /**
   * Pictures the model made, as data URLs — the Image Writer's whole answer, beside whatever
   * words it added. Set by the transport off the dialect's reading (`StreamDelta.images`),
   * never by `parseStreamText`, and absent on every reply that made none.
   */
  images?: string[];
  /**
   * **How the provider said the reply ended** (`StreamDelta.finish`) — set by the transport, never by
   * `parseStreamText`, and absent when the provider never said. What decides whether an empty reply
   * is an answer or a failure (`refuseUnfinishedEmpty`).
   */
  finish?: Finish;
  /**
   * **The last line of `content` is still being written.**
   *
   * Told rather than worked out, because only this function can answer it. `content` is the
   * raw with its reasoning split off and its tags stripped, and `stripCompleteDirectorTags`
   * *trims* — so `content` never ends in a newline and the fact that says "this line is
   * finished" is destroyed on the way out. The reader downstream is the transcript, which
   * has to know which bubble the model is still typing into.
   *
   * It used to be recovered as `!raw.endsWith("\n")`, which is a different question and
   * disagrees exactly where a tool tag is: `"Prose.\n<roll dice=…"` does not end in a
   * newline, and its visible last line — `Prose.` — was finished several tokens ago. So for
   * the whole time a tag was being written, a settled bubble was marked as still arriving:
   * its typing animation was skipped (`revealTypesOut` refuses a line that is "arriving"),
   * and a *spoken* line in that state is not revealable at all, so the reveal sat behind a
   * typing indicator for a line it already had. Both around a tool call, which is where the
   * reader saw them.
   */
  lineOpen: boolean;
};

/**
 * What a read call becomes. Three families, each handled by a different part of the app:
 * an `event` is something the reader settles, an `action` is something the story carries,
 * a `query` is something the run answers itself. `control` is a tag the loop reads on its own
 * terms (`<ask_user>`, read leniently by its own parser) — it is here so the grammar
 * knows it, and `build` never has to produce it.
 */
export type ParsedTool =
  | { kind: "event"; value: StateOrchestrationEvent }
  | { kind: "action"; value: DirectorAction }
  | { kind: "query"; value: DirectorQuery };

/**
 * **A call still being written**, from its `<` to the end of the text.
 *
 * `spec` is known as soon as the name is: fully typed, or a prefix that only one tool has
 * (`<read_ca` can only become `<read_card`). `<state_de` names two tools and has none yet.
 * `call` carries the attributes that have closed so far, and the body so far once the
 * opening bracket has arrived — what a card draws while the rest streams in.
 */
export type PartialCall = {
  index: number;
  /** The name as far as it has been written. */
  wrote: string;
  spec?: ToolSpec;
  call?: ToolCall;
};

/** Free-form so a user-defined agent needs no code change. */
export type PassId = string;

/**
 * The seam of the turn an agent pass runs at.
 * - `on_user_input`: after the player sends a message, before the Writer responds.
 * - `post_narration`: after the Writer (or chain) finishes, before the player's next turn.
 *
 * There is no third value. `both` stood here, offered on every card as "On its own
 * schedule", and it was not a schedule: it made the row eligible at *both* seams with a stamp
 * and an ordinal per seam, so "every 3 turns" fired on every third player line and every
 * third reply, twice a turn, under a label that said neither. A stored row carrying it was
 * made the two rows it always was, once, by the one-off upgrade. The one agent that
 * legitimately runs at both seams says so by declaration — `AgentDefinition.scheduleOwnedBy`,
 * read by `seamsOf` — and not by a value the reader can set on any card.
 */
export type PassTriggerPhase = "on_user_input" | "story" | "post_narration";

/** How many pictures one line may carry and the size each is kept at — a story line's or table talk's. */
export type PictureLimits = Pick<AttachmentLimits, "maxPictures" | "pictureMaxDim">;

/** How wide a picture on a line is drawn, by default — `PICTURE_SIZES` is the table. */
export type PictureSizeOption = "small" | "medium" | "large" | "full";

/**
 * User-configurable pipeline pass definition.
 * Stored in `chat.chatSettings.pipelinePasses` as an ordered array.
 */
export interface PipelinePassConfig {
  /** The agent's id — "stateManager", "storyGuide", "summary", "option", or one somebody wrote — with a seat suffix for a second row (`basePassId`). */
  id: PassId;
  /** Human-readable display name */
  name: string;
  /** Optional description shown in the UI */
  description?: string;
  /** Master toggle — disabled passes are skipped entirely */
  enabled: boolean;
  /** When this pass runs relative to the main narration */
  phase: PassTriggerPhase;
  /**
   * Execution priority within its phase, and the concurrency model.
   *
   * Passes are grouped by `order` into **waves**. Waves run in ascending order with a
   * barrier between them; every pass inside a wave runs concurrently. So "options may
   * run alongside the state manager" is `options.order === stateManager.order`, and
   * "the story guide must see the state manager's updates" is a strictly greater order.
   *
   * One field, because ordering and co-execution are one fact. A separate
   * `parallelGroup` would have to be kept in step with this, and a `dependsOn` list
   * would be a second ordering record that admits cycles and dangling ids.
   */
  order: number;
  /** How often this pass runs: 1 = every turn, N = every N turns, 0 = manual only */
  turnCadence: number;
  /**
   * How much this pass may spend on this story, in tokens sent and received, before the
   * scheduler stops offering it. Absent is no ceiling. Read against the chat's own counter for the
   * pass's agent, summed over every device (`Chat.spent`, `pastCeiling`), so a phone and a desktop
   * writing one story share one limit. A hand-run is never refused.
   */
  tokenCeiling?: number;
  /**
   * **Whether cheap signals may bring this row's next run forward** — a scene change, a
   * closed arc, a moved number, a summary that just folded (`escalationSignals`). The cadence
   * is then the floor on how often the agent looks, not the ceiling.
   *
   * On the row, where the reader can see it and turn it off. It was a registry flag alone
   * (`AgentDefinition.escalates`), which decided for the Director with no control on any
   * screen saying so; the registry flag now says only that the switch is *offered*, and the
   * row is the answer. Carried rather than defaulted: a stored Director row that predated
   * the field was brought up to the shipped value once, by the one-off upgrade.
   */
  escalates?: boolean;
  /**
   * **The plugin that offered this agent**, stamped when the reader pressed Add on its ready-made row
   * (`lib/agents/add-ready.ts`): its id, the name the reader knew it by, and the offer's key. The card
   * draws the plugin's look from the offer while the plugin is installed and says whose it was after.
   * Carried only on such a row, so every other row serialises without the key.
   */
  from?: { plugin: string; name: string; template: string };
  /*
   * `requireApproval` stood here, "the pipeline pauses for user approval after this pass
   * produces proposals". One reader in the tree — the summariser — and every other agent
   * asked `autoApprovesFor` instead, so the field on a State Manager row decided nothing and
   * a reader who switched it was switching a picture. The summariser's copy is
   * the `summary_proposal` answer in `autoApprove`, beside the other answers to "may it act without
   * asking".
   */
  /**
   * **The states this pass keeps an eye on**, by state id, as its proposal declared them.
   *
   * It changes nothing about how the pass runs: the scheduler, the grant and the prompt are
   * unaffected. What it is for is the other direction — a reader looking at a number on a
   * card can be shown which standing agent is minding it, and several may mind one. The
   * relation is written down here rather than guessed at from a prompt's wording, which is
   * the "work it out from the text" shape that has cost this repo twice.
   *
   * Carried, never defaulted: a pass that watches nothing stores no key and serialises
   * byte-identically.
   */
  watches?: string[];
  /**
   * **The agent this one runs right after** — at that agent's point in the turn, and only on a
   * turn it actually ran (`lib/pipeline/runs.ts`). Absent is the ordinary row: its `phase` and
   * its cadence. Present, `phase` is a copy of the leader's seam, kept by `withFollowersSeated`.
   * Carried only when set, so a row that follows nobody serialises without the key.
   */
  after?: string;
  /**
   * **What an agent somebody wrote was written with — and the mark of one.**
   *
   * Present on authored rows only; a shipped agent's text lives in `DEFAULT_PROMPTS`
   * and its cards in `DEFAULT_MODEL_PROMPTS`, and neither has any business being copied here.
   * It is the *shipped default* for the pass, in the exact sense those tables are the shipped
   * default for a built-in: the stack materialises from it on read, Prompt Master's first edit
   * persists a stack of its own, and emptying the base block refills from here
   * (`shippedBasePrompt`). One home for the authored text, one for the edit, and the refill
   * reads the first — which is the owner's ruling on what "clear" means for an agent that has
   * no table row.
   *
   * - `prompt`: the base block's text.
   * - `tools`: the tool cards the stack ships with. On the row and not in a permission table,
   *   because a grant is not a table any more: a tool's paragraph in the stack, switched on,
   *   *is* the grant (`lib/tools/granted.ts`). Editing the stack afterwards is the live answer,
   *   the same as for every other agent — this is only what a reset returns to.
   *
   * One key rather than two fields, so "is this row authored" is `authored !== undefined` and
   * not a `typeof` on a string beside a list that might or might not be there. A stored row
   * that carried `prompt` and `tools` at the top had them folded in once, by the one-off upgrade.
   */
  authored?: { prompt: string; tools: string[] };
  /*
   * `cards`, `historyScope` and `includeChanges` were here — what an authored agent was
   * shown, on its row. Every shipped agent answers the same three questions on its stack
   * and its profile (the card slots' `cardIds`, the Chat History slot's `historyScope`, a
   * Recent changes switch since deleted), and an authored agent's stack carried the first two as
   * well, so each was two homes for one fact, read as `block?.field ?? row?.field`. They are
   * the slots' and the profile's now; the one-off upgrade moved them off every stored row.
   *
   * `model`, `inheritMaster`, `samplerSettings` and `allowThinking` were here. Every one of
   * them was a second home for a fact `${id}Settings` holds — which is what `resolveAgent`
   * reads — and each was either never written (`model`, `samplerSettings`, `allowThinking`)
   * or written beside the real answer (`inheritMaster`, which the card set as it cleared the
   * overrides that already meant "inherits"). A row carries scheduling and nothing else; a
   * stored row that wore one of these had it taken off once, by the one-off upgrade.
   */
}

/**
 * **One chat's turn, as the screens draw it.** Kept per chat in `ChatState.pipelines` — see there
 * for why it is not one record for the app.
 */
export interface PipelineState {
  isGenerating: boolean;
  /**
   * **The chat whose run this chat's turn is waiting behind** — null unless it is.
   *
   * One slot runs every chat's turn, so a line sent in chat B while chat A narrates is owed
   * until A lets go. That wait only logged: B's line sat under an idle composer with no
   * indicator, no status and no Stop until A's whole run ended. The owed turn is `isGenerating`
   * here, so B offers Stop (which drops the wait), and this says what it waits for.
   */
  queuedBehind: string | null;
  activePassId: string | null;
  /**
   * Phase of the pass named by `activePassId`. Reported by the pipeline rather than
   * inferred from the id, because "stateManager" is a valid id in both phases.
   * Type-only import — erased at build time, so this adds no runtime cycle.
   */
  activePassPhase: PassTriggerPhase | null;
  /**
   * Every pass currently in flight. A wave runs several at once, so `activePassId`
   * (the most recent to start) is no longer the whole story — it is kept for the
   * single-pass UI that only needs "something is running".
   */
  activePassIds: string[];
  generationError: string | null;
  /**
   * **Stop's "N replies hidden · Restore", as another screen's frames carry it** — null on the
   * screen that cut, where the offer is its whole undo (`pendingRevealUndo`) and this is worked out
   * from it as the frame is built (`currentRun`). A follower draws it, and its Restore and Dismiss go
   * to that screen through the press door: the offer stood on the presser's screen only, every other
   * screen showing the same story without it (ROUND-2026-11-02 §11).
   */
  restoreOffer: { hiddenTurns: number } | null;
  /**
   * **The reply a failed run had been asked to write again, put back where it stood** — what the
   * error box's Retry asks for again. Null unless the run that failed was a retry or a swipe.
   *
   * The box's Retry started a plain turn, which after a failed swipe wrote a reply to the reply
   * the failure had put back rather than another take of it. Told by the run that failed — it
   * knows what it was asked for and which reply it put back — never worked out from the transcript.
   */
  failedRetake: { messageId: string; generation: Exclude<GenerationType, "normal" | "quiet"> } | null;
  /**
   * Agents currently producing output, by id. This used to be `generatingModels`, a
   * list of display *labels*, which the UI then string-matched ("Story Guide") to
   * decide what to show — a second record of which agents are running, in a form
   * that broke as soon as a label changed. Labels come from the registry at render
   * time now.
   */
  activeAgentIds: AgentId[];
  generatingAvatar: string | null;
  generatingSpeaker: Character | null;
  /**
   * The id the narration in flight will be committed under, allocated before the
   * request goes out. Live bubbles key off it so they keep their React identity when
   * the message lands — see `buildStreamingTurns`.
   */
  generatingMessageId: string | null;
  /**
   * Live token stream per agent, keyed by agent id. An entry exists only while that
   * agent is mid-completion. Five separate `<agent>Streaming` fields meant the
   * orchestrator carried a pass→field switch and every consumer knew the field
   * names; adding an agent touched all of them.
   */
  agentStreams: Record<AgentId, ParsedStream>;
  /**
   * **The helpers spinning right now**, in the order they started.
   *
   * A subagent is the one thing in this app that can take several seconds with nothing at all
   * on the screen: its stream is deliberately not painted (a second typing indicator for a
   * helper the reader is never shown), so before this the pane simply sat there and the honest
   * conclusion was that the app had hung. The Director's loop reports each start and end
   * through `LoopProgress`; this is where the pane reads it.
   *
   * Only the *running* ones. A helper that has finished is on the reply's own trace (a
   * `tool_use` item with a result), which is what the card draws and what survives a reload —
   * two records of one finished run is the pair that always comes apart.
   */
  liveCalls: readonly LiveCall[];
  /**
   * **What each called run is writing right now**, keyed by its run id (`LiveCall.run`).
   *
   * Not `agentStreams[agentId]`: two tasks at once run on one subagent card, and a called agent's
   * stream in its own agent's slot fought its caller's for it — which is why a call's stream used
   * to be painted nowhere. Keyed by the run, it is the running card's to draw and nobody else's,
   * and an entry exists only while that run is writing.
   */
  runStreams: Record<string, ParsedStream>;
  /**
   * **The run each pass of the turn is running under**, by its agent — minted by the wave
   * (`runWave`), so the progress box can stop one pass and let the rest of the turn go on
   * (`skipPassRun`). Only while the pass runs.
   */
  passRuns: Record<AgentId, string>;
  /**
   * **How each agent of this turn's passes ended** — the progress box's dot for an agent that has
   * finished, failed, been stopped or skipped, while the rest of the turn is still running. Not a
   * record: what a pass did is on the chat. Gone when the turn is (`PIPELINE_AT_REST`).
   */
  agentOutcomes: Record<AgentId, AgentOutcome>;
  /**
   * **Every agent this turn has run, in the order it joined** — the progress box's rows, which keep
   * their places as the others finish (`rosterRows`). Appended by `setAgentActive`, the one door every
   * agent's announcement goes through; gone with the turn.
   */
  turnAgents: readonly AgentId[];
  /**
   * **The calls and tasks that ended this turn**, with how — the progress box keeps their row, its
   * dot saying how it went, once they have left `liveCalls`. What a call reported is the reply's own
   * record (a `tool_use` item); this is only how its row in the box ends. Gone with the turn.
   */
  endedCalls: readonly EndedCall[];
  /**
   * **Which step of its loop the Director is on**, while it runs — `null` between runs.
   *
   * The status box read "Running Director…" for a six-step run exactly as it did for one, and
   * the step count was known only afterwards from the trace's last line. The loop reports each
   * step as it starts; this is where the box reads it.
   */
  directorStep: { step: number } | null;
  summaryLoadingState: 'idle' | 'connecting' | 'summarizing' | 'success' | 'error';
  summaryError: string | null;
  activeBackgroundSummaryRange: { start: number; end: number } | null;
  toolLoadingState: ToolLoadingState;
  toolError: string | null;
  /**
   * **The pass a `cancelled` or `error` verdict is about** — what the status box offers to run
   * again, by name. Null when what stopped was not a pass it can run by hand (the Director's
   * pane, a picture for the draft).
   *
   * The box's button ran the literal `storyGuide` whatever had stopped — a failed reply
   * included, which wrote an `error` here with no `toolError`, so a second box read "Tool
   * analysis failed: null" under the real one. Written by every writer of those two verdicts.
   */
  stoppedPassId: string | null;
  /**
   * The queries the app has answered for the Writer **inside the reply now streaming**.
   *
   * A Writer's roll is committed with its message, and its message is committed when the
   * whole reply is — so between the tag arriving and the reply landing the story has a call
   * with no answer, which is exactly the spinner the reader asked for. It also has to *stop*:
   * the run tells the screen the moment each one comes back rather than the screen guessing
   * from where the tag sits in the text.
   *
   * Empty at rest and cleared with the rest of the run. The record on the message is the one
   * that lasts; this is the same fact a few seconds early.
   */
  writerRolls: readonly RollRecord[];
  /**
   * **When the pause between two AI voices runs out** — epoch ms, or null with no pause running.
   *
   * Set by the tab that runs the story when a turn stops between two voices under a pause
   * (`betweenVoices` as seconds), and cleared the moment anything starts. Not in `PIPELINE_AT_REST`,
   * because it begins exactly when a run has come to rest. Relayed, so a guest's strip counts the
   * same seconds down; it is never persisted, so a pause nobody is timing is a Wait.
   */
  pauseUntil: number | null;
  /**
   * **The chat's memories being filed now** — a Refile, a node's "File them", the filing after a reply
   * lands — or null. Written by `startRefile` alone (`lib/memory/refile-run.ts`). Not in
   * `PIPELINE_AT_REST`: a filing runs beside a turn, and the turn's end is not its end.
   *
   * Here, in the chat's one record of work in flight, so `inFlight` reads it: it lived in a store of
   * its own, and a long refile — two hundred paid answers, written as they landed — was nothing to
   * the relay. The other device was not told, wrote and sent beside it, and its later stamp took the
   * filings back (sweep 2026-11-01C, B1).
   */
  filing: RefileRun | null;
}

/**
 * What the app does with the reader's own lines as they are typed and sent — not a control the
 * composer draws, so not one of its extras (`ComposerTuning`).
 */
export type PlayerLineTuning = {
  /** A tool tag in the reader's own line read as the same tag in a reply is (`lib/chat/player-tags.ts`). */
  readTags: boolean;
  /** The `{{` list as the reader types a line — and the `<` list while `readTags` is on. */
  suggest: boolean;
};

/**
 * The ring round a speaker's picture: none, the theme's own (a quiet line in the theme's border
 * colour, what every picture has always worn), or a colour of the reader's, as `#rrggbb`.
 */
export type PortraitBorder = "none" | "theme" | `#${string}`;

/** Where a run's picture stands: beside its first bubble, or beside its last. */
export type PortraitPlacement = "first" | "last";

/**
 * **What one POST's answer means for the message it carried** — three, because two was a lie.
 *
 * The POST resolved a boolean, so "the network dropped for a second" and "the room will never
 * take this" were one answer, and the queue retried both forever. A guest whose portrait was
 * past the room's size ceiling (413), or whose intent was malformed (400), held the head of a
 * **serial** queue for the rest of the session: every line and gate press behind it waited on a
 * message that could not land, and the composer never got the words back because nothing ever
 * gave up on them. Retrying is right for a wire that may recover and wrong for a refusal that
 * says why it will not.
 */
export type PostAnswer = "landed" | "retry" | "refused";

/**
 * **Where a press goes when this tab does not hold the chat** — a guest's seat. Every press a
 * screen offers on a chat it holds is carried out here; on one it does not, it is sent to the tab
 * that does, which answers with the chat as it then stands.
 */
export type PressDoor = {
  line: (text: string, images?: readonly MessageImage[], files?: readonly MessageFile[]) => void;
  stop: (discard: boolean) => void;
  note: (note: NoteDirection) => void;
  messageAction: (
    action: MessageAction,
    turnId: string,
    content?: string,
    images?: readonly MessageImage[],
    files?: readonly MessageFile[]
  ) => void;
  answerEdit: (messageId: string, atOffset: number, edit: AnswerEdit) => void;
  proposal: (payload: ProposalActionPayload) => void;
  libraryEdit: (edit: LibraryEditPayload, base?: unknown) => void;
};

/**
 * What a bare number in a model listing's price means — see `PricingUnit`. Everything downstream
 * is dollars per million tokens; `free` is a local server, whose listing names no price because
 * there is none.
 */
export type PricingUnit = "per_token" | "per_million_tokens";

export interface PromptBlock {
  id: string;
  title: string;
  content: string;
  role: PromptRole;
  /*
   * A slot was declared here — `isImportBlock`, `importType`, and its scope in `historyScope`,
   * `cardIds`, `arcIds` and `from`, which the builders read some of and not others. It is spelled
   * in the text now (`{{chatHistory::last}}`, `{{characters::ana}}`), read by
   * `importKindsForBlock`, so what a block brings in is what it says. `.agents/MACROS.md` §2.
   */
  /**
   * When this block is in the prompt at all — a name from `lib/prompts/conditions.ts`,
   * optionally negated with a leading `!`. Absent or `"always"` means unconditional, which
   * is most blocks.
   *
   * The vocabulary is not written out here on purpose: it used to be, as a comment listing
   * four mode flags, and by the time the field was read one of the four named a mode that no
   * longer existed. `BLOCK_CONDITIONS` is derived from `CHAT_MODES` and is the only list.
   */
  condition?: string;
  /**
   * The reader opened the lock: the condition is kept on the card, as the tag that says which
   * setting the block belongs to, and no longer decides anything. `gateKey` in
   * `lib/prompts/condition-key.ts` is the one reader. Absent means the condition decides,
   * which is every shipped block.
   *
   * Not a `SavedPromptBlock` field: like `enabled`, it is a fact about being in *this* stack —
   * a paragraph kept on the shelf has no setting to be held out by.
   */
  conditionOverridden?: boolean;
  /**
   * **How a tool's card has the agent write its calls** — tags or a fenced JSON block — on a tool's
   * card and no other block (round 2026-10-30E: *"We can remove the 'How agents write tool calls' in
   * agents since we simply decide it in prompt master"*). It was one chat setting
   * (`ChatSettings.toolFormat`) over every agent's every card; the card is where the paragraph is,
   * so the card is where its format is. Absent is `DEFAULT_TOOL_FORMAT` (`lib/tools/format.ts`), so
   * every card written before this reads as it did.
   *
   * A shelf field too: a card kept on the shelf keeps the format it teaches.
   */
  toolFormat?: ToolFormat;
  trigger?: string;   // Prepared for user/AI tool call triggers
  /**
   * Sort order within its run, low first. **Position and nothing else** — `renumberStack`
   * rewrites it from the sequence the stack is in on every change.
   *
   * It used to carry a second meaning: 80 or above meant "bottom block", the reminder sent
   * after the history. Two facts in one number, and the arithmetic that writes it made the
   * eighth paragraph in a stack a reminder for sitting eighth. What is sent after the story is
   * decided by where a block sits relative to the slots — `bottomStartsAt` in
   * `lib/prompts/stack.ts` — so this is position, once.
   *
   * **Nobody writes this by hand** — see `DefaultPromptBlock`. It is derived from the array
   * the stack is in, everywhere, because for one block it was authored twice and the two
   * spellings disagreed.
   */
  order: number;
  enabled: boolean;
  isSystemDefault?: boolean;
  /**
   * **Wears no tool tag: its text is sent, and grants nothing it spells** (`.agents/MACROS.md`
   * §6.3). A block's tool tags are read off its text, and a tag is a grant — so an agent's own
   * base prompt, which names `<read_card>` or `<options>` in passing, would hand the agent every
   * tool it mentions with no card to switch off. That was an id rule nobody could see
   * (`isIdentityBlock`: an id holding `sys-base`, `sys-reminder` or `sys-directive`). The shipped
   * base prompts, reminders and directives carry this instead, and the block editor shows it as a
   * switch, so a paragraph that only talks about a tool says so on its face.
   *
   * Tool tags only. An import is not a mention in passing: `{{…}}` in a block always
   * brings its material, so the block is always that slot and follows its setting.
   */
  untagged?: boolean;
  /**
   * **The blocks the Chat History card carries into the story, each at a depth** — SillyTavern's
   * in-chat injection (round 2026-09-30, 2.2). Read on the card that places the transcript
   * (`sectionPlacesFor`) and on no other block: that card is where the turns are, so it is where a
   * block among them is written and shown. Nested rather than a stack block with a depth, because a
   * stack block's position would be a second fact the payload ignores. The array is their order.
   */
  inserts?: InsertBlock[];
}

export interface PromptOverrides {
  models?: Record<string, Partial<ModelPrompt>>;
  tools?: Record<string, Partial<ToolPrompt>>;
  blocks?: Record<string, PromptBlock[]>;
  /**
   * **In a preset only: the agents whose stack this preset says is the shipped one.**
   *
   * A chat has two answers per stack — its own (`blocks`), or the shipped one (absent). A preset has
   * three, because absent there means "this preset does not say" (the owner's ruling, round
   * 2026-10-22): resetting a stack to shipped while on a preset must write *that* up, or the preset
   * forgets the stack and applying it leaves another chat's edits in place. A list of ids rather
   * than a copy of the shipped blocks, so the preset follows the app's shipped text as it changes.
   * `presetLaidOver` turns it into a reset and never writes it to a chat.
   */
  shipped?: string[];
}

/**
 * **Prompt post-processing, as SillyTavern has it** — the shape a conversation is put into after
 * every builder has finished with it and before the dialect renders it for a provider. The owner,
 * round 2026-10-07: *"in advanced: add prompt post processing like silly tavern. (collapse multiple
 * user messages, collapse multiple system, assistant messages, etc...)"*
 *
 * Followed from SillyTavern's `src/prompt-converters.js` (`postProcessPrompt`, `mergeMessages`,
 * release branch, read 2026-10-07), mode for mode:
 *
 * - **none** — the conversation as the builders wrote it. The shipped answer, so every payload is
 *   the bytes it was.
 * - **merge** — consecutive messages of one role become one, their words joined by a blank line.
 * - **semi** — merge; then every system message but the first becomes a user message, and the run
 *   is merged again, so one system prompt leads and the roles after it alternate.
 * - **strict** — semi, and the conversation opens on the user: where the first message after the
 *   system prompt is not the user's, an opening line is put there (ST's "placeholder").
 * - **single** — every message a user message, the model's lines and the player's each led by its
 *   speaker's name, all merged into one.
 *
 * Where this differs from ST, on purpose: ST names its placeholder "Let's get started."; here it is
 * the one opening line the app already has — the server's own "Start with a user message", else its
 * shipped wording (`DEFAULT_USER_FIRST`) — so there is one line for one fact and never two. ST's
 * `name` fields and example-dialogue names have nothing to read here (a wire message carries no
 * name); its tool messages become user ones (ST's mode without tools — this app writes tool calls as
 * tags and sends no `tool` role of its own). Pictures ride beside the words (`ApiMessage.images`), so
 * a merged message carries every picture of the messages merged into it, in order.
 *
 * **Told, never worked out.** The result says which messages each one was made of (`from`), so the
 * Debug pane draws the processed conversation with every block still captioned, and a message that
 * came through untouched is the *same object*, so the run's marks on it (`lib/ai/fed-back.ts`) and
 * the Inspector's labels survive.
 */
export type PromptProcessing = "none" | "merge" | "semi" | "strict" | "single";

export type PromptRole = "system" | "user" | "assistant";

export interface ProposalAction<T = unknown> {
  id: string;
  type: ProposalActionType;
  payload: T;
  /** Director message rendering this action's own card, when it has one. */
  cardMessageId?: string;
  /**
   * Where in the reply the tag that raised this action was written — its index into the
   * anchoring message's `raw`. Stamped only by the Writer's commit, whose tags sit in the
   * message the transcript draws, so the card can stand after the bubble the sentence that
   * spent the arrow ends in; a pseudo reply that splits into six bubbles then places it after
   * the right one rather than under the message as a whole. A Director's action has none: its
   * tags are in its own reply, and an offset into that would be an offset into the wrong text.
   */
  atOffset?: number;
}

/** A verdict on a Director's proposal pressed at a seat that does not hold the chat. */
export type ProposalActionPayload = {
  action: ProposalIntentAction;
  bundleId: string;
  /** Fields changed on an edit, keyed as the bundle's own action's. */
  edits?: Record<string, unknown>;
  actionId?: string;
  payload?: unknown;
  denied?: boolean;
  actionIds?: string[];
};

export type ProposalActionType =
  | "speaker_call"
  | "injection"
  | "state_event"
  | string;

export interface ProposalBundle {
  id: string;
  chatId: string;
  /** The single source of truth for whether this proposal has been settled. */
  status: ProposalStatus;
  /** Which agent produced this, resolved through lib/agents/registry. */
  agentId: string;
  actions: ProposalAction[];
  /**
   * Actions the user declined individually, by id — the "deny one card of a bundle"
   * feature. Deliberately a list on the bundle, not a status on the action: `status`
   * stays the ONLY approval-shaped field (§2), the bundle stays exactly one pending
   * unit, and `keptActions` below is the single rule every reader and the apply loop
   * share. Absent means none. A record, not a deletion — the denied action survives as
   * history and can be un-denied until the bundle settles.
   */
  deniedActionIds?: string[];
  /**
   * **What an approval ran and could not do**, by action id, with why — in words addressed to the
   * reader. A record beside `deniedActionIds`, not a status: the bundle was approved, and each of
   * these actions was run and changed nothing, because the chat had moved on since it was
   * proposed (the state it moves deleted, the item it spends already spent, the card it names
   * left out of this same bundle).
   *
   * The apply used to warn in the console and settle the bundle approved regardless, so the
   * card read "Applied" over a change that never landed. The card reads this instead. Absent
   * means everything approved ran.
   */
  refused?: Record<string, string>;
  /**
   * **Approved by the agent that made it, so what it still holds applies as it lands.**
   *
   * A Writer's tag in a pseudo reply used to apply the moment the reply committed, while the
   * reveal was still typing out the bubbles *before* it — so a reader who stopped, or sent,
   * before the card had appeared was already living with its effect: *"during narration prose,
   * a user can interrupt and use a gun even though it's been set that he would lose the gun if
   * he had continued."* A card that has not appeared has not happened.
   *
   * **Its `status` is `approved` from the start**, because nobody is being asked: the agent's
   * auto-approve already answered. What waits is the *landing* (`held`), and the flag goes when
   * the last held action has landed. It says which of the two things a landing does — apply, or
   * ask — and is not a second copy of either: a bundle the *reader* approved is approved without
   * it, and what the reveal still holds for one of those is asked about afresh (ARRIVAL §9.2).
   */
  appliesWhenShown?: boolean;
  /**
   * **What the reveal has not shown yet** — `.agents/ARRIVAL.md` §9.
   *
   * A bundle is what the reader has been shown. The actions whose card has not landed, and
   * everything that waits for the reply to be shown whole, are here instead of in `actions`, so
   * every reader of `actions` — the pane's cards, the count, Approve, the apply loop — reads only
   * what has landed without a filter of its own. One door moves an action out
   * (`landHeldActions`, driven by the reveal), which is what makes this exactly the future the
   * reader has not reached: a cut drops it, and nothing of it was ever posted, applied or asked.
   *
   * It used to be the whole bundle posted at commit, with a progress list for the auto-approved
   * half (`appliedActionIds`) — so the pane, the banner and the badge showed every proposal of a
   * reply while its first bubble was still being typed.
   *
   * Absent when nothing is held, which is every bundle once its reply has been read.
   */
  held?: {
    actions: ProposalAction[];
    /**
     * The card the reader will answer these on, when the agent minted one for them — posted
     * when the first of them lands, so a card is never drawn with nothing on it. Absent when the
     * agent's own reply is the card (the Director's), or when nothing is asked.
     */
    card?: DirectorMessage;
  };
  anchorMessageId?: string;
  directorMessageId?: string;
  /**
   * **The agent whose `<call_agent>` this run answered**, when one did. A called run's cards are an
   * answer to that agent, not the agent's review of the message, so the next run of the agent on
   * the same message does not replace them — and a called run replaces nothing either
   * (`clearLastToolPass`). Absent on a scheduled or a hand run.
   */
  calledBy?: string;
  timestamp: number;
}

export type ProposalIntentAction = "approve" | "reject" | "edit" | "deny" | "restore";

/**
 * A proposal is pending until the user settles it. This replaces the
 * `approved`/`rejected` boolean pair, which could represent the nonsensical
 * "both true" and disagreed about whether rejecting should also clear approved.
 */
export type ProposalStatus = "pending" | "approved" | "rejected";

/**
 * What a chat talks to: a built-in provider that writes stories, or one of the reader's servers.
 *
 * Read off the catalog rather than listed here (`config/providers.ts`): this union was typed out
 * beside the table it had to match, so adding a provider was two edits that had to agree. A row
 * with a `chat` service is a `Provider` by being written.
 */
export type Provider = ChatProviderId | CustomProviderId;

/**
 * Which machines behind an aggregator should serve the request.
 *
 * A model on OpenRouter is not one endpoint: `anthropic/claude-opus-5` is served by
 * Anthropic direct, by three Bedrock regions, by Vertex and by Azure, and they differ in
 * price, in quantisation, in context length and in what they log. Left alone the router
 * picks; this says otherwise.
 *
 * `order` is a preference, not a filter — that is what `allowFallbacks` is for. Both are
 * stored, and stored together, because sending one without the other means a different
 * thing to the API than the reader intends: an order with fallbacks on is "try these
 * first", the same order with fallbacks off is "these or nothing".
 */
export type ProviderRouting = {
  /** Endpoint tags, in the order they should be tried. Empty means no preference. */
  order: string[];
  /** Whether an endpoint outside `order` may serve the request. */
  allowFallbacks: boolean;
  /**
   * **What decides which host goes first** — the reader's `order`, or a measure the router keeps.
   * One field, not a sort beside the order: OpenRouter applies `sort` only "if `order` is not
   * specified", so the two side by side would be a control that silently did nothing. Absent on a
   * chat stored before it existed; `resolveProviderRouting` fills it.
   */
  sort?: RoutingSort;
  /** The most a host may charge; a side left out has no ceiling. Filled by `resolveProviderRouting`. */
  maxPrice?: RoutingMaxPrice;
};

/**
 * **The reveal as the screen holding the chat's reading has it** — `.agents/history/ROUND-2026-11-02.md` §4.3.
 *
 * Every screen walked its own reveal, so two screens on one reply showed different bubbles, cards and
 * holds, and each landed what it alone had shown. Now one screen holds the reading
 * (`lib/server/pipeline-relay.ts`, "The holder") and publishes this; every other screen draws it and
 * walks nothing (`mirrorReveal` in `lib/chat/reveal.ts`).
 *
 * Named by identity, never by index: `at` is the message the cursor stands in (the reply still
 * streaming, by the id it commits under) and how many of its bubbles are shown; turn ids are the chunk
 * ids every screen already agrees on (`readGateId` relies on the same agreement).
 */
export type PublishedReveal = {
  at: { messageId: string; chunkIndex: number | null } | null;
  cards: { turnId: string; shown: number } | null;
  gate: { kind: "dialogue" | "narration"; turnId: string; offered: boolean; byPause?: true } | null;
  paused: boolean;
  /** The bubble whose typing indicator is up — the follower types it locally, on its own clock. */
  typing: string | null;
  /** The reader has bubbles or cards of this chat still to be handed out. */
  behind: boolean;
};

/** A request field that says which side of the search the texts are on, and its two values. */
export type PurposeField = PurposeWords & { readonly field: string };

/** What a query is called, and what a document is called, in one hint. */
export type PurposeWords = { readonly query: string; readonly document: string };

/** Who answers a query (`ToolSpec.answeredBy`). */
export type QueryAnswerer = "app" | "model" | "agent" | "web";

export declare const RADII: { readonly none: ""; readonly sm: "rounded-md"; readonly md: "rounded-lg"; readonly lg: "rounded-xl"; readonly xl: "rounded-2xl"; };

/** The levels a reader can ask for, weakest first after `auto`. `budget` is the thinking allowance. */
export declare const REASONING_LEVELS: readonly [{ readonly id: "auto"; readonly label: "Model default"; readonly budget: 0; readonly blurb: "Nothing is sent. The model thinks as much as it usually does."; }, { readonly id: "minimal"; readonly label: "Minimal"; readonly budget: 1024; readonly blurb: "Barely at all — the fastest and cheapest a reasoning model gets."; }, { readonly id: "low"; readonly label: "Low"; readonly budget: 2048; readonly blurb: "A short think before answering."; }, { readonly id: "medium"; readonly label: "Medium"; readonly budget: 8192; readonly blurb: "A considered think — most models' own default."; }, { readonly id: "high"; readonly label: "High"; readonly budget: 16384; readonly blurb: "A long think. Slower, dearer, and better at hard turns."; }, { readonly id: "xhigh"; readonly label: "Extra high"; readonly budget: 24576; readonly blurb: "Longer still, on the models that take it."; }, { readonly id: "max"; readonly label: "Maximum"; readonly budget: 32768; readonly blurb: "As long as the model allows. Slowest and dearest."; }];

/**
 * **The type a change of a plugin's kind is filed as** (`RegisteredEvent`), its kind's own name beside
 * it — `StateOrchestrationEvent` is closed for the reason `DirectorQuery` is (`REGISTERED_QUERY`).
 */
export declare const REGISTERED_EVENT: "registered";

/**
 * **The kind a tool a plugin registered builds** (`addToolSpecs`): one kind for all of them, with the
 * tool's own name beside it (`RegisteredQuery.tool`), because `DirectorQuery` is a closed union every
 * reader narrows and a name chosen at run time cannot be one of its literals.
 */
export declare const REGISTERED_QUERY: "registered";

/**
 * What of `PipelineState` crosses as it stands. The other two buckets — reshaped on the way, and
 * withheld — and the check that every field is in one of the three are in `story-sync.ts`, beside
 * the reasons.
 */
export declare const RELAYED_PIPELINE_FIELDS: readonly ["isGenerating", "activePassId", "activePassPhase", "activePassIds", "generationError", "activeAgentIds", "generatingMessageId", "liveCalls", "turnAgents", "agentOutcomes", "endedCalls", "writerRolls", "directorStep", "summaryLoadingState", "summaryError", "activeBackgroundSummaryRange", "toolLoadingState", "toolError", "filing", "failedRetake", "stoppedPassId", "restoreOffer"];

/**
 * Everything that decides which cards retrieval hands an agent.
 *
 * One shape, resolved per agent. The chat-wide `rag*` settings are the defaults;
 * an agent overrides any subset of them through `ModelSettings.rag`. Nothing in
 * lib/rag.ts reads chat settings itself — it is given a policy and applies it, so
 * "which agent is this for" never has to be threaded through the ranker.
 */
export type RagPolicy = {
  enabled: boolean;
  /**
   * Whether the query window is counted in messages or in tokens.
   *
   * Two modes because they fail differently: whole messages never begin mid-sentence but cost
   * whatever people happened to type, while a token budget is even but can start mid-thought. This
   * side had only the first once, which made "how far back does the search look" answerable in one
   * unit on one screen and the other unit on the next.
   */
  windowMode: ChunkMode;
  /** `messages` mode: how many recent messages form the retrieval query. */
  windowSize: number;
  /** `tokens` mode: the query's ceiling, filled from the newest message backwards. */
  windowTokens: number;
  /**
   * Whether a reply of several lines is several units of the window, or one.
   *
   * A pseudo reply is one stored message and ten bubbles, so "the last five messages" was
   * five replies of ten lines — fifty bubbles of query behind a control that said five. On,
   * the window is counted in the lines the transcript draws (`chunkBody`'s rule), and each
   * carries its own speaker's name into the query rather than "Assistant:".
   */
  countLines: boolean;
  /** What the query does with a `Name:` at the start of a line. See `ChatSettings.speakerPrefixes`. */
  speakerPrefixes: SpeakerPrefixRule;
  /**
   * Minimum score to admit a card at all. **0 is no minimum** — the shipped answer since round
   * 2026-10-06: the budget is the cutoff, and a floor under it is an extra the reader switches on.
   */
  threshold: number;
  /**
   * How much each scoring signal counts — the whole tuning surface. This replaced the
   * engine picker and the rank modes: one candidate is scored by every signal whose
   * weight is above 0 and the fused score is their weighted mean, so there is no single
   * "scorer" field any more. `lib/rag/fusion.ts` owns the defaults and the math.
   */
  signalWeights: SignalWeights;
  /** Which cards close reading reads — see `CloseReadingReach`. */
  rerankReach: CloseReadingReach;
  /** How many: the best N, or N either side of the cut. The cost dial. */
  rerankDepth: number;
  /**
   * One model per engine, so the wrong-checkpoint pairing that `rankingSettings` once
   * existed to prevent — a cross-encoder name handed to the embedder, which loads
   * nothing — is not representable at all.
   */
  embeddingModel: string;
  rerankerModel: string;
  replaceRules: readonly ReplaceRule[];
  inheritChatRules: boolean;
  /** Card families retrieval ranks. A family that is off is passed through unranked. */
  rankCharacters: boolean;
  rankWorlds: boolean;
  /**
   * How many further turns an admitted card stays admitted for. 0 is off.
   *
   * Without it, every turn re-ranks from nothing, so a card can be in the prompt, out of it,
   * and back in across three consecutive turns as the conversation drifts — which reads to
   * the model as the world forgetting and re-learning a fact. Stickiness is a *decaying
   * floor* now, not a hard counter: an admitted card's score floor falls linearly to zero
   * over this many turns, and the card stays while the floor still clears the cutoff. The
   * reader buys continuity with tokens; the decay is what stops a long-gone card riding
   * its old score forever.
   *
   * The reader's hand on the scale is `Character.activation` / `World.activation` — a fact
   * on the card, not a per-chat pin table. The old `pins` field lived here and in a debug
   * modal; a card the story is about is `"active"` now, everywhere the card goes — and it is
   * a floor of 1 in the same map as these (`lib/rag/floors.ts`), not a path of its own.
   */
  stickyTurns: number;
  /**
   * **How far back a card's keys are read**: the newest message and this many before it, for every
   * key a card has. A Require or Exclude key said anywhere in them gates the card, with the ranking
   * on or off; a Boost key's evidence fades `KEY_MEMORY_DECAY` a message back (`rememberedKeys`). It
   * is not the query window: the window is what the models read, and a lorebook entry named eight
   * messages ago is usually still the place the scene is in (`.agents/history/RAG-PASS6.md`).
   */
  keyDepth: number;
  /**
   * What a card being *linked* to somebody in the scene is worth: the floor it stands on.
   *
   * 0 is off, and a link changes no ranking at all. It was a three-way mode beside this
   * number, and the mode made the number irrelevant two answers out of three — two controls
   * over one fact (§12).
   *
   * **An addition, not a floor** (`.agents/history/RAG-PASS5.md`, `RAG-PASS6.md`). It was a floor under every
   * card linked to anybody in the cast, shipped at 1: in a cast of twenty a list of every owned or
   * linked card in the story sat at the top of the scale, −19 points of need-recall on the devset
   * stories. Now the walk runs once, and a card linked — either way, either relation — with a card it
   * let in gets this much added to its score for a second walk. A card's fused score runs ~0.54 at a
   * pool's middle to ~0.87 at its top and the 5th and 10th are ~0.04 apart, so a few hundredths
   * settles close calls between related cards; at 0.5 it is the old pin again. It still faces the
   * threshold and the budget like any score.
   */
  linkLift: number;
  /**
   * What a card in a present character's lorebook is worth: the floor it stands on while one of
   * the lorebook's owners is in the scene (`lorebookFloors`). 0 scores each entry as a card of its
   * own, 1 puts the whole book in.
   */
  lorebookFloor: number;
  /** The floor a card the Director is holding in the story stands on — see `lib/director/boosts.ts`. 1 is the top of the scale. */
  directorBoostFloor: number;
};

/** How many results a ranking answers with, when the tag asks for a number. */
export type Ranked = { top?: number };

/**
 * A fixed amount of raw transcript, in whichever unit the reader chose to name it.
 *
 * `turns` counts sent messages back from the end — a turn is a message, as everywhere a screen
 * says "turn" (`lastTurnsStart`); `tokens` walks back until the next turn would not fit. Both resolve to the same thing in the end — an index history starts at — and both
 * are pulled back to the nearest summary boundary, so neither can land inside a covered range.
 */
export type RawHistorySize = { unit: "turns" | "tokens"; amount: number };

/**
 * **Where a guest's reading had got to, named by identity rather than by position.**
 *
 * This was a `TurnCursor` — a message *index* — on the reading that "both tabs hold the same
 * transcript and a stale cursor clamps". Neither half was true of a table. The index was a
 * position in the *guest's* copy, applied to the host's *newer* one, and the cut that follows
 * it discards everything past it: two guests who had read to the same bubble both sent the
 * same index, so the second one's line pruned the first one's out of the story; a guest one
 * append behind deleted a reply every other screen had already read; and nothing stopped a
 * hand-written `messageIndex: -1` from emptying the transcript for everyone.
 *
 * So the guest names things the host can check, and the host refuses to cut through anything
 * it cannot account for (`placeReadingMark`):
 *
 *  - `messageId` — the message the reader's cursor stands in (the reply still streaming, when
 *    that is where it stands: its id is the one it commits under);
 *  - `chunkIndex` — how much of that message they had been shown;
 *  - `through` — the last message this tab held. If the host's story has moved past it, the
 *    guest spoke over a story they had not been sent, and nothing is cut.
 */
export type ReadingMark = {
  messageId: string;
  chunkIndex: number | null;
  through: string;
};

export type ReasoningLevel = (typeof REASONING_LEVELS)[number]["id"];

/** `why` on each: where the facts were read — every row of `config/providers.json` says. */
export type ReasoningWire =
  | { style: "openrouter"; why?: string }
  | {
      style: "effort";
      /** The request field the word goes in. */
      field: string;
      /** What a model no family row matches is offered. */
      rule: LevelRule;
      /** Families that take something else — the first matching row wins. */
      models?: readonly ModelLevelRule[];
      /** Whether this provider counts reasoning inside the reply cap. */
      countsInCap: boolean;
      why?: string;
    }
  | { style: "anthropic"; why?: string }
  | {
      style: "fixed";
      /** Why nothing can be asked — said where the level would be chosen. */
      why: string;
    };

/**
 * **Which models can refile memories** (§5.2): Classification, Close reading cross-encoder,
 * or Embedding.
 */
export type RefileFiler = Extract<MemoryFiler, "classifier" | "closeReading" | "embedding" | "fused">;

export type RefileRun = {
  chatId: string;
  /**
   * How many memories this run files — what it was handed, until the runner says how many it will
   * really ask about (a memory moved by hand and kept there is not asked about, and is not counted).
   */
  total: number;
  /** How many have landed — filed, or failed with the reason on their row. */
  done: number;
  /** The memories that have landed, in the order they did — what the toast walks through. */
  landed: readonly string[];
  /** Its run in the progress store, drawn by `LiveRunProgress` — null when the work named no stages. */
  progressId: number | null;
};

/** Where a rule's refile files a memory: among the sub-nodes of the place it is at, or down the whole tree. */
export type RefileScope = "children" | "tree";

/**
 * **A change of a kind a plugin registered** (`lib/director/proposal-kinds.ts`): the kind's name, whose
 * it is, and the call as the grammar read it. One type for every plugin's kinds, with the name beside
 * it, for the reason `RegisteredQuery` is one: this union is closed and every reader narrows it, and a
 * name chosen at run time cannot be one of its literals. Filed, themed, approved and applied under
 * `kind` (`eventKindOf`), never under `"registered"`.
 *
 * `from` is stored with it so a chat whose plugin has gone still says whose change it was.
 */
export type RegisteredEvent = {
  type: typeof REGISTERED_EVENT;
  kind: string;
  from: { plugin: string; name: string };
  args: Record<string, string>;
  body?: string;
};

/** A call to a registered tool, as `DirectorQuery` carries it. */
export type RegisteredQuery = { kind: typeof REGISTERED_QUERY; tool: string; args: Record<string, string>; body?: string };

export type RelayedPipelineField = (typeof RELAYED_PIPELINE_FIELDS)[number];

/** One agent's stream, as a follower is given it: the display text, never the raw buffer. */
export type RelayedStream = { content: string; thinking: string; lineOpen: boolean };

/**
 * Turning a chat into bubbles.
 *
 * This used to live inline in ChatMessageList as one ~120-line useMemo with three
 * near-duplicate branches — committed messages, committed pseudo chunks, and the live
 * stream. Each answered "who is speaking" with its own copy of the logic, and they
 * drifted: the same narrator turn resolved to the Narrator character on one path and
 * to null on another, so its avatar changed the moment narration was committed.
 *
 * There is one rule here now (resolveSpokenName / forMessage) and the call sites keep
 * only what genuinely differs between a committed message and a live one: the turn id,
 * the timestamp, and whether it is still streaming.
 *
 * Pure and free of React so it can be exercised directly.
 */
export interface RenderedTurn {
  id: string;
  originalMessage: Message;
  speakerId: string;
  speakerName: string;
  speakerCharacter?: Character | null;
  isUserPersona: boolean;
  content: string;
  timestamp?: number;
  turnIndex: number;
  /** Which chunk of its message this bubble is; null when it is the whole message. */
  chunkIndex: number | null;
  /**
   * The line of the message's `content` this bubble was cut from — `PseudoChunk.lineIndex`,
   * carried so the Writer's cards can be placed: a tag's offset is turned into a line of
   * the visible text (`lineAtOffset`) and the card stands after the last bubble at or before
   * it. Absent on a whole-message bubble, which has nowhere else a card could go.
   */
  lineIndex?: number;
  /**
   * **What was written under this bubble, when a find-and-replace rule drew it differently** — the
   * text its editor opens on. Absent when the bubble draws what was written. `lineIndex` is a line of
   * the stored text either way, so a card is placed after the bubble its tag was written in.
   */
  written?: string;
  /**
   * A line of the story rather than a person's message — see `isProseChunk`.
   *
   * Carried as a fact and not as a presentation, because how it is drawn is the user's
   * (`narrationLineStyle`) and this is not. The speaker is still filled in — the narrator —
   * so a turn is never half-identified whichever style is in force.
   */
  isNarration?: boolean;
  /**
   * **This row is a picture written in the prose, and draws no bubble** — `PseudoChunk.picture`,
   * told by the chunker rather than found again in `content` by the renderer. `content` is still
   * the markup that was written, which is what the row's editor opens on.
   */
  picture?: ChunkPicture;
  isStreaming?: boolean;
  /**
   * Arriving, and too ambiguous to draw yet — so it is a typing indicator and nothing else.
   *
   * Half of `Elena: hi` is `Ele`, which has no name in front of it and is therefore
   * narration as far as the parser can tell. Drawing that flickers a line of story before
   * every bubble in a reply. The line used to be dropped from the list entirely, which
   * traded the flicker for silence: in a pseudo message a line of narration is all name-shaped
   * characters until its first full stop, so the whole line arrived before anything at all
   * appeared on screen.
   *
   * Emitting it as a promise instead means the indicator goes up when the model *starts*
   * the line rather than when it finishes it. `ChatMessageList` never renders its text.
   */
  isPending?: boolean;
}

/**
 * **Find-and-replace on the story's text** (`<replace>`, `lib/text/replace.ts`).
 *
 * `target` is one address or a comma-separated list (`character:<id>:description`, what `<search>`
 * answers with); with none, every place in `scope` that holds `find`. `find` is text or `/regex/`.
 * One place must hold it exactly once unless `all`.
 */
export type ReplaceEvent = {
  type: "replace";
  target?: string;
  scope?: string;
  find: string;
  replacement: string;
  all?: boolean;
  /**
   * **What it changes, fixed the moment it was proposed** (`freezeReplace`) — the card the reader
   * approves is a record of these places and these words, never a question asked of the chat again.
   *
   * It was asked again by everything that read it — the apply, the card's drawing, its subject, its
   * title — and a replace is not idempotent: "Vek" → "Captain Vek" approved and applied then drew
   * "Captain Vek → Captain Captain Vek", and one approved after the text moved applied to places the
   * reader had never been shown. Absent only while a reply is still being written, and on cards
   * settled before it was kept, which draw what they asked.
   */
  planned?: FrozenReplace;
};

/**
 * **One find/replace pair** — a regular expression and what to write in its place, applied to what
 * the transcript draws, to what the prompt sends, or both. `.agents/IMPORT-EXPORT.md` §6.4.
 *
 * Three promises, each held by a shape rather than by care:
 *
 * - **A stored rule always compiles.** `find` and `flags` are checked where a rule is written (the
 *   editor keeps an uncompilable pattern as a draft; an import leaves it out and says so), so nothing
 *   that runs a rule has a validity question to answer every turn (`lib/regex/rule.ts`).
 * - **It never rewrites a stored message.** It changes what is drawn and what is sent, through one
 *   function each way (`lib/regex/chat-rules.ts`); `Message.content` stays as written.
 * - **It never runs on what the app parses.** Tool tags, state updates, speaker attribution and the
 *   stream's tool scanner read the stored text, so a rule can restyle a reply and cannot change what
 *   the reply did.
 */
export type ReplaceRule = {
  id: string;
  name: string;
  enabled: boolean;
  /** The pattern, without slashes. */
  find: string;
  /** A subset of `REPLACE_FLAGS` ("gimsu"). */
  flags: string;
  /** What each match becomes: `$1`, `$<name>`, `$&` and `{{match}}` are the match's parts. */
  replace: string;
  /** Taken out of every part of the match before it is written into `replace`. */
  trim?: string[];
  /** Whose messages it reads — the AI's replies, the player's lines, or both. Never empty. */
  lines: ReplaceRuleLines[];
  where: "screen" | "prompt" | "both" | "query" | "cards";
  /** How far back it reaches, counted from the newest message (0). Absent bounds are no limit. */
  depth?: { min?: number; max?: number };
  /**
   * Switched off because running it stopped the app on a device, and when (`lib/regex/stall-off.ts`).
   * Said on its row; switching it on clears it, which is "try again" on every device. Absent: it
   * never stalled, or was tried again since.
   */
  stalled?: { at: number; ms?: number };
};

export type ReplaceRuleLines = "replies" | "player";

/** One place a proposed replace changes: where, and its whole text before and after. */
export type ReplacedPlace = {
  /** The field's address, by ids (`lib/text/corpus.ts`), so a rename does not move it. */
  at: string;
  /** The place as the reader knew it when it was proposed — `Ana — Description`. */
  label: string;
  before: string;
  after: string;
  /** How many occurrences in it change. */
  count: number;
};

/** What the reply-length cap is called. OpenAI's reasoning models refuse `max_tokens`. */
export type ReplyCapField = "max_tokens" | "max_completion_tokens";

export type RerankDialectId = "cohere" | "tei";

export type RerankService = {
  url: string;
  dialect: RerankDialectId;
  /**
   * Fields every request carries besides the dialect's own — Jina and Fireworks return each
   * document's text unless told not to, which is the whole candidate list sent back per turn.
   */
  extra?: Readonly<Record<string, unknown>>;
  /** Already 0..1, or raw logits the reader must squash (llama.cpp's server). */
  scale: "unit" | "logit";
  /** The most documents one request may carry. */
  maxDocuments: number;
  /**
   * The most tokens one request may carry, counted as the provider counts them — the query once per
   * document, plus every document — where it documents such a limit, and absent everywhere it does
   * not. A request over it is refused whole: Voyage's Close reading of a few hundred memories, every read.
   */
  maxRequestTokens?: number;
  models: readonly string[];
  listing?: RetrievalListing;
};

/**
 * One key on a character or world card. Whole-word, case-insensitive — or, written `/like this/`
 * with optional flags, a regular expression matched as written, as a SillyTavern key is.
 */
export type RetrievalKey = { text: string; mode: RetrievalKeyMode };

/**
 * How one retrieval key gates or boosts its card.
 *
 * `boost` feeds the keywords signal when matched; `require` keeps the card out of the
 * pool until one of the card's require keys appears in the query window; `also` is a second
 * such gate — "and one of these too", SillyTavern's secondary keys under its default logic — so
 * a card with both needs one of each; `exclude` bars the card whenever it matches. Require, also
 * and exclude are eligibility, not score — a card they remove never reaches the ranker at all,
 * and they gate whether or not retrieval is ranking.
 */
export type RetrievalKeyMode = "boost" | "require" | "also" | "exclude";

/**
 * **Where a provider lists the models of one retrieval service**, when it does — so the card's
 * model browser shows what is really on offer, with its price, rather than the row's few
 * suggestions. Absent for a provider with no such listing (Voyage, Cohere, Jina publish none a
 * browser can filter by service), and then the suggestions are the list.
 *
 * Each is a public page — no key — and each was fetched and read on 2026-09-26.
 */
export type RetrievalListing = {
  url: string;
  /**
   * What a price in the listing is. **`none` where it prints one that is not what is billed**:
   * OpenRouter lists every reranker at "0" and charges per search, so a "Free" badge there would be
   * the one wrong thing the browser could say. Such a row is drawn "Price not published".
   */
  prices: PricingUnit | "none";
  /** Ids the listing marks free in the id itself — OpenRouter's `:free` — whatever `prices` says. */
  free?: RegExp;
};

/** What happens after a bubble lands: a timer, or a person. */
export type RevealGate = "timed" | "continue";

/** What kind of line a bubble is, for the two rules that pace them differently. */
export type RevealGateKind = "dialogue" | "narration";

/**
 * **Where the reader was, and what held them there** — the cursor, the hold and the pause, as one
 * value: what a run starting from it needs to walk the rest of a queue the way it would have been
 * walked. The hold is kept unoffered (`unoffered`): the run that starts from here offers it again
 * with the next bubble in hand.
 */
export type RevealPlace = { cursor: TurnCursor; gate: RevealState["gate"]; paused: boolean };

/**
 * The pseudo-message reveal, and who is allowed to move it.
 *
 * The animation runs in `ChatMessageList` but is cancelled from `useChatEngine` — Stop
 * cuts the transcript, retry replaces its tail, switching chats abandons it. A
 * component-local worker id can only be bumped from inside that component, so the engine
 * had no way to stand a worker down: it moved the cursor and the worker, mid-`sleep`,
 * woke up and wrote its own older cursor straight back over it. That is why a reply the
 * player interrupted appeared to be overwritten.
 *
 * `epoch` is the cancellation token, and it lives in the store because both sides can
 * reach it. One run owns the reveal at a time; anything that moves the reveal from
 * outside bumps the epoch, and every step the worker takes is a no-op once it has.
 */
export type RevealState = {
  /**
   * **The chat whose transcript this reveal describes**, or null for none. Written by every write that
   * stands the reveal somewhere new (`standAnew`), kept by every step a run takes inside it.
   *
   * One record serves every chat the tab opens, and a cursor is an index — so a reveal written for one
   * chat reads as a place in any other. Switching chats wrote the new chat's held-back place before the
   * old chat's transcript had left, and the old chat then kept "its" place off the new chat's cursor:
   * a bubble of another story, or past its end nothing at all, and coming back showed the reply whole
   * (2026-11-04). Named, a reveal of one chat cannot be read as another's (`parkReveal`).
   */
  chatId: string | null;
  /** A run is in progress. Drives the Stop button. */
  active: boolean;
  /**
   * The bubble an indicator is standing in front of, and since when. Null when none is up.
   *
   * **The run raises it, and nothing else does.** It raises it while it types out a bubble it
   * already has, and while it waits behind a line the model is still writing — the second is
   * what lets it tell, on arriving, a line the reader watched being written from one written
   * before they got here, and not type the first out a second time.
   *
   * The transcript used to raise it too (`announceReveal`), for any line it was withholding,
   * on its own clock — and so it went up during the run's **rest** after the bubble before.
   * The reader saw no pause after a line, only the next indicator; and the run, waking from
   * its rest, counted the rest as time spent watching that indicator and paid the next
   * bubble's typing off with it, so it landed at once. Whether that happened depended on
   * whether the model was still writing the next line when the last one landed — which is
   * why it was *"sometimes, not even consistently"*, why a character carrying on (whose next
   * line is the likeliest to be still in flight) showed it most, and why two screens at a
   * table, reading one reply through different transports, skipped different pauses. One
   * producer, which walks rest → indicator → bubble in that order, is what makes the
   * indicator unable to stand inside a rest.
   *
   * **It was a bare boolean, and that is two facts in one field.** "An indicator is on
   * screen" is what the interrupt cut asks (a promise was made, so the bubble in hand
   * lands); "the reader has already waited for *this* bubble, for *this* long" is what the
   * run asks before deciding whether to type it out. They are usually true together and do
   * not have to be — the first chunk of every pseudo reply spends a few characters unclaimed,
   * which raises the indicator for an instant — so the opening bubble of a burst was
   * routinely credited with a wait nobody had sat through and appeared instantly. See
   * `typingDebtMs`, which is the rule that reads this.
   */
  typing: { turnId: string; since: number } | null;
  /** The last turn shown. `null` means nothing is revealed yet. */
  cursor: TurnCursor | null;
  epoch: number;
  /**
   * The reveal is stopped at `cursor` until the player says go on. Null when nothing holds.
   *
   * The *fact* is here; the promise is not. A promise is not serialisable, nothing that
   * subscribes to this store could call it, and putting it here would re-render every
   * subscriber over a value none of them can read. It lives in module state beside the
   * epoch that cancels it.
   *
   * **The hold outlives the run that set it, and the offer does not.** They are two facts
   * and were one: a run sets the hold the moment a gated line lands, and then finds there is
   * nothing behind it yet — the reveal has caught up with the model — so it waits on the
   * transcript, and until the next line arrives there is nothing to ask about. A run stood down
   * then (a cut, a chat switch) must not take the hold with it, or the next line would be handed
   * over unasked by the run after it, which is the gate being skipped; and if the *offer* stood
   * before the line did, a Continue button would stand under a story with nothing left to show,
   * which is a control that does nothing. So the hold is written when the line lands and
   * `offered` only once a run is parked with the next bubble in hand.
   */
  gate: {
    kind: RevealGateKind;
    turnId: string;
    /** A run is parked here with something to hand over. **Read `revealOffer`, not this.** */
    offered: boolean;
    /**
     * Held only because the reader paused — the line itself would have flowed on. At a table that
     * is the difference between a place in the story every screen stops at (a gate, named by the
     * line) and a pause the whole table is under, which each screen meets at whatever line it has
     * in hand and which one press ends everywhere (`plugins/multiplayer/client/continue-gate.ts`).
     */
    byPause?: true;
  } | null;
  /**
   * How many of one row's tool cards have been shown — its `before` first, then its `after`.
   *
   * **A card is a step of the reveal, not decoration on a bubble.** They used to be drawn the
   * instant the reply committed, all of them, wherever the reveal happened to be — so a diff
   * card for the first line of a burst appeared while the reader was three bubbles further
   * down, which reads as the app catching up rather than as the story happening in order. The
   * run walks them the way it walks bubbles: reveal one, take a beat, reveal the next.
   *
   * Null means **nothing is being withheld** — no run is pacing this row, so every card it has
   * is drawn. That is the state every path but a live run leaves behind, which is what lets a
   * card that arrives after the reveal has gone past (a proposal commits at the end of a
   * reply) still appear rather than waiting for a walk that has finished.
   */
  cards: { turnId: string; shown: number } | null;
  /**
   * The reader asked the queue to hold.
   *
   * Distinct from `gate`: a gate is this bubble waiting for you, a pause is every bubble
   * after it waiting too. Set from the composer while replies are flowing past faster than
   * they can be read, and cleared only by continuing.
   */
  paused: boolean;
  /**
   * The reading pause the run is sitting out right now, and how long it is — null when it is not
   * resting. Only a rest: a bubble being typed out has its indicator to say so, and a hold waits
   * for a press, which has no length. What the composer's ring draws (`ComposerTuning.continueWait`).
   */
  beat: { since: number; ms: number } | null;
};

export type RollOutcome = {
  dice: ParsedDice;
  rolled: RolledTerm[];
  /** With an extra modifier added, when one was named. */
  total: number;
  modifier?: { label: string; value: number };
  vs?: number;
  /** `total >= vs` — meeting the target is making it. Absent without a target. */
  success?: boolean;
  /**
   * **The total was set by the reader, not added up** — it is not the faces and the modifier's
   * sum, which `rollSum` still answers. Absent on every throw, and on a reader's edit of the faces,
   * where the total follows them. The sentence says so (`describeRoll`) and so does the card, so
   * neither claims the dice came to a number they did not.
   */
  setByHand?: true;
};

/**
 * A roll the app threw for the Writer while it wrote this take — where the tag sat in `raw`
 * and what came up. Kept on the take (`MessageTake.rolls`) rather than re-derived, because the
 * dice cannot be thrown again: the scene was written from *these* faces, and a swipe back to
 * this take must show the roll it was written from, not a fresh one.
 */
export type RollRecord = {
  atOffset: number;
  /** The sentence the model was answered with — the one thing that goes back into the prompt. */
  result: string;
  /**
   * Which tool asked, by its kind. The Writer cuts its stream for any query it holds, not only the
   * dice (`isCuttingLookup`), so a card that drew every record as a roll was captioning a
   * `read_card` answer with a die.
   */
  tool: string;
  /**
   * The throw itself, when it was one.
   *
   * **The card is told, not left to read the sentence.** Colouring a success, a failure or a
   * lucky roll means knowing the target, the total and what the dice could have done, and
   * every one of those is in here — recovering them by parsing `result` is the shape
   * CLAUDE.md's second corollary names. `result` stays because it is what the model was sent.
   */
  roll?: RollOutcome;
  /**
   * **The call this answers**, as the tool's own arguments — `tool` is its name — so it can be
   * shown again in whichever form the chat writes calls (`renderCall`) and read back by the real
   * parser when the reader rewrites it (`lib/chat/answer-edits.ts`).
   *
   * Kept on the record rather than found in `raw`, because `raw` stops holding the tag the moment
   * the line's words are edited (`rewriteMessageIn`): the words become the raw, and every tag goes.
   * It is also where whose throw it was and what hung on it are read from (`answerAbout`) — those
   * were an `about` field beside it, the same two arguments stored twice. Absent on an answer whose
   * call could not be recovered when the field arrived.
   */
  call?: { args: Record<string, string>; body?: string };
  /**
   * **What a plugin's tool handed its card** (`LookupAnswer.data`) — the card is told, as a roll's
   * is by `roll`, and never reads the sentence back. Absent for the app's own tools.
   */
  data?: Record<string, unknown>;
  /**
   * **The plugin whose tool answered**, by id and name. Kept so the card can still say whose it was
   * when the plugin is switched off or removed ("from Dice Tower, not installed") instead of drawing
   * an answer nobody can explain.
   */
  from?: { plugin: string; name: string };
  /**
   * **The reader changed this answer after it was given** — its call, or what the next turn reads
   * of it (`lib/chat/answer-edits.ts`). The card says so, so it never claims the dice or a card
   * said something they did not; the prompt reads the edited `result` as the answer, since it is
   * the story's now.
   */
  edited?: true;
};

export type RolledTerm =
  | { sign: 1 | -1; sides: number; values: number[]; kept?: number[] }
  | { sign: 1 | -1; constant: number };

export type RoundCalls = "off" | "resume" | "follow";

/** A place in the round as the walk sees it: the loop entry it came from, and whose seat it is. */
export type RoundEntry = { key: string; seat: Seat };

/**
 * A price ceiling in **US dollars per million tokens** — OpenRouter's `max_price` unit (`{"prompt": 1}`
 * is "<= $1/m prompt tokens"). A hard filter: a host dearer than this is never used.
 */
export type RoutingMaxPrice = { prompt?: number; completion?: number };

/**
 * `order` — the reader's list (empty: the router's own choice); the rest are OpenRouter's
 * `provider.sort` values: cheapest, most tokens a second, soonest first token.
 */
export type RoutingSort = "order" | "price" | "throughput" | "latency";

export type RuleAction =
  | { do: "burn" }
  | { do: "move"; to: string }
  | { do: "alsoFile"; to: string }
  | { do: "pin" }
  | { do: "unpin" }
  /**
   * File the memory again, with `with` (absent: whoever files after a reply) — among the sub-nodes of
   * the place it is at (`children`), or down the whole tree (`tree`). Always stored: a scope left out
   * was read as the whole tree by the rule engine and drawn as "into sub-nodes only" by its editor.
   */
  | { do: "refile"; with?: RefileFiler; into: RefileScope }
  | { do: "check" }
  /**
   * **Call one of the chat's agents** (round 2026-10-08D) — once for the node, not once a memory: it is
   * handed `prompt` and the memories filed there. `atCount`: only as the node comes to hold a multiple
   * of that many (*Calls an agent*, "once this many are here").
   */
  | { do: "callAgent"; agent: string; prompt: string; atCount?: number };

export type RuleTest =
  | { test: "age"; atLeast: number }
  | { test: "unsent"; atLeast: number }
  | { test: "sent"; atLeast: number }
  | { test: "fit"; above?: number; below?: number }
  | { test: "read"; above?: number; below?: number }
  | { test: "pinned"; is: boolean }
  | { test: "kind"; is: "fact" | "passage" }
  | { test: "crowded"; over: number };

/**
 * **How long the agents' run records are kept, and whether the Inspector shows the gone ones** —
 * `lib/agents/runs.ts` (`pruneOldRuns`, `runsHorizon`) and the Inspector's Runs view read them.
 */
export type RunLogTuning = {
  /**
   * The newest this many messages keep every run recorded about them, their takes' too; older ones
   * keep only each agent's newest run, which is what says where the agent is up to.
   */
  keptFor: number;
  /** The Inspector's Runs view also draws runs whose turn is gone — rewound, deleted, or past `keptFor`. */
  showDeleted: boolean;
};

/**
 * **The turn in flight, as one message.**
 *
 * `story_chunk` and `story_status` were two kinds for one fact and had to be ordered by hand at
 * each call site ("sent *after* the chunk bookkeeping, so 'the bubble closed' always reaches a
 * guest before 'the turn is over'"). One value cannot arrive out of order with itself.
 */
export type RunStatePayload = {
  state: Pick<PipelineState, RelayedPipelineField>;
  /** The speaker of the narration in flight; the receiver's own roster draws the face. */
  speakerId: string | null;
  streams: Record<string, RelayedStream>;
  /** How long the between-voices pause has left, stamped into a deadline at the receiver. */
  pauseInMs?: number | null;
  /**
   * **The host's reveal, at a table** (`PublishedReveal`): every guest draws it and walks nothing.
   * Absent while the host is not on the story's screen (there is no reveal of it to follow), and on
   * the owner's own relay, which publishes the reading on its own (`PublishedReading`).
   */
  reveal?: PublishedReveal | null;
};

export declare const SOURCES: readonly [{ readonly id: "chub"; readonly label: "Chub AI"; readonly blurb: "The largest public catalogue. Also known as CharHub and characterhub.org."; readonly hosts: readonly ["chub.ai", "charhub.io"]; readonly search: (query: string, limit: number, signal: AbortSignal) => Promise<SourceCard[]>; }, { readonly id: "character-tavern"; readonly label: "Character Tavern"; readonly blurb: "Community cards with a fast index — search by name, then filter by taste."; readonly hosts: readonly ["character-tavern.com"]; readonly search: (query: string, limit: number, signal: AbortSignal) => Promise<SourceCard[]>; }, { readonly id: "botbooru"; readonly label: "BotBooru"; readonly blurb: "Booru-style archive — heavily tagged, and searchable by tag."; readonly hosts: readonly ["botbooru.com"]; readonly search: (query: string, limit: number, signal: AbortSignal) => Promise<SourceCard[]>; }, { readonly id: "aicharactercards"; readonly label: "AI Character Cards"; readonly blurb: "A curated catalogue with token counts and its own quality grading."; readonly hosts: readonly ["aicharactercards.com"]; readonly search: (query: string, limit: number, signal: AbortSignal) => Promise<SourceCard[]>; readonly resolve: (id: string, signal: AbortSignal) => Promise<CardDownload>; }];

/** The brand only this file can write — see `SpeechRule`. */
export declare const SPEECH: unique symbol;

/**
 * **How a box of text an agent is writing is drawn** — its reasoning, or an agent at work.
 *
 * Folded is the header alone, which is how reasoning has always been drawn (the owner's ruling,
 * *"make sure that thinking box for models is closed/minimized by default"*). A window is a few
 * lines that follow the end of the text as it arrives, so a reader can watch it being written
 * without the reply landing under a panel of it. Open is the whole text, unfolded. Whichever it
 * is, a press on the box's header still opens or folds that one box.
 *
 * One list for the settings that take it (`reasoningBox`, `agentStreamBox`) and for the box
 * that reads them (`StreamBox`), so a screen and the box cannot come to mean two things by one word.
 */
export declare const STREAM_BOX_VIEWS: readonly ["folded", "window", "open"];

/**
 * Lists of identified records, merged one record at a time.
 *
 * The `global*` entries are the libraries — what you have saved outside any one chat, to drop
 * into the next one. They are a row each rather than one keyed record because the merge is per
 * record and the records are different shapes; everything *above* the storage layer treats
 * them as one thing, and `lib/library/registry.ts` is where that list lives. The prefix is not
 * decoration: `tests/unit/library.test.ts` reads the shelves out of this object by it, in both
 * directions, so a shelf stored without it is a shelf nothing checks.
 */
export declare const SYNC_COLLECTIONS: { readonly chats: "chats"; readonly globalRoster: "global_roster"; readonly globalWorlds: "global_worlds"; readonly globalFaces: "global_faces"; readonly globalArcs: "global_arcs"; readonly globalPromptBlocks: "global_prompt_blocks"; readonly globalBackgrounds: "global_backgrounds"; readonly libraryFolders: "library_folders"; readonly presets: "presets"; readonly fonts: "fonts"; readonly settings: "settings"; };

/** The knobs `buildSamplingBody` can write, by their wire names. `max_tokens` is the reply cap, not a knob. */
export type SamplerKnob =
  | "temperature"
  | "top_p"
  | "top_k"
  | "min_p"
  | "top_a"
  | "repetition_penalty"
  | "frequency_penalty"
  | "presence_penalty";

/**
 * What a family of models takes where it differs from its provider. The first row whose pattern
 * matches the model id wins: its `takes` and `whileThinking` replace the provider's, and its
 * `names` and `ranges` override the provider's knob by knob.
 */
export type SamplingFamily = {
  match: RegExp;
  takes: "all" | readonly SamplerKnob[];
  whileThinking?: readonly SamplerKnob[];
  names?: WireNames;
  ranges?: KnobRanges;
  why: string;
};

export type SamplingParams = {
  temp: number;
  topP: number;
  repPen: number;
  maxTokens: number;
  frequencyPenalty: number;
  presencePenalty: number;
  topK: number;
  minP: number;
  topA: number;
  /**
   * **DRY** ("Don't Repeat Yourself"), on the servers that take it (`SamplingWire.dry`): how hard a
   * repeated run of tokens is penalised — 0 is off and sends nothing — the base the penalty grows
   * by, and how long a repeat may run before it is penalised at all.
   */
  dryMultiplier: number;
  dryBase: number;
  dryAllowedLength: number;
};

export type SamplingWire = {
  /** Every knob, or the ones this provider takes. */
  takes: "all" | readonly SamplerKnob[];
  /**
   * Of what it takes, what it still takes while the request has the model think
   * (`requestThinks`). Absent: thinking changes nothing. OpenAI's GPT-5.2 takes a temperature only
   * at effort `none` and refuses one at any other; DeepSeek takes the penalties and ignores them
   * while it thinks — a slider drawn there decides nothing.
   */
  whileThinking?: readonly SamplerKnob[];
  /** Absent: every field under the name it was built with. */
  names?: WireNames;
  ranges?: KnobRanges;
  /** Model families that take something different — OpenAI's reasoning models take no sampler at all. */
  models?: readonly SamplingFamily[];
  /**
   * Whether it takes the DRY sampler (`dry_multiplier`, `dry_base`, `dry_allowed_length`), and where
   * that is documented. Apart from `takes`, because "every knob" on OpenRouter or a proxy means the
   * eight every OpenAI-shaped API has heard of; DRY is a few local servers' own, and goes nowhere
   * else. Absent: never sent, and its sliders are not drawn.
   */
  dry?: string;
  /** Where these facts were read — every row of `config/providers.json` says. */
  why?: string;
};

/** A call the grammar read whole. */
export type ScannedCall = { spec: ToolSpec; call: ToolCall };

/**
 * The turn rules: one labelled table per question, and the pure answers every surface reads.
 *
 * `.agents/TURNS.md` §28 is the design. It replaced an axis of three modes (Live, Pass the mic,
 * Wave batch) and four turn orders under it, because the product of the two answered two
 * different questions in one list — *how AI voices follow each other* and *how people get the
 * floor* — and most of it decided nothing. What is left is four questions, each drawn only
 * where its answers differ:
 *
 *  1. who writes (`narratorMode`, `config/chat-modes.ts` — not here);
 *  2. the order: free for all, or a round — and, under each, what a call does;
 *  3. what happens between two AI voices;
 *  4. at a table, whether the players' turns are batched into one window.
 *
 * Pure on purpose: no store, no wire, no clock reads. The walk (`nextInRound`) is asked by the
 * chat's own turn system on your own *and* at a table (`lib/speaker.ts`), so there is one walk
 * and a room only adds people and a window to it. What the table holds live — the window's
 * tallies, the clock, where the host seated people — is `plugins/multiplayer/client/roomStore.ts`, and whose turn
 * it is at a table is *derived* from the chat (`lib/mic/floor.ts`), never stored beside it.
 */
export type Seat = string;

export type ShelfLayout = keyof typeof LAYOUT_PICTURES;

/**
 * **The chat card a shelf card was saved from** — so saving that card again updates this one
 * (`shelveCharacter`), where every save used to add another: "Sparkle (2)", "Sparkle (3)", each
 * with its own copy of her lorebook (round 2026-10-03B, the owner's "yes").
 *
 * On the shelf card, not the chat's: saving to the shelf writes nothing into the story, and a chat
 * id is a uuid, so a card cannot be taken for another library's that shares its slug. Written by
 * the three saves in `lib/cards/to-shelf.ts` alone — `shelveCharacter` on her and on the lore cards
 * it files in her lorebook, `shelveWorld`, `shelveArc` — and shelf bookkeeping like `folderId`: a
 * pick into a chat or a file does not carry it (`cardBatchFor`, the story manager's pick,
 * `recordFileJson`), so a card picked off the shelf and saved back is a card of its own. A shelf
 * card saved before this existed has none, and the next save adds a card as it always did; that one
 * is updated after.
 */
export type ShelfOrigin = { chatId: string; cardId: string };

/** What a write through a shelf's door came to: the cards as filed, and why any were not (`CardsAway`). */
export type ShelfWrite<T> = { filed: T[]; away: CardsAway | null };

/** Per-signal multipliers, 0..2. 0 turns the signal off entirely. */
export type SignalWeights = Record<"lexical" | "semantic" | "reranker" | "keywords", number> & {
  classifier?: number;
  branch?: number;
};

/**
 * `xs` is for a control that stands *inside* another control -- the close on an armed chip
 * over the composer -- where the floor the other three keep (44px under a finger) made the
 * chip itself 46px tall and pushed the composer down the screen: *"make sure the arm HUD box
 * isn't too big vertically."* It keeps a smaller coarse floor rather than none, because a
 * finger still has to land on it.
 */
export type Size = "xs" | "sm" | "md" | "lg";

/**
 * One search result, as the picker and the preview read it.
 *
 * `provider` is deliberately **not** something a row writes: `searchCards` stamps it from the
 * row it called, so a mapper cannot label its own cards as somebody else's — which is what
 * the deleted `characterhub` branch did on purpose (`{...node, provider: "characterhub"}`
 * over Chub's nodes) and what made two picker entries indistinguishable.
 */
export type SourceCard = {
  /** The site's own id. Also the "already imported" key — see `Character.cardSourceId`. */
  id: string;
  name: string;
  /** Small image for the grid. May be webp — the preview reads the response's content type. */
  avatar_url?: string;
  /** Large image for the preview panel. */
  max_res_url?: string;
  description?: string;
  tagline?: string;
  topics?: string[];
  nTokens?: number;
  /** Favourites/likes/stars — whatever the site's own "people liked this" number is, or
   *  nothing at all. Left undefined rather than defaulted to 0, so "★ 0" means zero rather
   *  than "this site does not count". */
  starCount?: number;
  /**
   * The card itself. Absent when the site needs a second request to find it — see `resolve`.
   */
  downloadUrl?: string;
  /** What `downloadUrl` serves: a character-card PNG, or the card's JSON directly. */
  downloadType?: CardDownloadType;
};

/** What the transcript does with a `Name:` at the start of a line. See `ChatSettings.speakerPrefixes`. */
export type SpeakerPrefixRule = "shown" | "repeated" | "hidden";

export type SpeakingOrder = "free" | "round";

/**
 * How long a name may be, beyond which characters it may contain.
 *
 * A sentence is made of the same characters a name is. *The lunch period timer on the wall
 * clock reads 12:35.* was read as a character called "The lunch period timer on the wall
 * clock reads 12" saying "35. Twenty-five minutes left." — a line of narration posted as
 * somebody's words, and from there into the next prompt as a person who had spoken.
 *
 * Two limits, because neither one catches the other's case: a sentence long enough to hold
 * a clock exceeds the word count, and a bare `12:35` is one word. Generous on purpose —
 * "The Voice in the Wall" is a name somebody will write, and refusing a real speaker draws
 * their line as narration, which is the same bug pointing the other way.
 *
 * Shape is all there is here. `She had one rule: never look back.` is four short words and
 * passes, and no rule written against the *text* can do better — only the cast could, and
 * this function is asked about lines from a model that introduces characters before the
 * roster has them.
 *
 * The numbers are the chat's (`ChatSettings.spokenLines`, shipped at five words and 32
 * characters), and every reader asks them of the rule it is handed (`SpeechRule`).
 */
export type SpeechBounds = { maxWords: number; maxChars: number };

/**
 * What a speaker rule is made of: the bounds, and the pattern a spoken line opens with before its
 * name — a regular expression as the reader types it, read with the `u` flag; empty for none.
 */
export type SpeechInput = SpeechBounds & { prefix: string };

/**
 * **What counts as somebody speaking** — the one rule every reader of a `Name:` line is handed.
 *
 * A `Name:` is read in a dozen places: the transcript's two builds (and the hold-back while a name
 * is half-typed), the bubble, the cast's guess at who wrote a message, the prompt builders, the
 * retrieval query, an edit, a delete, a picture's row. They used to share one pattern that took no
 * settings, which was right while the rule had nothing a chat could change. Once it has, a reader
 * left on the shipped rule is a second rule — a line drawn as Ana's bubble and sent as narration —
 * so the rule is a value, derived from the chat once (`speechRuleOf`) and handed in.
 *
 * Branded, so a reader cannot write one for itself: only `compileSpeechRule` makes one, and
 * `tests/unit/speech-rule-callers.test.ts` holds every caller to being handed it.
 */
export type SpeechRule = SpeechInput & {
  readonly [SPEECH]: true;
  /** A whole speaker line under this rule — `speakerLine`. */
  readonly line: RegExp;
  /** How many groups the reader's own pattern has, which the line's groups are counted after. */
  readonly groups: number;
  /**
   * What the live stream holds back while a line could still become somebody speaking, where a
   * mark is asked for (`trailingLineCouldBeSpeaker`): the mark whole and a name part-way through
   * it (`named`, the name its last group), and the mark itself part-way through (`beginning`,
   * null for a pattern that cannot be rewritten — `patternBeginnings`). Null where no mark is.
   */
  readonly holds: { named: RegExp; beginning: RegExp | null } | null;
};

/**
 * **What the changes were spent on, which says who spent them.** A typed send spends them on its
 * line, and the line names its speaker (`speakerCharacterId`). A press with no line names the seat
 * that pressed it, since there is no line to read the speaker from.
 *
 * The spender was this screen's persona (`getPlaceholderData`). At a table the host's door files a
 * guest's armed changes, so a guest who lit a torch reached the Writer as
 * `[<the host's character> actions: …]`, and the Writer gave the host's character the guest's action.
 */
export type SpentOn = { line: string } | { seat: string };

/** What a `<state_set>` does to a value: adds to it, or writes it whole. */
export type StateAction = "add" | "edit";

export type StateChange = {
  type: "character_add" | "world_add" | "state_update" | "arc_add" | "arc_update" | "memory_add" | "memory_update" | "memory_node" | "agent_add" | "agent_update" | "agent_remove" | "notebook_set" | "entity_states" | "entity_states_pair" | "boost_card" | "replace" | "registered";
  entityId: string; // character id, world id, storyArc id, memory id (ids, for a move), node id, setting name, or pack id
  targetKey?: string; // e.g. state key or "title" or "content" or action type or setting key or tracker field id
  previousValue?: unknown; // captured previous value/object
  /**
   * The value as this change **left** it — the witness.
   *
   * `previousValue` alone can only be assigned back, and assigning is right only when the
   * whole set of later changes is being undone with it. Deleting one middle turn is not
   * that set, so restoring a card's whole state list there wiped every later turn's
   * changes to the same card, with no record that it had happened.
   *
   * With this, undo is a three-way merge (`lib/state/undo.ts`): unchanged since — put the
   * earlier value back; changed since — a later writer owns it. Absent on the adds
   * (`character_add`, `world_add`, `arc_add`), whose undo deletes what they made without
   * asking, and on a record stored before the witness existed, which restores absolutely.
   */
  appliedValue?: unknown;
  /**
   * **What a relative change moved** — a `<state_delta>`, or each side of a `<state_transfer>`:
   * the card, the state, and the amount it really moved (after clamping), signed.
   *
   * A delta adds an amount, so once anything else has moved the same state its undo is
   * *subtract what I added*, not *put back what I found* — which the witness merge can only
   * answer by leaving the entry alone. It did, the record was dropped anyway, and the drift was
   * permanent: a swipe or a deleted turn left the other writer's change and this one's both in
   * force. Absent on every change that sets rather than moves (`lib/state/undo.ts`).
   */
  moved?: { entityId: string; stateId: string; by: number }[];
  /**
   * **A reply's `raw` before a `<replace>` rewrote its words** — the model's text, tags and all,
   * which a rewrite collapses to the new words (`rewriteMessageIn`). The undo stands the old words
   * back on it (`writeField`), so a rewind gives the reply back as it was written and not as its
   * words alone. Only on a replace of a line that had a raw.
   */
  previousRaw?: string;
  description?: string; // description of the change (optional)
  promptOverrides?: PromptOverrides;
  tool?: string;
  /**
   * The `ProposalAction` that made this change, when one did.
   *
   * The app has always known it — `actionRegistry.applyAction` is holding the action while
   * the change is written — and used to throw it away, so every reader that needed "which
   * proposal did this?" re-derived it from *which message the change was filed on*. That is
   * a narrower rule than the filing, and where the two disagreed both undo paths broke:
   * deleting one card reopened its whole bundle (the message owns several actions), and
   * deleting a director message left changes filed elsewhere applied with nothing left to
   * undo them. Told, not inferred.
   *
   * Absent on a change no proposal made — a player's own armed state action, a tool pass.
   */
  actionId?: string;
  /**
   * **The note this change is the doing of** — a player's own armed action.
   *
   * Arming something in the state drawer and sending does two things at once: it moves the
   * state, and it files a Director's note telling the Writer what was done. They are one
   * operation, so the note is the receipt for the change, and deleting the receipt undoes the
   * transaction: *"if I arm a state diff, and I delete the director's note, it actually reverts
   * the state back."*
   *
   * Told rather than inferred — the same argument `actionId` above makes. The alternative is
   * matching a note's *text* against the changes filed on the message it is anchored to, which
   * is a display recovering a fact its producer already had (§13.2) and would take the wrong
   * changes the moment two turns armed the same state.
   *
   * Absent on every other change, including a proposal's: a Director's card is undone by
   * rejecting the card.
   */
  noteId?: string;
};

/**
 * **The four state tags — one that shapes a card, three that move what is on it.**
 *
 * None of them carries a value to write, which is the rule that survived the trackers whole:
 * a model asked for the new value of a stat after a wound writes an absolute, and the absolute
 * is wrong. A number moves by a `delta` the code clamps; an item moves by a signed count or a
 * wear percentage; a transfer moves what one card holds to another.
 *
 * Each of the three carries `evidence`, the Writer's line it was read from, and
 * `STATE_EVENT_KINDS[…].validate` refuses one without it — a change to a number nobody wrote
 * down is the failure the typed state exists to end.
 *
 * Numbers arrive parsed (`NaN` when the attribute was not one) so the validator can name what
 * was written rather than a default standing in for it.
 */
export type StateDefine = {
  type: "state_define";
  entityId: string;
  /**
   * The item on that card to put it inside, or `""` for the card itself.
   *
   * A state's id is unique across a whole card, so this is only ever needed when the state is
   * *made*: everything after that addresses it by id wherever it sits.
   */
  in: string;
  /** The state's id. Its label, when the tag gives one, and a slug of it otherwise. */
  state: string;
  label: string;
  /** A `STATE_PRESETS` id, as written; the validator names the list. */
  preset: string;
  min: number | undefined;
  max: number | undefined;
  unit: string;
  emoji: string;
  /**
   * What it holds the moment it is made, as written — `""` leaves the preset's own start.
   *
   * A string, because a state's value is a number, a flag, a sentence or a list depending on
   * its kind, and the one place that knows which is the apply.
   */
  start: string;
  /** `undefined` when the tag said nothing, so the preset's own answer stands. */
  hud: boolean | undefined;
  menu: boolean | undefined;
  playerEditable: boolean | undefined;
  action: "add" | "remove";
};

export type StateDelta = {
  type: "state_delta";
  entityId: string;
  state: string;
  delta: number;
  evidence: string;
};

/**
 * **What a state can be** — and a *thing* is one of them.
 *
 * There is no separate item any more, and deleting that distinction is the whole of this
 * change. A card held `states` **and** `items`, so "how much water is in the flask" and "is the
 * flask cracked" were two different kinds of fact stored in two different lists, edited in two
 * different panels, moved by two different tags and refused by two different validators — for
 * no reason anybody could state. The reader's words: *"there shouldn't be state and item.
 * theres only states."*
 *
 * An `item` is a state whose **value is how many you have**, and whose `states` are what it is
 * made of. So a revolver is an item holding a condition (a number), a safety (a boolean) and
 * six bullets (an item) — three facts of three kinds, in one list, each drawn by the control
 * its own kind needs.
 */
export type StateKind = "number" | "boolean" | "text" | "list" | "item";

export type StateOrchestrationEvent =
  | WorldAdd
  | CharacterAdd
  | StateUpdate
  | ArcAdd
  | ArcUpdate
  | MemoryAdd
  | MemoryUpdate
  | MemoryNodeEvent
  | SummaryProposal
  | AgentAdd
  | AgentUpdate
  | AgentRemove
  | NotebookSet
  | StateDefine
  | StateDelta
  | StateTransfer
  | LinkCards
  | BoostCard
  | ReplaceEvent
  | RegisteredEvent;

/**
 * **Something held, handed from one card to another** — with what is inside it.
 *
 * The one tag `<state_delta>` cannot do, because it moves a number on *one* card and this
 * takes a state off one and puts it on another. `<item_delta>` is gone with the item: gaining
 * is `<state_define preset="item" start="3">`, spending is `<state_delta delta="-1">`, and
 * wearing something down is a delta on the condition nested inside it. Three verbs for
 * everything, rather than three for facts and three more for objects.
 */
export type StateTransfer = {
  type: "state_transfer";
  /** Either may be a character or a world — a chest is a card like anybody else. */
  from: string;
  to: string;
  state: string;
  qty: number | "all";
  /** Which item it lands inside on the far side, or `""` for simply held. */
  in: string;
  evidence: string;
};

export type StateUpdate = {
  type: "state_update";
  entityType: "character" | "world";
  entityId: string;
  targetKey: string;
  action: StateAction;
  value: string;
};

/** How a provider takes stop strings: the field is `stop` on the OpenAI shape, renamed by its dialect. */
export type StopWire = {
  /** The most it documents in one request; absent where it documents no count. */
  max?: number;
  /** A model family that refuses them outright. */
  refusedBy?: { match: RegExp; why: string };
  /** Where the row's facts came from. */
  why: string;
};

/**
 * **A store's answer, said whenever the store moves.** Every state change is compared, so a streamed
 * chunk, which moves the store every 400 ms and the answer never, says nothing.
 *
 * Takes the store rather than importing one, so it imports neither and both can import it.
 */
export type Store<S> = { getState(): S; subscribe(listener: (state: S, previous: S) => void): () => void };

export type StoryArc = {
  id: string;
  /**
   * Guideline, spine, or thread. `"style"` is what a guideline is stored as — the labels
   * are in `lib/story/arc-kinds.ts` and nothing spells them anywhere else.
   */
  type: "style" | "major" | "minor";
  title: string;
  content: string;
  isSpoiler: boolean;
  isNew?: boolean;
  status?: "ongoing" | "closed";
  /**
   * **Whether this arc is in the prompt.** Absent is in, which is what every arc written
   * before the switch existed is — carried, not defaulted, so no stored chat moves a byte.
   *
   * A character or a world says this with a roster on the chat (`characterIds`, `worldIds`),
   * because their cards are shared with a global shelf and a chat's array legitimately holds
   * cards that are not in the cast — `deleteCharacter` prunes the roster, and the Director's
   * `Active` state key writes it. An arc has none of that: `chat.storyArcs` *is* the arcs in
   * this story, and a parallel list of ids would be a second description of the same set,
   * which is the one shape this codebase keeps paying for. So the switch is on the card.
   *
   * Not `status`, which is beside it and means something else. A closed arc is still sent —
   * `buildStoryArcsMarkdown` labels it `[Status: Closed]` on purpose, because "this thread is
   * finished" is a thing the story needs to know. This is "do not send it at all".
   */
  enabled?: boolean;
  /**
   * The arc this one sits under — a subplot of a spine, a thread of a subplot. **Absent is
   * top level**, carried rather than defaulted like every other arc field, so no stored chat
   * moves a byte. Same kind as its parent, always: the tree lives inside a kind's tab.
   *
   * There is deliberately **no `order` for the tree.** The array is the order — children
   * follow their parent in it, in array order — and `order` below means the shelf, as it
   * always has. A position kept as a sequence *and* as a number is two facts, and this repo
   * has paid for that pair before (CLAUDE.md, the prompt block's `order`).
   *
   * `lib/story/arc-tree.ts` is the one reader: it flattens depth-first with a cycle guard —
   * a chain that never reaches the top is drawn at the top rather than not at all — and
   * `resolveArcTarget` answers which arc a `parent="…"` attribute names.
   */
  parentId?: string;
  /**
   * Both carried, not defaulted. `updatedAt` is the shelf's alone; `folderId` is a shelf folder
   * there and one of `Chat.arcFolders` in a chat — the reader's filing, which no prompt reads (an
   * arc under an arc is `parentId`, which the prompt does read).
   *
   * An arc that has only ever lived inside a chat is stamped by the chat around it and
   * filed nowhere, so it stores neither key and every existing chat serialises
   * byte-identically. See `Character.updatedAt` and `Character.folderId`.
   */
  updatedAt?: number;
  folderId?: string;
  /** Where in that folder the reader put it. See `order` on `Character`. */
  order?: number;
  /** A shelf card's: the chat arc it was saved from — see `ShelfOrigin`. */
  savedFrom?: ShelfOrigin;
};

/**
 * **Where the Writer's tool cards go, and whether they are drawn at all.**
 *
 * One answer with three values rather than a switch and a placement, because the two
 * questions are not independent: "after the reply" and "in the story where it happened" are
 * both *drawn*, and "not at all" makes the placement decide nothing. A reader who does not
 * want a diff card interrupting a scene has two ways to say so and one control to say it in.
 *
 * The table is here so the picker and the reader cannot describe different things, and
 * because the reveal asks it too — cards that are not drawn are not paced for, which is the
 * whole of "if the tool card is hidden we mustn't wait for the typing animation".
 */
export type StoryToolCardPlacement = "inline" | "end" | "off";

export type StreamBoxView = (typeof STREAM_BOX_VIEWS)[number];

/**
 * A mistake the text already proves — see the header. `at` is how much of it to keep.
 * `json` is a closed fence that could not be used: not JSON, or naming no tool.
 */
export type StreamProblem = { why: "unknown" | "json" | "stranger"; at: number; tag: string };

/**
 * An amount of story in each unit. Two numbers because they are two quantities — 6 messages and
 * 2,000 tokens are not one number in two spellings, and switching units must not leave a box
 * asking for six tokens of story. Only the policy's `countUnit` is read.
 */
export type SummaryAmount = { messages: number; tokens: number };

/**
 * What the batch and the kept window are counted in: messages, or the tokens they weigh.
 *
 * A message count is blind to how long a message is, and the window is not — six lines of
 * dialogue and six pages of prose are the same six. `SUMMARY_COUNT_UNITS` holds the bounds and
 * the wording for each.
 */
export type SummaryCountUnit = "messages" | "tokens";

/**
 * How the blocks already written are kept as the story grows.
 *
 *  - `layers` — Summaryception's shape (`.agents/SUMMARY-LAYERS.md`). Blocks pile up on layer 0;
 *    when a layer holds more than `layers.size`, its oldest `layers.merge` are rewritten as one
 *    block on the layer above, and so on up to `layers.depth` layers. The top layer only grows.
 *    One layer is "never rewrite the blocks".
 *  - `rolling` — one budget for the bank and the raw turns: every run rewrites the bank and the
 *    new story as one block. Early detail thins with each pass.
 */
export type SummaryFold = "layers" | "rolling";

/** The layers' shape, read under `fold: "layers"`. */
export type SummaryLayers = {
  /** Blocks a layer holds before its oldest are merged up. */
  size: number;
  /** Blocks merged into one at a time. At least two. */
  merge: number;
  /** How many layers there are. One means blocks are never merged. */
  depth: number;
};

/**
 * A fixed amount of summary context, in blocks or tokens.
 */
export type SummaryLimitSize = { unit: "blocks" | "tokens"; amount: number };

export type SummaryPolicy = {
  /** When a run happens. */
  trigger: SummaryTrigger;
  /** What `batch` and `keep` are counted in. */
  countUnit: SummaryCountUnit;
  /**
   * How much story one summary covers — and, under a trigger that counts, how much must have
   * passed the kept window before one is written. One number, as Summaryception's "turns per
   * batch" is: it was two (a cadence on the pass row, and a cap on the range here), so "every
   * six messages" and "six messages at a time" could disagree, and the cadence lived on a row
   * whose schedule this policy owns.
   */
  batch: SummaryAmount;
  /** The newest story no scheduled run summarizes — Summaryception's verbatim turns. */
  keep: SummaryAmount;
  /** How the blocks already written are kept. */
  fold: SummaryFold;
  /** The layers' shape, under `fold: "layers"`. */
  layers: SummaryLayers;
  /**
   * Put the summaries already written in front of the model when it writes the next one — the
   * story so far, for a batch; the layers above, for a merge (Summaryception's prior context).
   *
   * Not the same question as folding: `materialFor` already replaces spans *inside* the range
   * with their compressions, because what a range contains is a fact about the range. This is
   * about everything *before* it.
   */
  includePriorSummaries: boolean;
  /** Which lenses the scheduler produces. The spine is always among them. */
  kinds: string[];
};

/**
 * Tags carry a proposal's *content*. Whether it has been approved lives on its
 * ProposalBundle and nowhere else — there is no `approved="…"` attribute to parse.
 */
export type SummaryProposal = {
  type: "summary_proposal";
  start: number;
  end: number;
};

/**
 * When a summary is written: once enough story has piled up past the kept window, when the raw
 * turns fill their space, or either. `SUMMARY_TRIGGERS` says which of the two each id watches.
 */
export type SummaryTrigger = "cadence" | "cadence_or_pressure" | "pressure";

/**
 * How much of the bank rides along with a summary. It held how long a summary was asked to be —
 * sentences per turn, and a ceiling — until round 2026-10-07B took the length out of the prompt.
 */
export type SummaryTuning = {
  /** How much of the summariser's own window the summaries before the span may fill, as a fraction. */
  priorShare: number;
};

export type SurfaceProps = React.HTMLAttributes<HTMLDivElement> & {
  elevation?: Elevation;
  radius?: keyof typeof RADII;
  padding?: keyof typeof PADDING;
  /**
   * Draw a hairline. Only for a surface meeting one of the *same* shade — a border on a card
   * that already differs in fill is the nested-box look the overhaul is removing.
   */
  bordered?: boolean;
};

export type SyncCollection = (typeof SYNC_COLLECTIONS)[keyof typeof SYNC_COLLECTIONS];

/**
 * **How the models write a tool call — the two renderings of one table.**
 *
 * `.agents/DIRECTOR.md` §2.2 set the rule: one tool table, two renderings. The XML tags are how
 * this shipped; a fenced JSON block is the second (`.agents/TOOLS.md` §2.2). Neither is native
 * function calling — OpenRouter answers 404 for models with no tool endpoint, and the Anthropic
 * dialect whitelists body fields — so both are text the model writes and the app reads, and the
 * format decides exactly four things: how a tool is described, how a call is read, how a call is
 * quoted back, and how the stream is scanned. The grant, the kind table, the validators and the
 * cards never see it: a call is a `ToolCall` by the time anything downstream runs.
 */
export declare const TOOL_FORMATS: readonly ["xml", "json"];

/**
 * **The table's clock**, keyed like the window: `of` names whose turn it is timing, so a clock from
 * a turn that has moved on counts nothing down.
 */
export type TableClock = { of: string; deadline: number };

/** The table's Next turn as a screen draws it — flat, so a shallow comparison holds. */
export type TableNextTurn = {
  /** The table is stopped between two voices, and a Next turn stands on every screen. */
  open: boolean;
  /** The Next turn at this place in the story was pressed and the turn is starting. */
  starting: boolean;
  counted: boolean;
  pressed: number;
  total: number;
  mine: boolean;
};

export interface TablePort {
  /** Something any answer below reads has moved. */
  subscribe(listener: () => void): () => void;

  /** The table playing `chatId`, seated and in session — or null. */
  view(chatId: string | null | undefined): TableView | null;
  /** The story a table is bound to on this tab, from the moment it is chosen until it ends. */
  boundChatId(): string | null;

  /**
   * **A chat this tab holds for another library** — a guest's view of the host's story. It is
   * never persisted (the storage funnels ask this), never run, and never paid for here.
   */
  foreign(chatId: string | null | undefined): boolean;
  /** The view itself, for `setActiveChatId`'s first look. */
  foreignChat(chatId: string): Chat | undefined;
  /** Keep the latest in-memory copy of a view after a write the funnel refused to persist. */
  keep(chat: Chat): void;

  /** True on a chat this tab holds; on a foreign one, whether the host granted it. */
  may(chatId: string | null | undefined, right: TableRight): boolean;
  /** The rows that cover `action` on `message`, for this seat — true on a chat this tab holds. */
  mayActOnMessage(chatId: string, action: MessageAction, message: Pick<Message, "speakerCharacterId">): boolean;

  /** The host switched the AI off for the table playing this chat. */
  blocksAI(chatId: string): boolean;

  /** Where a press on `chatId` goes instead of being carried out here — null when this tab holds it. */
  forward(chatId: string | null | undefined): PressDoor | null;

  /** The floor at the table playing this chat — the rules in force and whose turn it is. */
  floor(chatId: string): { rules: TurnRules; view: FloorView } | null;
  /** May this tab's player speak now, and if not, who has the floor. */
  micGate(chatId: string): { locked: boolean; holderName: string | null };
  /** Done writing in the window (an empty send), with the call it carried. */
  pressReady(calling?: string | null): void;
  /** A line this seat wrote went into the window, with the call it carried. */
  windowLine(calling: string | null): void;
  closeWindow(): void;
  moveTurnTo(seat: Seat): void;

  /** The Continue this screen answers at the table, given its own hold — null when none. */
  gateProgress(activeChatId: string | null, gate: RevealState["gate"]): ContinueGateProgress | null;
  /** The table's Next turn, or null where the screen decides for itself. */
  nextTurn(activeChatId: string | null, lastMessageId: string | null): TableNextTurn | null;
  pressNextTurn(): void;

  /** The table's reading of `chatId`, as this tab last knew it — or null. */
  reading(chatId: string | null | undefined): PublishedReveal | null;
  /** `chatId` is a table's chat whose reading this tab knows, so the reader is the table's. */
  readsAt(chatId: string): boolean;
  /** The table's reading moved. */
  onReading(listener: () => void): () => void;

  /** This person renamed themselves: a table they sit at hears the new name. */
  announceName(): void;
}

/**
 * **The rights a seat asks before it offers a control.** The host grants or withholds each; a tab
 * holding its own chat has every one. The plugin's permission rows are the source, and its port
 * checks at compile time that every name here is one of them.
 */
export type TableRight =
  | "writeNotes"
  | "stopReplies"
  | "editLibrary"
  | "approveProposals"
  | (typeof LINE_RIGHTS)[number];

/** One person at the table, as the room names them. */
export type TableSeat = { id: string; name: string; isHost: boolean };

/**
 * **The table playing a chat, as this tab sits at it** — or the port answers null.
 *
 * `players` and `claims` are what the turn walk seats (`lib/mic/table.ts`); `selfId` and `isHost`
 * are this tab's chair; the rest is the floor's live state, which the strip and the composer draw.
 */
export type TableView = {
  chatId: string;
  players: readonly TableSeat[];
  claims: Record<string, string>;
  /** This tab's account at the table, once the room has seated it. */
  selfId: string | null;
  isHost: boolean;
  window: WindowTally | null;
  clock: TableClock | null;
  typing: Record<string, TypingEntry>;
};

/**
 * **A tag, where it was written, and the text of it.**
 *
 * The parsers each already worked this out — they collected `{ index, … }` and sorted by it
 * — and each then threw the position away and returned a bare list. So anything that needed
 * to know what order a reply did things in had to *re-derive* it by scanning the raw text with
 * its own regexes, which is the shape CLAUDE.md names twice: a display that works out what the
 * app did instead of being told. The trace pane did exactly that, and re-matching cannot
 * agree with the parse it is imitating.
 *
 * `raw` is the tag exactly as the model wrote it, which is the one thing a run log wants and
 * the only thing the parsed object cannot reconstruct. `name` is the tag name as written —
 * `define_pass` when that is what the model typed — because every sentence back to the model
 * quotes the tag it wrote and not the event type behind it: a broken `<highlight>` reported as
 * `<highlight_add>` told the model to fix a tag that does not exist.
 */
export type TagSpan<T> = { index: number; raw: string; name: string; value: T };

/**
 * Which take a message is showing and how it got there — **one answer for every bubble drawn
 * from that message.**
 *
 * A reply in a pseudo message is several bubbles, and each one used to work this out from a ref of
 * its own: what position *it* was last drawn at. A bubble that was not there for the previous
 * take has no such memory, so it took the entrance animation — which comes in from the left —
 * while its siblings swiped in from the right. "During swipes, in pseudo chunks, the animation
 * for the character bubbles and narrator prose goes in the opposite direction." Which bubbles
 * went which way depended on how the two takes happened to split into lines.
 *
 * So the arrival belongs to the *message*, and the transcript keeps it (`ChatMessageList`) and
 * hands the same one to every row. `null` means nobody has swiped: a bubble that has just
 * mounted, from a chat being opened or a reply landing, arrived by being new.
 */
export type TakeArrival = {
  position: number;
  /** How many takes there were when this arrival was decided — see `takeArrival`. */
  count: number;
  dir: "next" | "prev" | null;
  /**
   * How many times the reader has moved between this turn’s takes.
   *
   * The bubble is keyed on it, so it remounts — and replays its arrival animation — exactly
   * when one of those moves happens, and at no other time. It used to be keyed on `position`,
   * which is not the same fact: see below.
   */
  moves: number;
};

/**
 * **The work done on one take's words** — the cards its own tags made, the after-reply agents'
 * cards, and what they applied (the Writer's tracker, the Fact Writer's memories, the State
 * Manager's changes, the Director's review), and the summaries that reach the take. Held by the take while another is shown, so swiping back
 * finds it again rather than paying to read the same words twice, and so another take's work is
 * never in force under this take's words (`lib/chat/take-work.ts`).
 *
 * The cards and bundles as they stood. Their effects are not stored: an approved bundle is applied
 * again when the take comes back — the same apply the reader's Approve runs, against the chat as
 * it stands then, so what can no longer apply says so on its card rather than landing over
 * something else.
 */
export type TakeWork = {
  /**
   * The message the work was anchored on when it was parked. A retry gives the take a message of
   * its own, so the ids are moved to the message it comes back on.
   */
  on: string;
  bundles: ProposalBundle[];
  cards: DirectorMessage[];
  /** Notes the cards filed that no action files again. */
  notes: HiddenInjection[];
  /**
   * The memories its actions wrote, as they stood when it was parked — filed where they were filed —
   * so applying the action again does not ask the Classification model to file them again.
   */
  memories: { action: string; memory: Memory }[];
  /** Actions whose memory the reader had made their own, which stayed: not applied twice. */
  stayed: string[];
  /** The summary blocks that reach this take — written from its words. */
  summaries: ChatSummary[];
};

/** The marked text a reader can style: quoted speech, `*single*` and `**double**` asterisks. */
export type TextMark = "dialogue" | "italic" | "bold";

/** How one kind of marked text is drawn. `"inherit"` is the bubble's own colour. */
export interface TextMarkStyle {
  colour: "inherit" | `#${string}`;
  bold: boolean;
  italic: boolean;
}

export type ToolArg = {
  /** The one spelling the model is told. */
  name: string;
  /**
   * Other spellings the parser reads. Never documented, never rendered — they exist because
   * the writer is a language model, and a model that shortens `modelTier` to `tier` has still
   * named a price. An alias may not be another arg's name on the same tool; the test says so.
   */
  aliases?: readonly string[];
  type: ToolArgType;
  /** For `enum`: the values, lower-case. */
  values?: readonly string[];
  required?: boolean;
  /**
   * What the tag means when it leaves this out — written once, here, because two readers need
   * it: the signature line says it to the model, and `build` takes it. `<state_update>` had
   * them apart, the paragraph saying the value is the whole new field and the parser reading a
   * missing action as "add", so a mood set to "calm" came out "wary\ncalm". Only for an
   * attribute whose absence *is* an answer; one whose absence means "leave it alone" has none.
   */
  default?: string;
  /**
   * One clause. This is what the signature line will render. A function for a clause that states a
   * number this chat sets (Settings → Advanced), asked with the chat's groups (`argDoc`).
   */
  doc: string | ((tuned: TuningGroups) => string);
  /**
   * **What the value names in the chat**, when it names something there: a card (a character or a
   * world), a character, a story arc, or an agent. Said here, on the row, because the attribute's
   * name cannot say it — `name` is a card to read on `<read_card>` and a new person's name on
   * `<character_add>`, `agent` an agent on `<call_agent>`. The `<` list in a prompt box offers the
   * chat's names for it (`lib/prompts/tool-suggest.ts`).
   */
  refers?: "card" | "character" | "arc" | "agent" | "callable agent";
};

export type ToolArgType = "string" | "number" | "boolean" | "enum" | "list";

export type ToolBody = {
  /** What the body *is* — the same word the JSON form uses as its key. */
  field: string;
  doc: string;
  required: boolean;
  /**
   * Other arguments that say what the body would, any one of which makes the tag whole at its
   * bracket (`wholeAtBracket`): `<read arc="…">` has said all a `<read>` asks, as `<read card="…">` has.
   */
  or?: readonly string[];
};

/**
 * A call as the model wrote it, after the grammar has read it and before anything has judged
 * it. `args` are keyed by their canonical names — an alias has already been folded — and
 * carry every attribute written, known or not, so a builder can still see a spelling the
 * spec does not list. `wrote` is the tag name as written (`define_pass`, not
 * `spawn_standing_subagent`), which is what every message back to the model quotes.
 */
export type ToolCall = {
  name: string;
  wrote: string;
  args: Record<string, string>;
  body: string | undefined;
  index: number;
  raw: string;
  /**
   * **The synonyms the reading folded, when it folded any** — the tag name and the arguments written
   * as an alias, each with what it was read as. Absent for a call written as taught. The Director's
   * next observation says them back (`aliasesReadLine`), so a model that wrote a synonym learns the
   * taught spelling instead of the alias table carrying it for good (TOOL-DESIGN.md §2.7).
   */
  aliased?: AliasesRead;
  /**
   * **The attributes it wrote that its tool does not take**, as written — absent when there are none.
   * Such a call is read whole and acted on by nothing (`ToolScan.refused`), and the model is told
   * which attribute it was. Passed through and ignored, `<link_cards action="unlink">` (the old
   * form of an unlink) built a *link*, the opposite of what the model meant, and nobody said so.
   */
  strangers?: readonly string[];
  /**
   * **The values it gave an enum attribute that the attribute does not list**, as written — absent when
   * there are none. Refused as a stranger is (`isRefused`): read as the default, `<state_set mode="add">`
   * — the word before the modes — wrote over the list it meant to add to.
   */
  offValues?: readonly { arg: string; wrote: string }[];
};

export type ToolFormat = (typeof TOOL_FORMATS)[number];

export type ToolKind = "query" | "proposal" | "control";

export type ToolLoadingState =
  | 'idle'
  | 'connecting'
  | 'analyzing'
  | 'success'
  | 'error'
  | 'cancelled';

/** How far an agent's tool calls may go in one run or one reply, and how a failure is met. */
export type ToolLoopTuning = {
  /**
   * What one run may write, every step counted, in output tokens — `null` for each agent's own
   * response length. Read by `resolveAgent`, the one place that knows the agent's reply length.
   */
  runTokens: number | null;
  /** The most steps one run may take, whatever is left of `runTokens`. */
  maxSteps: number;
  /** How many times one mistaken call is said back before the run is taken to repeat itself. */
  repeatedMistakes: number;
  /** Rolls and lookups a story agent's reply may stop for and be answered. */
  asksPerReply: number;
  /** `<call_agent>`s one run may make, across its steps. */
  callsPerRun: number;
  /** How long a chain of calls may grow: A calls B calls C, and C calls no one. */
  callDepth: number;
  /** `<task>`s one run may send, across its steps (TOOL-DESIGN.md §4.2). */
  tasksPerRun: number;
  /** The most steps one task's own run may take. */
  taskSteps: number;
  /** The most one step of a task may write, in output tokens — its request's response length, under the agent's own. */
  taskStepTokens: number;
  /** How many times a tool pass is asked again after a failure the provider could recover from. */
  retries: number;
  /** The pause before each of those, in milliseconds. */
  retryPauseMs: number;
};

/**
 * A tool tag in a reply that became nothing, and why.
 *
 * The Writer's tools are drawn in the story, so a tag of the Writer's that was refused
 * (`RefusedEvent`) or could not be read (`UnreadTag`) is recorded on the message it was written
 * in and drawn as a card in its error tone where the tag sat — a console line was where these
 * went before, and a reader who ticked a grant and saw nothing happen had nowhere to look.
 * `atOffset` is the tag's index into the message's `raw`, as `ProposalAction.atOffset` is.
 */
export type ToolProblem = {
  name: string;
  atOffset: number;
  reason: "refused" | "malformed";
  /** One sentence, addressed to the reader. */
  detail: string;
};

export interface ToolPrompt {
  id: string;          // e.g., "call_character", "world_add"
  description: string; // The prompt text explaining what the tool does and its XML format
}

export type ToolScan = {
  /** In the order written, both forms together — the whole reading, as `scanCalls` gives it. */
  complete: ScannedCall[];
  /**
   * **Calls read whole that nothing may act on**: each wrote an attribute (or a key) its tool does
   * not take, or a value its enum does not list (`isRefused`). Read, so a tag in one's body is still that call's text and the
   * stream does not wait for it to close; never in `complete`, so no reader builds it; reported by
   * `unreadTags`, which names the attribute.
   */
  refused: ScannedCall[];
  /**
   * `complete` short of the call still being written — **what a reader of the live stream acts
   * on**: the cut, the story's live cards, a live step's timeline. Everything from `partial`'s
   * opener on is that call's body until it closes, and a `<roll/>` quoted in an open `<call_agent>`
   * brief was thrown, answered and drawn as a card of its own — and then, once the brief closed,
   * read whole as the brief's text. Equal to `complete` when nothing is open.
   */
  beforeOpen: ScannedCall[];
  /** At most one: the outermost tool still open at the end of the text, or an unfinished opener. */
  partial: PartialCall | null;
  /** The first mistake, or none. When there is one, `partial` is not asked. */
  problem: StreamProblem | null;
  /** Every closed fence that held nothing usable, for the end-of-step reader to report. */
  jsonProblems: JsonProblem[];
};

export type ToolSpec = {
  name: string;
  /**
   * Other names a model writes for this tool unprompted (`<remember>` for `<memory_add>`) — never an
   * old name of this app's: a renamed tag is moved in what is stored by a one-off script
   * (`scripts/one-off/`) and read no more. `namesOf` is the spellings the grammar matches.
   */
  aliases?: readonly string[];
  /**
   * The permission key — the one name that is also the key into `DEFAULT_TOOL_PROMPTS`,
   * `toolPermissions`, `DEFAULT_TOOLS_BY_MODE` and `STATE_EVENT_KINDS[…].permission`.
   */
  permission: string;
  kind: ToolKind;
  /**
   * **For a query: who answers it, and so what asking costs** (TOOL-DESIGN.md §2.5). `app` is the
   * app itself, from what the story holds or with its own dice — free; `model` is one request to
   * another model (the Vision agent, the Image Writer); `agent` is an agent's whole run, its
   * requests now; `web` leaves this app. Every query says, and nothing else does (`tool-specs.test`),
   * so a paid query cannot be stamped free by leaving it out. The signature's stamp reads it.
   */
  answeredBy?: QueryAnswerer;
  args: readonly ToolArg[];
  body?: ToolBody;
  /**
   * **The add this tool edits**, for an `_update` derived from its `_add` (TOOL-DESIGN.md §2.1):
   * its args are `target`, then every arg of the add made optional, then what only an edit says
   * (`editOf`). The two signatures re-stated eight fields by hand and had to agree; now the edit's
   * signature is one line — `[any field of agent_add]` — and a field added to the add is one an
   * update takes, with nothing to remember.
   */
  edits?: string;
  /** For an edit: the argument that names what it edits — the first of its args. */
  target?: ToolArg;
  /**
   * For a query that builds more than one kind — `<read>` builds `read_card`, `read_links`,
   * `read_arc` and, for an address, `read` — every kind it builds; otherwise its own name is the
   * one (`QUERY_KINDS`). Each kind finds the tool back by `specOfKind`.
   */
  builds?: readonly string[];
  /**
   * The call as an object, or `null` when the call asks for nothing at all — an empty
   * `<read_card/>`, a `<call_character>` naming nobody. `null` is dropped and reported as
   * unreadable; a *usable* object that is wrong is the validators' business, not this one's.
   */
  build: (call: ToolCall) => ParsedTool | null;
};

/** Where one use of a tool has got to — see `lib/director/timeline.ts`. */
export type ToolUseStatus = "streaming" | "called" | "returned" | "failed" | "refused";

/** Which context markers the transcript draws — see `TRANSCRIPT_MARKER_MODES`. */
export type TranscriptMarkers = "both" | "frontier" | "range" | "none";

export type TranscriptTuning = {
  /**
   * The longest a person's line may be and still stack under the line they sent before it, in
   * characters — `lineRunsFor` reads it. Past it a line stands on its own, under its own name.
   */
  standsAlone: number;
};

export type TuningGroup = keyof TuningGroups;

/** Every group on the screen, by the `ChatSettings` key it is stored under. */
export type TuningGroups = {
  contextWindow: ContextWindowTuning;
  toolLoop: ToolLoopTuning;
  lookupLimits: LookupTuning;
  webPages: WebPageTuning;
  summaryLimits: SummaryTuning;
  directorLimits: DirectorTuning;
  notebookLimits: NotebookLimits;
  composer: ComposerTuning;
  playerLines: PlayerLineTuning;
  editors: EditorTuning;
  transcript: TranscriptTuning;
  runLog: RunLogTuning;
  memoryLimits: MemoryLimits;
};

/**
 * **One card in the turn loop, as the reader arranged it** — stored on the chat
 * (`ChatSettings.turnLoop`).
 *
 * `id` is a character id or the narrator's. `key` is the entry's own name, because a character may
 * stand in the loop twice and the two places have to be told apart — by the editor that drags
 * them, and by the transcript, which stamps the entry a turn was taken for (`Message.roundEntry`).
 * `out` keeps a card the reader took out of the round: known, in the chat, callable, and never
 * appended back at the end the way a card the loop has never heard of is.
 */
export type TurnCard = { key: string; id: string; out?: true };

/**
 * A position in the transcript, and what it means to cut there.
 *
 * The reveal animation used to track its progress as `revealedCount` — an index into an
 * array only `ChatMessageList` could see. That is why interrupting it needed an event
 * round trip: the component that knew where the reveal had got to was not the one that
 * could act on it, so `INTERRUPT_TYPING_REQUESTED` shipped the decision back across the
 * bus and rebuilt the messages by hand at the far end, three times over, bypassing
 * `pruneDraftToLength` and its state rollback entirely.
 *
 * A cursor is a *chat* coordinate. Anything holding the chat can act on it, and a cursor
 * pointing past a turn that has since been deleted simply admits everything that is left
 * — it clamps instead of dangling.
 */
export type TurnCursor = {
  messageIndex: number;
  /** Which chunk within the message, or null when the message is one whole bubble. */
  chunkIndex: number | null;
};

/**
 * The rules in force, composed — **never stored in this shape** (`lib/mic/rules.ts` builds it).
 *
 * `order`, `nextVoice` and `batch` are *in force*, not as stored: a question that is not drawn
 * never gates anything. A round in a chat with one voice and nobody else at the table alternates
 * the reader and the voice exactly as a free-for-all does, so it is one — and the call card it
 * would otherwise take away stays, which is the bug a rigid order in a narrator chat shipped.
 */
export type TurnRules = {
  order: SpeakingOrder;
  nextVoice: NextVoice;
  roundCalls: RoundCalls;
  betweenVoices: BetweenVoices;
  /** Whether the players' turns are one window — a table only. */
  batch: boolean;
  batchCloses: BatchCloses;
  batchLineCap: number | null;
  playerTurnSeconds: number | null;

  /** Derived: the AI voices with a turn of their own, in cast order. */
  voices: Seat[];
  /**
   * Derived: the loop a round walks, entry by entry — voices and people, or `TABLE_SEAT` for a
   * batched table. **A seat may stand in it more than once**, which is why the walk steps over
   * entries and not seats. Empty under a free-for-all.
   */
  round: RoundEntry[];
};

/** Where somebody's fingers are: the story's composer, or the table talk. */
export type TypingAt = "story" | "ooc";

/** What a receiver holds about one person's fingers, until a stop or the TTL clears it. */
export type TypingEntry = { at: TypingAt; until: number; preview?: string };

export interface UIState {
  leftSidebarOpen: boolean;
  rightSidebarOpen: boolean;
  /** The Director pane's width. The Inspector has its own below: one number resized both,
      which is why dragging the Director's edge used to move the pane on the other side. */
  sidebarWidth: number;
  inspectorWidth: number;
  settingsModalOpen: boolean;
  /**
   * Which settings section the dialog should open on, when a door elsewhere wants a
   * specific one — the memory hub's "edit the summary prompt" lands on Prompt Master.
   * Consumed once by `SharedSettingsForm`; null means "wherever it was".
   */
  settingsInitialSection: string | null;
  /**
   * Which agent Prompt Master (or Context master) should open on, when a door elsewhere means
   * one — the pencil on an agent's card in Pipeline & Agents, the retrieval hub's "Open Context
   * master". Consumed once by whichever of `PromptMasterPanel` and `ContextMasterPanel` opens; null means
   * "whichever it was". The same shape as `settingsInitialSection`, and it rides beside it.
   */
  settingsInitialAgent: string | null;
  /**
   * The section the dialog was on when it closed — reopening lands there. Ten screens is
   * too many to re-navigate for the third tweak to the same slider; a door's
   * `settingsInitialSection` still wins when one asks.
   */
  settingsLastSection: string | null;
  /** Internal selections of modals per chat (e.g. active tab/lens/view), keyed by `${chatId}:${selectionKey}`. */
  modalSelections: Record<string, string>;

  storyModalOpen: boolean;
  worldModalOpen: boolean;
  charactersModalOpen: boolean;
  /**
   * What the player has set up and not yet sent.
   *
   * UI state, because it is a **draft**: nothing has happened until they send, which is what
   * makes taking one off free and what anchors the whole queue to the message it belongs to.
   * Applied and cleared by `handleSend`; a failed send leaves it armed, because the actions
   * did not happen either.
   */
  armedActions: ArmedAction[];
  /**
   * The pictures waiting beside the draft, for the same reason `armedActions` is here: nothing
   * has happened until the send, and the send is what makes them the message's. Cleared where
   * `input` is cleared, and not before — a refused send keeps them.
   */
  attachments: MessageImage[];
  /** The documents waiting beside the draft, as their text — the pictures' twin (`lib/files/read.ts`). */
  attachedFiles: MessageFile[];
  /** The standalone retrieval inspector, promoted out of the Debug pane's cramped tab. */
  ragViewerOpen: boolean;
  /** The summary tree, promoted out of the memory bank's "Turn Summaries" category. */
  summaryTreeOpen: boolean;
  /**
   * **The Memory hub** — the memory canvas, its own quick access since round 2026-10-08D (*"What holds
   * the summary is now summary. memory is now memory."*). The same screen as the summaries'
   * (`SummaryTreeModal`), opened on the Memory side alone.
   */
  memoryModalOpen: boolean;
  /**
   * Which lens the hub should open on, when a door elsewhere means a particular memory —
   * the Director's ring lands on the Director's handovers rather than on the story canvas.
   * Consumed once by `SummaryTreeModal`; null means "wherever it was". The same shape as
   * `settingsInitialSection`, and for the same reason: the door knows which memory it meant,
   * and the screen should not have to infer it from what opened it.
   */
  summaryTreeInitialLens: string | null;
  /**
   * The context viewer, promoted out of the Debug pane's "Token allocation" tab.
   *
   * Six token gauges in a 320px sidebar, where the legend wrapped to two columns of 10px
   * type — and the only tab in that pane that built every agent's prompt at once, on every
   * chat mutation, for a view nobody could read.
   */
  contextModalOpen: boolean;
  /**
   * The shelves, from inside a chat.
   *
   * Beside retrieval and the summary rather than in the entity row: those three open *this
   * chat's* characters, worlds and arcs, and this one opens what you have saved outside every
   * chat. Putting it next to "Characters" would make it look like a fifth view of the same
   * roster.
   */
  globalFilesModalOpen: boolean;
  /**
   * What a fork is being named for — the cut, not a boolean beside one.
   *
   * A `forkModalOpen` flag plus a `forkFromTurnId` is two states that have to agree about
   * whether a fork is being made, and they would disagree the first time a turn was deleted
   * out from under an open dialog. One state cannot; `null` is closed. A cut rather than a turn
   * id, because a Director message forks too (`ChatCut`), into the same dialog.
   */
  forking: ChatCut | null;
  /**
   * What a prune is asking about — the same shape as `forking`, for the same reason, and in the
   * store rather than in the transcript because the Director pane opens it too: one dialog,
   * mounted by the transcript, which holds the bubbles it draws.
   */
  pruning: ChatCut | null;
  /**
   * The card — or the lorebook — a link is walking to, so whichever manager opens lands on it.
   *
   * A card can be linked to a card of the other kind, and the two managers are two modals: a
   * glyph on a character's state that names a world has to close one and open the other *and*
   * say which world. One field rather than a per-manager "open at" prop, because the walk is
   * one gesture and the manager that answers it is decided by the card, not by the caller. A
   * lorebook a character owns is walked to the same way, and lands on its page in the world
   * manager; the kind says which list to look in, since a lorebook is not a card. Cleared by
   * whichever manager finds it in its own list.
   */
  walkTo: { kind: "card" | "lorebook"; id: string } | null;
  /**
   * Which agents' raw-output panels the user has expanded, keyed by agent id.
   * One boolean per agent used to be its own UIState field, which meant adding an
   * agent meant editing this interface, its initial value, the orchestrator's
   * pass→field switch, and every render condition.
   */
  expandedAgentLogs: Record<AgentId, boolean>;
  /**
   * The Director's note being written, and the settings it was primed with — `null` when
   * the composer is not in note mode.
   *
   * One field rather than a boolean beside a target and a lifetime. "Am I writing a note"
   * and "what did I choose for it" would be two representations of one state, and the pair
   * drifts in the direction that is worst: settings left over from the last note, quietly
   * addressing this one to somebody the reader never chose. Arming the composer *is*
   * choosing, so the choice is what the mode is made of.
   */
  directorsNote: NoteAddressing | null;
  isChooseAndEditMode: boolean;
  customChoiceMode: boolean;
  impersonatedCharId: string | null;
  equippedCallCharId: string | null;
  /**
   * An empty send asked who opens a story with nothing in it yet. Read only while the transcript is
   * empty, and only through `openingPickStands`, which asks the settings every render — a line in
   * the chat answers the rest of the question by itself. It was `inlineStartupSelect`, the picker's
   * own visibility, and it stood whatever the settings did next.
   */
  openingAsked: boolean;
  input: string;
  rewindPreviewTurn: number | null;
  /**
   * How far the typing animation has got, and who owns it. See `lib/chat/reveal` —
   * every transition goes through there, because the animation runs in one component
   * and is cancelled from another.
   */
  reveal: RevealState;
  /**
   * What Stop hid, offered back once.
   *
   * Deliberately ephemeral. §11's rule is about state whose absence corrupts a later
   * decision; the chat is already correct here and losing this loses only an offer.
   * Surviving a reload would be worse — "3 replies hidden · Restore" pointing at a
   * previous session, backed by messages `db.json` no longer has. It holds the whole
   * pre-cut chat rather than the removed messages because the cut also rolls back
   * entity state, and reconstructing that is precisely the second implementation this
   * pass exists to delete.
   *
   * `reading` is where the reader was when Stop cut, and what held them there: Restore puts the
   * reveal back at it, so the bubbles it hands back are a queue again rather than landing at once.
   *
   * `left` is the chat as Stop left it, and the offer stands only while the open chat is that very
   * object (`revealUndoFor`): written back over anything done since, Restore undid it unannounced.
   */
  pendingRevealUndo: { chat: Chat; left: Chat; hiddenTurns: number; reading: RevealPlace } | null;
}

/**
 * **A font the reader added themselves** (round 2026-10-30: *"Add a way for the user to add their own
 * font"*) — one file, kept on the `fonts` collection and synced like a background on the shelf: a
 * record each, so a device sends the one font that changed and never the set whole.
 *
 * Its id is what a font choice stores (`FontChoice`), and the `font-` prefix is what keeps it from
 * ever spelling one of the four shipped families. `file` is the font file as a data URL, the way a
 * portrait or a background is kept; `lib/fonts/user-fonts.ts` reads one in and draws it.
 */
export type UserFontId = `font-${string}`;

/**
 * The buttons this interface is made of.
 *
 * Written because the same three class strings were already spread across the app — the icon
 * button `"relative rounded p-1.5 text-ink-300 hover:bg-surface-400 hover:text-ink-600"` five
 * times in the chat header alone, the primary fill at a dozen call sites, and the
 * selected/unselected chip ternary about thirty times across the settings panels.
 *
 * ── Touch targets, and why `sm` has two sizes ─────────────────────────────────────────────
 *
 * The size scale is the reason this exists at all. The message action buttons were `p-1`
 * wrappers around `h-3.5` icons — a **22px** target, against a platform minimum of 44 — and
 * the composer's own buttons, in the same file tree, were already 40.
 *
 * Fixing that by making everything 44 traded one complaint for its opposite: a 44px pill
 * floating over every message is enormous under a mouse, where the target only has to be as
 * big as the pointer is precise. Both complaints are correct, because they are about
 * different input devices — so `sm` asks the device:
 *
 *     min-h-8 pointer-coarse:min-h-11
 *
 * 32px under a mouse, 44px under a finger. `pointer-coarse` is a real Tailwind v4 variant
 * (checked against this install with `candidatesToCss`, because a variant that silently
 * generates nothing is this repo's most-repeated failure) and it reads the *primary* pointer,
 * so a laptop with a touchscreen is sized for the trackpad it is actually being used with.
 *
 * `md` stays unconditionally 44: it is the default, and a caller that has not thought about
 * the question gets the safe answer. Getting the small one still takes an explicit `sm`,
 * which is the opposite of how the app got to 22px.
 */
export type Variant = "primary" | "secondary" | "ghost" | "danger" | "subtle" | "floating";

/**
 * How a page off the web is read for a model (`web_fetch`, `lib/server/web-page.ts`) — what of it is
 * kept, and how long the server waits for it.
 */
export type WebPageTuning = {
  /** A link keeps its address, `[text](address)`, so a model can fetch it next; off, its words alone. */
  links: boolean;
  /** A picture is read as what its alt text says, `[Image: …]`; off, it is left out. */
  pictures: boolean;
  /** How long a page, or one search engine, may take to answer, in seconds. */
  seconds: number;
};

/**
 * **What a batched window has heard**, keyed by the turn it belongs to.
 *
 * `of` names the AI line the players are answering (`windowKeyOf`), so a tally from an earlier
 * window is not a tally at all — it is ignored rather than reset, and there is no reset step to
 * forget. That is what the old wave's `waveOpen` + three counters could not say: whether the counts
 * were about *this* window.
 */
export type WindowTally = {
  of: string;
  ready: Seat[];
  lines: Record<Seat, number>;
  /** Calls the players' lines carried, in the order they were sent — answered when it closes. */
  calls: string[];
};

/**
 * **What a field is called on this wire**, where it is not the name `buildSamplingBody` writes.
 * The reply cap was the first (`max_completion_tokens`); the knobs followed when llama.cpp turned
 * out to read the repetition penalty as `repeat_penalty` — no alias for `repetition_penalty`
 * (`tools/server/server-schema.cpp`) — so its slider was drawn, sent, and dropped without a word.
 * One map for both, so a rename has one way to be written.
 */
export type WireNames = { max_tokens?: ReplyCapField } & Partial<Record<SamplerKnob, string>>;

export type World = {
  id: string;
  title: string;
  content: string;
  isAutoGenerated: boolean;
  isAutoEdited: boolean;
  isNew: boolean;
  image: string | null;
  imageTransform?: ImageTransform;
  /** Whether the card is always in the prompt, or retrieval's to admit. See CardActivation. */
  activation?: CardActivation;
  /** See `StatefulEntity` — the same field a character has, on the same terms. */
  states: EntityState[];
  /**
   * **The lorebook this card is in** — a world folder, which is what a lorebook is
   * (`lib/cards/lorebooks.ts`). In a chat it names one of `Chat.worldFolders`; on the world shelf
   * a `LibraryFolder`. Absent, or naming a lorebook that is gone, is no lorebook: the card is sent
   * under "General".
   *
   * **One fact for where a card is.** A card used to say it three ways — this folder (shelf
   * filing, reaching no model), a free-text `category` (the prompt heading, which the shelf named
   * its folders after) and `bookOf` (whose character book it was) — each set in a different place,
   * with nothing saying how they related. The heading is the lorebook's path now
   * (`lorebookPath`), and who owns the book is a link on the character (`Character.lorebooks`), so
   * the card holds only where it is. On
   * the card rather than as a list on the lorebook, for the reason `Character.folderId` gives: "in
   * two lorebooks at once" is not representable.
   *
   * Carried, not defaulted.
   */
  folderId?: string;
  /** Where in that folder the reader put it. See `order` on `Character`. */
  order?: number;
  /** The card's own retrieval keys — see `RetrievalKey`. Carried, not defaulted. */
  retrievalKeys?: RetrievalKey[];
  /**
   * **This card comes into a chat switched off** — SillyTavern's `disable`, as a fact about a
   * card that is not in a chat yet.
   *
   * In a chat the roster is the one answer to "is this card on" (`worldIds`), so the field has no
   * meaning there and is taken off when a card lands in one. It is the answer everywhere a card
   * has no roster around it: on the world shelf, and inside a file — a chat's card that is
   * switched out of its roster leaves as a file saying it lands switched off (`worldsAsFiled`),
   * which is exactly what a disabled World Info entry says.
   *
   * Carried, not defaulted, and only ever `true`: a card that lands switched on stores no key, so
   * every existing record serialises byte-identically.
   */
  landsSwitchedOff?: true;
  /** A shelf card's: the chat card it was saved from with its character — see `ShelfOrigin`. */
  savedFrom?: ShelfOrigin;
  /**
   * **What a SillyTavern lorebook entry said that this app does not read**, kept so the entry can
   * go back out saying it: the file's entry minus the fields this app reads and writes
   * (`OWN_ENTRY_FIELDS` in `lib/sillytavern.ts`), in World Info's spelling — `position`, `depth`,
   * `probability`, the inclusion groups, recursion, `sticky`/`cooldown`/`delay`, `characterFilter`,
   * `caseSensitive`/`matchWholeWords`, other apps' `extensions`, and whatever a future SillyTavern
   * adds.
   *
   * Written only by the importer and read only by the SillyTavern writers. It has no editor
   * because nothing in it has a behaviour here, and because it is *the entry minus what the card
   * says* it can never disagree with the card: a field is either read into the card or carried,
   * never both. Import used to keep 8 of about 40 fields, so re-exporting a book was never
   * faithful to the one it came from.
   *
   * Carried, not defaulted: a card that never came from SillyTavern stores no key, so every
   * existing record serialises byte-identically.
   */
  carriedWorldInfo?: Record<string, unknown>;
  /**
   * When this card was last written — the merge's tiebreak, once it is on the world shelf.
   *
   * Carried rather than defaulted, like `Character.updatedAt`: a card that has only ever
   * lived inside a chat is stamped by the chat around it and stores no key of its own, so
   * every existing chat serialises byte-identically. A card *on the shelf* is its own
   * record, and without a stamp two devices that edited different cards cannot both be
   * right — whichever saved last replaces the other wholesale.
   */
  updatedAt?: number;
};

export type WorldAdd = {
  type: "world_add";
  title: string;
  image: string | null;
  content: string;
};

export type AppStory = {
  /** The app's live state: the chat on screen, its pipeline, the reader's pace (`uiState`). */
  chats: { get: () => ChatState; set: (patch: Partial<ChatState>) => void; subscribe: (listener: (state: ChatState, previous: ChatState) => void) => () => void; use: <T>(selector: (state: ChatState) => T) => T; };
  /** The freshest copy of a chat of the library, or undefined. */
  readChat: (chatId: string) => Chat | undefined;
  /** Change a chat through the one door every edit takes; false when the write was not taken. */
  mutateChat: (chatId: string, mutator: (draft: Chat) => void) => boolean;
  /** A chat's pipeline as the store holds it (`PIPELINE_AT_REST` when nothing runs). */
  pipelineFor: (state: Pick<ChatState, "pipelines">, chatId: string | null) => PipelineState;
  PIPELINE_AT_REST: Partial<PipelineState>;
  /** A new chat in the library. */
  createChat: () => Chat;
  /** The reader's display name. */
  getDisplayName: () => string;
  /** A chat from another library made whole in this app's shape (a snapshot a table sent). */
  normalizeChat: (raw: Partial<Chat>) => Chat;
  /** Called when the library's chats change on this device. */
  onChatsChanged: (listener: () => void) => () => void;
  /** A change that marks nothing as touched by the reader. */
  quietly: <T>(write: () => T) => T;
  /** Keep chats open on this device (held, never parked) while `provider` names them. */
  keepOpen: <S>(store: Store<S>, open: (state: S) => readonly string[]) => () => void;
  /** The drafts at a chat's table, as the composing rows read them. */
  draftsAt: (rows: readonly ComposingRow[], place: ComposingPlace) => ComposingRow[];
  /** Whether a turn is writing now. */
  turnIsWriting: (p: Pick<PipelineState, "isGenerating" | "activePassPhase" | "activePassIds">) => boolean;
  /** The turns a table sees of a live reply. */
  tableTurnsOf: (chat: Chat, pipeline: Pick<PipelineState, "activePassIds" | "agentStreams" | "generatingMessageId" | "generatingSpeaker" | "writerRolls">) => RenderedTurn[];
  /**
     * **Say a refused intent in the composer**: its words go back in the box and the reason is read,
     * as the app does for its own refusals.
     */
  refused: (payload: { of: string; reason: string; text?: undefined; chatId?: undefined; } | { of: string; reason: string; text: string; chatId: string | null; }) => void;
};

export type AppTurns = {
  /**
     * **Start a turn**, as the app's own Send and Next turn do. Only from a press (see above).
     */
  start: (chatId: string, options?: Omit<{ chatId: string; reason?: string | undefined; generation?: GenerationType | undefined; }, "chatId">) => void;
  /** Stop the turn writing in a chat, as Stop does. */
  stopTurn: (chatId: string, cutAt?: ((chat: Chat) => TurnCursor | null) | undefined, held?: Omit<RevealPlace, "cursor">) => Promise<void>;
  /** Interrupt the writing turn: the id of what was writing, or null. */
  interrupt: (chatId: string) => Promise<string | null>;
  /** Pick a stalled run back up after a chat changed under it. */
  recover: (chatId: string) => void;
  enqueueSpeaker: (chat: Chat, characterId: string) => void;
  handOverTurn: (chat: Chat, calling: string | null, { passing }?: { passing?: boolean | undefined; }) => void;
  holdTurn: (chat: Chat, readerId: string) => void;
  stampRoundEntry: (chat: Chat, message: Message) => void;
  nextTurnOffered: (chat: Chat, pipeline: Pick<PipelineState, "isGenerating" | "generationError" | "toolLoadingState" | "summaryLoadingState" | "filing">) => boolean;
  nextTurnWaits: (chat: Chat) => boolean;
  turnOwner: (chat: Chat) => { nextOwner: "user" | "ai"; reason: string; };
  interruptWithLine: (draft: Chat, line: Message, at: LinePlace) => void;
  markInterruptedBy: (draft: Chat, lineId: string, replyIds: readonly (string | null)[]) => void;
  applyTurnDelete: (chatId: string, turnId: string) => boolean;
  applyTurnEdit: (chatId: string, turnId: string, content: string, images?: readonly MessageImage[] | undefined, files?: readonly MessageFile[] | undefined) => boolean;
  messageForTurnId: (chatId: string, turnId: string) => Message | undefined;
  mayRestructure: (chatId: string) => boolean;
  restructureChat: (chatId: string, change: () => boolean | void) => boolean;
  returnCarriedTakes: (chatId: string) => Message | null;
  editAnswer: (chatId: string, messageId: string, atOffset: number, edit: AnswerEdit) => string | null;
  cursorAtEndOfMessage: (chat: Chat, messageIndex: number) => TurnCursor | null;
  cursorAtOrBefore: (a: TurnCursor, b: TurnCursor) => boolean;
  divergingTurnIndex: (previous: readonly Message[], next: readonly Message[]) => number | null;
  holdsForReader: (turn: RenderedTurn, animation: AnimationSettings) => boolean;
  parseChunkTurnId: (turnId: string) => { messageId: string; chunkIndex: number; } | null;
  revealPacesTurns: (animation: AnimationSettings) => boolean;
  clampLifetime: (replies: number, opensAt: number) => number;
  queueInjection: (chatId: string, note: NoteAddressing & Pick<HiddenInjection, "content"> & Pick<HiddenInjection, "authorOwnerId"> & { id?: string | undefined; }, directorMessageId?: string | undefined) => void;
  applyArmedActions: (chatId: string, chat: Chat, queue: readonly ArmedAction[], on: SpentOn) => void;
  playerLineWords: (settings: Pick<BaseSettings, "playerLines"> | undefined, words: string) => Pick<Message, "content" | "raw">;
  readPlayerLineTools: (chatId: string, messageId: string, signal?: AbortSignal | undefined) => Promise<void>;
  resolveAnimation: (animation: Partial<AnimationSettings> | undefined) => AnimationSettings;
  /** The app's tuning numbers (`config/tuning.ts`). */
  tuning: <G extends TuningGroup>(settings: { readonly [K in G]?: Partial<TuningGroups[K]> | undefined; } | undefined, group: G) => TuningGroups[G];
};

export type AppReveal = {
  /** Who may release a held reveal: answers true to let it go. One at a time; `null` removes it. */
  setGatekeeper: (fn: (() => boolean) | null) => void;
  /** Who keeps Pause: one at a time; `null` removes it. */
  setPauseKeeper: (fn: (() => boolean) | null) => void;
  setPaused: (paused: boolean) => void;
  mirror: (chat: Chat, published: PublishedReveal | null, liveId: string | null) => void;
  followed: (chatId: string | null | undefined) => boolean;
  stopFollowing: (chatId: string | null) => void;
  releaseHeld: (at: string | null) => void;
  fitTo: (chat: Chat) => void;
  publishedOf: (chat: Chat, liveId: string | null) => PublishedReveal | null;
  reset: (cursor: TurnCursor | null, cards?: { turnId: string; shown: number; } | null) => void;
  placeReadingMark: (chat: Chat, mark: ReadingMark) => TurnCursor | null;
  readingMarkOf: (chatId: string | null) => ReadingMark | undefined;
  readReadingMark: (raw: unknown) => ReadingMark | undefined;
  /** The run as another screen draws it (`RunStatePayload`). */
  currentRun: (store: ChatState, chatId: string) => RunStatePayload;
  readRun: (raw: unknown) => RunStatePayload | null;
  readReveal: (raw: unknown) => PublishedReveal | null | undefined;
  applyRunStateToChat: (chatId: string, received: RunStatePayload) => void;
  /** Land what the table read, as the Director lands a reading. */
  landTableReading: (chatId: string, published: PublishedReveal | null) => void;
};

export type AppProposals = {
  approve: (chatId: string, bundleId: string, edits?: Record<string, unknown> | undefined) => string | null;
  /** What an approval turned away says, by reason. */
  APPROVE_REFUSED: { readonly gone: "That proposal is no longer in the story."; readonly settled: "That proposal is already settled."; readonly unseen: "That proposal hasn't been shown yet."; readonly stepped: "That proposal is approved from its own card."; };
  deny: (chatId: string, bundleId: string, actionId: string, denied?: boolean) => void;
  reject: (chatId: string, bundleId: string) => void;
  restoreAction: (chatId: string, bundleId: string, actionIds: readonly string[]) => void;
  restore: (chatId: string, bundleId: string) => void;
  update: (chatId: string, bundleId: string, actionId: string, payload: unknown) => void;
  isPending: (bundle: ProposalBundle) => boolean;
  /** What an edit may change, per kind. */
  EDITABLE_FIELDS: Record<string, EditableFields>;
  /** What an edit may change on this change — a built-in kind's row, a plugin's kind's own, or nothing. */
  editableFieldsOf: (event: { type?: unknown; kind?: unknown; } | undefined) => EditableFields | undefined;
  /** One editable field's value, wherever its kind keeps it. */
  fieldOf: (event: Record<string, unknown>, key: string) => unknown;
  /** The change with one editable field written, as a new object. */
  withField: <T extends Record<string, unknown>>(event: T, key: string, value: string) => T;
  /**
     * **The right a plugin's kind of change says governs a guest's edit to it** — or `null`: not a
     * plugin's change, or one whose kind declares none or is not installed here, which a guest may not
     * edit. Asked by the host's door (`editRight`), so a kind added by a plugin is the host's until it
     * says otherwise.
     */
  guestRightOf: (payload: unknown) => string | null;
  STATE_SET_MODES: { readonly replace: "edit"; readonly append: "add"; };
};

export type AppMic = {
  TABLE_SEAT: string;
  maySpeakNow: (rules: TurnRules, floor: FloorView, seat: string) => boolean;
  playerSeat: (ownerId: string) => string;
  seatCharacterId: (seat: string) => string | null;
  seatOwnerId: (seat: string) => string | null;
  windowCloses: (rules: Pick<TurnRules, "batchCloses" | "batchLineCap">, window: WindowTally, players: readonly string[], hostClosed: boolean) => boolean;
  windowFor: (stored: WindowTally | null, of: string) => WindowTally;
  ownerOfSpeaker: (chat: Chat, table: MicTableView, speakerId: string) => string | null;
  speakerOfSeat: (chat: Chat, table: MicTableView | null, seat: string) => string;
  turnRulesFor: (chat: Chat | null | undefined, table: MicTableView | null) => TurnRules;
  floorViewFor: ({ chat, rules, table, window, generating }: FloorInput) => FloorView;
  windowKeyOf: (chat: Chat) => string;
  tableFor: (chat: { id: string; } | null | undefined) => MicTableView | null;
};

export type AppTable = {
  provide: (port: TablePort) => () => void;
};

export type AppCast = {
  NARRATOR_ID: string;
  playerCharacterId: (ownerId: string) => string;
  isPlayerCharacterId: (characterId: string) => boolean;
  isOthersPlayerCard: (characterId: string, ownerId: string) => boolean;
  callableCharacters: (chat: CastView) => Character[];
  getSpeakerCharacter: (chat: Chat, speakerId: string | null) => Character | null;
  claimedCharacterFor: (chat: Chat, ownerId: string, claims: Record<string, string>) => Character | null;
  personaCharacterOf: (chat: Chat) => Character | null;
  tableCharacterFor: (chat: Chat, ownerId: string, claims: Record<string, string>, isHostAccount: boolean) => Character | null;
  chatHasTable: (chat: Chat | null | undefined, live: boolean) => boolean;
  isReservedCardId: (id: string) => boolean;
  mayDeleteCharacter: (card: Pick<Character, "id" | "roleSetting">) => boolean;
  mayLeaveStory: (card: Pick<Character, "id" | "roleSetting">) => boolean;
};

export type AppCards = {
  CARD_FIELDS: readonly CardField<"id" | "name" | "description" | "image" | "imageTransform" | "expressions" | "activation" | "isAutoGenerated" | "isAutoEdited" | "isNew" | "states" | "updatedAt" | "lorebooks" | "savedFrom" | "personality" | "scenario" | "firstMes" | "mesExample" | "creatorNotes" | "systemPrompt" | "postHistoryInstructions" | "alternateGreetings" | "chubId" | "cardSource" | "cardSourceId" | "roleSetting" | "tags" | "retrievalKeys" | "folderId" | "order" | "carriedExtensions" | "carriedCardFields">[];
  WORLD_FIELDS: readonly CardField<"id" | "image" | "imageTransform" | "activation" | "isAutoGenerated" | "isAutoEdited" | "isNew" | "states" | "updatedAt" | "savedFrom" | "retrievalKeys" | "folderId" | "order" | "title" | "content" | "landsSwitchedOff" | "carriedWorldInfo">[];
  readableStateRows: (raw: unknown) => EntityState[];
  MAX_STATE_DEPTH: number;
  readableImageTransform: (raw: unknown) => ImageTransform | undefined;
  isInlinePicture: (value: unknown) => value is string;
  TABLE_TALK_PICTURES: number;
  TABLE_TALK_LIMITS: PictureLimits;
  attachmentLimits: (settings: Partial<Pick<ChatSettings, "composer">> | undefined) => AttachmentLimits;
  parseDirectorTagSpans: (raw: string) => DirectorTagSpan[];
  TOOL_SPECS: readonly ToolSpec[];
  namesOf: (spec: ToolSpec) => string[];
  scanToolCalls: (raw: string) => ToolScan;
};

export type AppLibrary = {
  upsertCharacter: (chatId: string, character: Character) => boolean;
  deleteCharacter: (chatId: string, id: string) => void;
  upsertWorld: (chatId: string, world: World) => boolean;
  deleteWorld: (chatId: string, id: string) => void;
  upsertChatFolders: (chatId: string, kind: "world" | "character" | "arc", folders: readonly ChatFolder[]) => void;
  deleteChatFolders: (chatId: string, kind: "world" | "character" | "arc", ids: readonly string[]) => void;
  setEntityInChat: (chatId: string, kindId: EntityKindId, ids: string | readonly string[], active: boolean) => void;
  characterListings: () => CharacterListing[];
  /** The library's listings, by kind. */
  listings: (id: LibraryId) => Library<LibraryRecord, LibraryRecord>;
  withWholeCards: <T>(shelf: Library, cards: readonly LibraryRecord[], work: (whole: LibraryRecord[], away: CardsAway | null) => T) => Promise<T>;
  cardsAwaySay: (shelf: Pick<Library, "plural">, away: CardsAway) => string;
  absorbCard: (draft: Chat, intoId: string, fromId: string) => boolean;
};

export type AppNet = {
  apiFetch: (path: string, init?: RequestInit | undefined) => Promise<Response>;
  apiBeacon: (path: string, init?: RequestInit | undefined) => void;
  /** A request to another host's address with a seat token (`Authorization: Room <token>`). */
  roomFetch: (path: string, token: string, init?: RequestInit | undefined) => Promise<Response>;
  roomHeader: (token: string) => Record<string, string>;
  joinUrl: (address: string, path: string) => string;
  normalizeServerAddress: (raw: string) => string;
  /** Whether this is the packaged app (its pages are not served by the server they talk to). */
  IS_BUNDLED_APP: boolean;
  /** A retrying, ordered sender (`lib/net/outbox.ts`). */
  outbox: (options: OutboxOptions) => Outbox;
  answerOf: (status: number) => PostAnswer;
  deadlineIn: (remainingMs: unknown) => number | null;
  msLeft: (deadline: number | null | undefined) => number | null;
};

export type AppIdentity = {
  /** A name made fit to show, or null for one that is not a name. */
  playerName: (raw: string | null | undefined) => string;
  /** This device's seat token for a key (a host and a table), or "". */
  getSeat: (key: string) => string;
  setSeat: (key: string, token: string) => void;
};

export type AppPlugins = {
  isOn: (id: string) => boolean;
  /** A React hook: whether it is on, redrawn when the records change. */
  useIsOn: (id: string) => boolean;
  /** Called when the records change; the answer stops it. */
  subscribe: (listener: () => void) => () => void;
  /** Press one of a plugin's declared actions, as its card does: the server's sentence when refused. */
  act: (id: string, action: string) => Promise<{ ok: boolean; error?: string | undefined; }>;
  /**
     * A mount's address on this server or another's (`/api/plugins/<id>/<mount>`, or its public one
     * under `/public/`), for `net.apiFetch` and `net.roomFetch`.
     */
  mountPath: (id: string, mount: string, at?: { public?: boolean | undefined; }) => string;
  /** A plugin page's address (`/plugin?at=<id>/<path>`), with a query of the plugin's own. */
  pagePath: (id: string, page: string, query?: Record<string, string>) => string;
  /** What a device that is not this computer is told when it asks to change a plugin. */
  computerOnly: "Plugins can only be changed on the computer Dahlia AI runs on.";
};

export type AppNav = {
  /** Go and come back (`push`), or go instead (`replace`). */
  useNavigate: () => { push: (path: string) => void; replace: (path: string) => void; };
  usePath: () => string;
  useQuery: () => URLSearchParams;
  /** The chat screen's address for a chat. */
  chatPath: (chatId: string) => string;
};

export type AppParts = {
  ChatMessage: (props: Omit<ChatMessageProps, "speech">) => React.JSX.Element;
  MessageAvatar: ({ speakerCharacter, speakerName, box, face, continues, }: { speakerCharacter?: Character | null | undefined; speakerName?: string | undefined; box: { shape: { label: string; aspect: number; radius: string; icon: string; height: number | null; crop: "portrait" | "avatar"; }; width: number; height: number; ring: { className: string; style?: React.CSSProperties | undefined; }; }; continues?: string | null | undefined; face?: { image: string | null; transform?: ImageTransform | undefined; } | null | undefined; }) => React.JSX.Element;
  TypingWorm: ({ className }: { className?: string | undefined; }) => React.JSX.Element;
  AttachmentStrip: ({ images, onRemove, files, onRemoveFile, className, }: { images: readonly MessageImage[]; onRemove: (id: string) => void; files?: readonly MessageFile[] | undefined; onRemoveFile?: ((id: string) => void) | undefined; className?: string | undefined; }) => React.JSX.Element | null;
  useAttachments: (held: readonly MessageImage[], setHeld: (next: MessageImage[]) => void, pictureLimits: () => PictureLimits, documents?: HeldDocuments | undefined) => { pick: () => void; onPaste: (event: React.ClipboardEvent<Element>) => void; remove: (id: string) => void; removeFile: (id: string) => void; dropping: boolean; dropTarget: { onDragEnter: (event: React.DragEvent<Element>) => void; onDragOver: (event: React.DragEvent<Element>) => void; onDragLeave: (event: React.DragEvent<Element>) => void; onDrop: (event: React.DragEvent<Element>) => void; }; };
  PlayerNameEditor: ({ name, save, textClass, className, as: NameTag, }: { name: string | null; save: (next: string) => void; textClass?: string | undefined; className?: string | undefined; as?: "span" | "h1" | undefined; }) => React.JSX.Element;
  PlayerIdentityRow: ({ className }: { className?: string | undefined; }) => React.JSX.Element;
  useStoredPlayerName: () => { name: string | null; save: (next: string) => void; };
  SignInLink: ({ href }: { href: string; }) => React.JSX.Element;
  useSignInOffer: () => string | null;
  Reveal: ({ open, gap, gapAfter, appear, swap, as: Tag, children, ...data }: { open: boolean; gap?: "1" | "1.5" | "2" | "2.5" | "3" | "4" | undefined; gapAfter?: "1" | "1.5" | "2" | "2.5" | "3" | "4" | undefined; appear?: boolean | undefined; swap?: boolean | undefined; as?: "div" | "li" | undefined; children: React.ReactNode; } & { [attribute: `data-${string}`]: string | boolean | undefined; }) => React.JSX.Element | null;
  Surface: ({ elevation, radius, padding, bordered, className, ...rest }: SurfaceProps) => React.JSX.Element;
  ConfirmRow: ({ question, confirmLabel, onConfirm, onCancel, align, layout, }: { question: string; confirmLabel: string; onConfirm: () => void; onCancel: () => void; align?: "start" | "end" | undefined; layout?: "stack" | "inline" | undefined; }) => React.JSX.Element;
  ConfirmDeleteButton: ({ label, confirmLabel, icon, onConfirm, ...look }: { label: string; confirmLabel: string; icon: React.ReactNode; onConfirm: () => void; } & Look) => React.JSX.Element;
  useConfirmLatch: <T extends HTMLElement = HTMLDivElement>() => { armed: boolean; arm: () => void; disarm: () => void; ref: React.RefObject<T | null>; leave: (event: React.PointerEvent<Element>) => void; };
  useCopyFlash: (holdMs?: number) => { copied: boolean; copy: (text: string) => void; };
  useModalBackdrop: ({ onClose, open, layer, backdrop, padding, placement, keepOnBackdropClick, }: ModalBackdropOptions) => { ref: React.RefObject<HTMLDivElement | null>; className: string; onMouseDown: (e: React.MouseEvent<HTMLDivElement, MouseEvent>) => void; };
  submitsOnEnter: (e: React.KeyboardEvent<Element>) => boolean;
  TYPE: { readonly dialogTitle: "text-sm font-semibold text-ink-700"; readonly sectionHeading: "text-2xs font-semibold uppercase tracking-wider text-ink-200"; readonly label: "text-xs font-medium text-ink-500"; readonly body: "text-xs text-ink-600"; readonly hint: "text-3xs text-ink-200 leading-relaxed"; readonly warning: "text-3xs text-amber-600 dark:text-amber-400 leading-relaxed"; readonly readout: "font-mono text-2xs text-accent-300"; readonly emoji: "text-base"; };
  GLYPH: Record<Size, string>;
  /** The room's mark, as the header draws it. */
  RoomIcon: React.ComponentType<{ className?: string | undefined; weight?: "regular" | "bold" | "fill" | "duotone" | undefined; }>;
  chipAvatarBox: (appearance: Partial<AppearanceSettings> | undefined) => { shape: { label: string; aspect: number; radius: string; icon: string; height: number | null; crop: "portrait" | "avatar"; }; width: number; height: number; ring: { className: string; style?: React.CSSProperties | undefined; }; };
  useResolvedAppearance: (chat: Partial<AppearanceSettings> | undefined) => AppearanceSettings & { fontFamily: FontChoice; };
  useComposingRows: (chat: Chat | null, withheld?: string | null) => ComposingRow[];
};

export type AppAreas = {
  story: AppStory;
  turns: AppTurns;
  reveal: AppReveal;
  proposals: AppProposals;
  mic: AppMic;
  table: AppTable;
  cast: AppCast;
  cards: AppCards;
  library: AppLibrary;
  net: AppNet;
  identity: AppIdentity;
  plugins: AppPlugins;
  nav: AppNav;
  parts: AppParts;
};

/**
 * **A tag of your own in the story's text, drawn as your component** — the way the app draws its own
 * `<spoiler>`: the same parser keeps it, the same renderer draws it wherever story text is drawn (the
 * transcript, the Director's pane, a card's page), and the tool scanner leaves it alone.
 *
 * ```tsx
 * this.addStoryTag({
 *   name: "dice",
 *   Draw: ({ attrs, text }) => <span className="dice">{attrs.faces ?? text}</span>,
 * });
 * ```
 *
 * A model, a reader or your own code writes `<dice faces="3,5">3 and 5</dice>` into a message, and the
 * message is drawn with your component where the tag stands.
 *
 * - **The text is never changed.** What is stored and what a prompt sends is the tag as written, the
 *   way `<spoiler>` is sent: your component changes what the screen draws, not what any model reads.
 *   Teach a model the tag with a prompt block (`addPromptBlock`), which the reader adds.
 * - **Write the meaning inside it.** Once your plugin is removed the app no longer knows the tag and
 *   draws the words inside it as plain text — `3 and 5` above. A tag written empty (`<dice/>`) draws
 *   nothing then.
 * - A name the app already reads (a tool's, HTML's, `spoiler`) is refused.
 */
import type { ComponentType, ReactNode } from "react";

/** What your tag's component is handed. */
export type PluginStoryTagProps = {
  /** Its attributes as written, every value a string (a handler's `on…` name is never kept). */
  attrs: Readonly<Record<string, string>>;
  /** The words inside it, as plain text. */
  text: string;
  /** What is inside it, drawn by the app (emphasis, colour). Absent for a tag written empty. */
  children?: ReactNode;
};

export type PluginStoryTag = {
  /** The tag's name: lower-case letters, digits, `_` and `-`, starting with a letter. */
  name: string;
  /** Drawn inline where the tag stands, inside your plugin's mark (`[data-dahlia-plugin="<id>"]`). */
  Draw: ComponentType<PluginStoryTagProps>;
};

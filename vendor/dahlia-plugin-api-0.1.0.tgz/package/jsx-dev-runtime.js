import { PLUGIN_API_GLOBAL } from "./global.js";

/**
 * JSX as a development build compiles it (`jsxDEV`), against the app's React — what a test runner or
 * a dev server asks for when a plugin's `jsxImportSource` is this package. The app hands over its
 * production runtime only, so `jsxDEV` is its `jsx`/`jsxs` (the extra arguments a development build
 * passes — the source position, `self` — are debugging aids, not part of what is drawn).
 */
const { jsx: runtime } = globalThis[PLUGIN_API_GLOBAL] ?? {};
if (!runtime) {
  throw new Error("@dahlia/plugin-api: this code runs inside Dahlia, loaded as a plugin. There is no app here.");
}

export const Fragment = runtime.Fragment;
export function jsxDEV(type, props, key, isStaticChildren) {
  return (isStaticChildren ? runtime.jsxs : runtime.jsx)(type, props, key);
}

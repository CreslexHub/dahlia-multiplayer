/**
 * A plugin's id: lowercase words and hyphens. It names a folder on the reader's disk, so the app
 * refuses any other; the build refuses it first, where the author can still fix it.
 */
export const PLUGIN_ID_PATTERN = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

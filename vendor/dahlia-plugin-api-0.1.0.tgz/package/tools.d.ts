/**
 * **A tool a model can call** — a tag the Writer, the Director or any agent may write, answered by your
 * code, drawn as a card in the story.
 *
 * Registered with `this.addTool(tool)`, it joins the app's own tool table: the reader finds its card in
 * Add block → Tool instructions beside the app's tools, adds it to an agent, and from then on that
 * agent's prompt carries its paragraph (titled with your plugin's name, in Prompt master, Context master
 * and the Debug pane), its calls are read by the same parser and answered by your `answer`, and each
 * answer is drawn where the call was written. Nothing reaches a prompt until the reader adds the card.
 *
 * ```ts
 * this.addTool({
 *   name: "tower_roll",
 *   label: "Dice tower",
 *   says: "Drop dice down the tower and read what lands.",
 *   title: "TOWER ROLL — drop dice down the tower.",
 *   when: "a moment should be left to chance.",
 *   args: [{ name: "dice", type: "string", required: true, doc: 'how many six-sided dice, "3"' }],
 *   examples: [{ args: { dice: "3" } }],
 *   answer: (call) => {
 *     const faces = Array.from({ length: Number(call.args.dice) || 1 }, () => 1 + Math.floor(Math.random() * 6));
 *     return { text: `The tower drops ${faces.join(", ")}.`, data: { faces } };
 *   },
 *   card: { icon: { file: "icons/tower.svg" }, tone: "amber", Body: ({ data }) => <Faces faces={data?.faces} /> },
 * });
 * ```
 */
import type { ComponentType } from "react";
import type { CardLook } from "./graphics";
import type { PluginChat } from "./index";

/** One attribute of the tag. Its `doc` is the one clause the model is told about it. */
export type PluginToolArg = {
  name: string;
  type: "string" | "number" | "boolean" | "enum" | "list";
  /** For `enum`: the values, lower-case. */
  values?: readonly string[];
  required?: boolean;
  /** What leaving it out means, said to the model. */
  default?: string;
  doc: string;
  /** Other spellings read as this one, never shown to the model. */
  aliases?: readonly string[];
};

/** The call as the app's parser read it: attributes by their names (an alias already folded), and the body. */
export type PluginToolCall = {
  tool: string;
  args: Readonly<Record<string, string>>;
  body?: string;
};

/** What `answer` is handed beside the call. */
export type PluginToolContext = {
  /** The chat the call was written in, as it stood when the call was read. */
  chat: PluginChat;
  /** Aborts when the reader presses Stop: stop work, and anything you answer after is not read. */
  signal?: AbortSignal;
};

/**
 * **The answer**: the sentence the model reads next, and — for your card — anything it should draw
 * from. The card is *told* what to draw (`data`); it never reads the sentence back.
 */
export type PluginToolAnswer = string | { text: string; data?: Record<string, unknown> };

/** What your card's `Body` is drawn with. */
export type PluginToolCardProps = {
  call: PluginToolCall;
  /** The sentence the model read — the reader's version, once they edited it. */
  text: string;
  data?: Record<string, unknown>;
  /** The reader changed this answer after it was given. */
  edited: boolean;
};

export type PluginTool = {
  /**
   * The tag the model writes — lower-case letters, digits and `_`, starting with a letter — and the
   * name of its card. Refused when the app already reads that tag.
   */
  name: string;
  /** Other tag names read as this tool, never shown to the model. */
  aliases?: readonly string[];
  /** The card's name in Prompt master, and on its tag. */
  label: string;
  /** What it is for, in a sentence the reader is shown under its name. */
  says: string;

  // ── the paragraph the model is told, rendered by the app like its own tools' ──
  /** Its first line: `NAME — what it does.` */
  title: string;
  when?: string;
  whenNot?: string;
  /** Paragraphs after `when`, before the schema: the rules that are not grammar. */
  notes?: readonly string[];
  /** Worked calls, rendered in whichever form the chat writes calls in (a tag, or JSON). */
  examples?: readonly { args: Record<string, string>; body?: string }[];
  args: readonly PluginToolArg[];
  /** What goes between the tags, if anything. `field` is its name in the JSON form. */
  body?: { field: string; doc: string; required: boolean };
  /**
   * Who answers, and so what a call costs — said to the model beside the tag. `app` (the default): your
   * code, from what it holds. `web`: it leaves this computer, so the model is told to keep the story out.
   */
  answeredBy?: "app" | "web";

  /**
   * **Answer one call.** Runs only inside a turn somebody started, when an agent holding the card
   * writes the tag. Throwing answers the model with your message, as a failed tool.
   */
  answer: (call: PluginToolCall, context: PluginToolContext) => PluginToolAnswer | Promise<PluginToolAnswer>;

  /** How its answers are drawn in the story and the Director pane: a look, and a body under the line. */
  card?: CardLook & { Body?: ComponentType<PluginToolCardProps> };
};

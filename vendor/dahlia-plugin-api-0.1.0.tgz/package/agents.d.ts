/**
 * **An agent the reader can add** — a ready-made agent offered in Settings → Pipeline & Agents → Add an
 * agent, beside the app's own, under your plugin's name.
 *
 * Pressing Add writes it into the chat through the one door every new agent goes through (the wizard's
 * and the Director's `<agent_add>`): it becomes the reader's own written agent — its instructions its
 * base prompt block, its tools its tool cards, its place in the turn on its card — and runs inside the
 * turns the reader starts, like any agent. Nothing is added to any chat until the reader presses Add, and
 * removing your plugin leaves the agents already added where they are (they are the reader's); a tool
 * card of yours in one grants nothing while you are not installed.
 *
 * ```ts
 * this.addAgent({
 *   name: "Tower Keeper",
 *   description: "Rolls the dice tower when a scene turns on chance.",
 *   prompt: "You keep the dice tower. When the last reply leaves something to chance, drop the dice.",
 *   tools: ["tower_roll"],
 * });
 * ```
 */
import type { CardLook } from "./graphics";

/** The sampler knobs an agent's card carries (Settings → Pipeline & Agents → its card → Model & sampler). */
export type PluginAgentSampler = "temp" | "topP" | "topK" | "minP" | "topA" | "repPen" | "frequencyPenalty" | "presencePenalty" | "dryMultiplier" | "dryBase" | "dryAllowedLength";

/**
 * **What it is added asking of a model** — written onto its card at Add, where the reader sees it and
 * can change it like any agent's. It runs on the reader's own model (the chat's, unless they pick
 * another): a plugin never chooses which model, or whose key, a reader pays for.
 */
export type PluginAgentModel = {
  /** Sampler values over the chat's; each one turns the card's "Use the master sampler" off, as a reader's would. */
  sampling?: Partial<Record<PluginAgentSampler, number>>;
  /** The longest reply, in tokens. */
  maxTokens?: number;
  /** Whether it asks for a reasoning block. Absent: as the chat says (Connection). */
  allowThinking?: boolean;
  /** How hard it reasons when it may. */
  reasoningEffort?: "auto" | "minimal" | "low" | "medium" | "high" | "xhigh" | "max";
};

export type PluginAgent = {
  /** The name it is added under; the reader may rename it. Refused at Add if this chat has one by that name. */
  name: string;
  /** One line on what it is for: its card's, and what other agents are told about it. */
  description: string;
  /** Its instructions — the agent's base prompt block, which the reader can rewrite in Prompt master. */
  prompt: string;
  /** The tool cards it is added with, by name: your own tools (`addTool`) or the app's (`"roll"`, `"lookup"`…). */
  tools?: readonly string[];
  /**
   * When it runs: `"reply"` (in the reply, after the Writer), `"player"` (when the player sends), or the
   * id of the agent it runs right after (`"writer"`, the default: after the reply is written).
   */
  runs?: string;
  /** Turns between runs: 1 (the default) every turn, 0 only when called. */
  every?: number;
  /** Where its words go, as the agent card's output box spells it. Absent: nowhere. */
  output?: string;
  /** Its model settings, written on its card at Add (`PluginAgentModel`). Absent: the chat's. */
  model?: PluginAgentModel;
  /**
   * **Its card's look** in Pipeline & Agents: your icon for its mark and your tone for its badge, whose
   * word is `noun` (absent: "from <your plugin>"). Drawn while your plugin is installed; after, its
   * card wears the app's plain mark and says whose it was.
   */
  card?: CardLook;
};
